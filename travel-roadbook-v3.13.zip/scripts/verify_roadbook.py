#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""一键交稿自检（v2.8 严格版，给「不太会写代码的模型」用的硬闸门）。

用法（只有这一条，别自己发明参数）:
    python scripts/verify_roadbook.py --html 路书.html

退出码：0 = 可以交付；1 = 不许交付（按输出里的「怎么修」改）。
"""
import argparse
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
from html.parser import HTMLParser

HERE = os.path.dirname(os.path.abspath(__file__))
REQUIRED = ["v-home", "v-prep", "v-itinerary", "v-spots", "v-food", "v-budget", "v-faq", "v-planb", "v-official", "v-maps"]

# 功能完整性：这些能力必须真的存在（只换内容，不许整块删掉/改名/关掉）
FEATURES = [
    ("景点实拍图数据 V543_IMGS", "V543_IMGS"),
    ("景点别名映射 V600_ALIAS", "V600_ALIAS"),
    ("打卡热度榜弹层 v46", "v46-ov"),
    ("返回/关闭条 v564", "v564-back"),
    ("导航内核 __navTo", "__navTo"),
    ("票据识别页 v-ocr", 'id="v-ocr"'),
    ("记账页 v-budget", 'id="v-budget"'),
    ("景点打卡页 v-spots", 'id="v-spots"'),
    ("行程页 v-itinerary", 'id="v-itinerary"'),
    ("天数自适应 v15", "v15-anyday-js"),
    ("防退化护栏 v601", "v601-guard-js"),
    ("详情页实拍横幅", "v600-detail-photo"),
    ("转场层 v512", "v512"),
    ("背景层 v594", "v594"),
    ("滚动修复层 v23", "v23-scrollfix-js"),
    ("顺路判定层 v24", "v24-foodroute"),
    ("附近美食入口", 'id="v46-near"'),
    ("首页版本徽标", 'id="rbVer"'),
    ("热度榜条目", "v46-rank"),
    ("美食三 tab", 'data-v46-open="local"'),
    ("日卡实拍兜底 v2.7", "v27-fix-js"),
    ("选中态/底纹 v2.7 CSS", "v27-fix-css"),
    ("行程时间线自动补导航 v3.0", "v30-timeline-nav-js"),
    ("出发前准备页", 'id="v-prep"'),
    ("其他问题页", 'id="v-faq"'),
    ("备选方案页", 'id="v-planb"'),
    ("景区导览图入口", 'id="v-official"'),
    ("景区地图索引", 'id="v-maps"'),
    ("按餐次餐厅页", 'id="v-meal-'),
    ("预算明细页", 'id="v-budget-detail"'),
    ("导航缺失原地提示", "showNavMissing"),
    ("机票入口先切机票卡", "showPlane"),
    ("默认只显示当前票卡", "showSeg(curSeg)"),
    ("票据段数自适应", "buildTicketEntries"),
    ("行程内车票/航班入口", "rbInsertInlineTicket"),
    ("旧票务入口清理", "rbClearInlineTickets"),
    ("行程内入口无目标兜底", "rbInsertFallbackTicket"),
    ("旧页车票模式兼容", "rbTrainOnCompat"),
    ("旧页航班模式兼容", "rbFlightOnCompat"),
    ("行程内票据识别入口", "v63-ocr-entry"),
    ("车票/航班模式互斥", "syncTicketMode"),
]


def load(path):
    try:
        return io.open(path, encoding="utf-8").read()
    except Exception as e:
        print("FAIL 读不到文件：%s（%s）" % (path, e))
        sys.exit(1)


def sections(html):
    ids = set(re.findall(r'<section[^>]*\bclass="[^"]*\bview\b[^"]*"[^>]*\bid="([^"]+)"', html))
    ids |= set(re.findall(r'<section[^>]*\bid="([^"]+)"[^>]*\bclass="[^"]*\bview\b', html))
    return ids


def section_body(html, sid):
    """取一个 <section class=view> 的内容；碰到下一个 section 就停，避免把整页算进来。"""
    m = re.search(r'<section[^>]*\bid="%s"[^>]*>(.*?)(?=<section[^>]*\bid="v-|$)' % re.escape(sid), html, flags=re.S)
    return m.group(1) if m else ""


class _SectionNestParser(HTMLParser):
    """只追踪 section 的开闭；不依赖浏览器修正，专门抓整段替换吞 </section>。"""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.nested = []
        self.unclosed = []
        self.extra_close = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "section":
            return
        sid = dict(attrs).get("id", "?")
        if self.stack:
            self.nested.append((sid, self.stack[-1]))
        self.stack.append(sid)

    def handle_endtag(self, tag):
        if tag.lower() != "section":
            return
        if not self.stack:
            self.extra_close += 1
            return
        self.stack.pop()


def check_dom_nesting(html):
    """v3.7：section.view 必须平铺，不能互相嵌套。

    实测某个模型整段替换内容时把板块自带的 </section> 一起吃掉，
    38 个板块开标签只剩 21 个闭标签，17 个板块被套进前一个板块；
    静态文本检查仍 PASS，但 Dock 被父层 opacity:0/0×0 带走，打卡详情点进去空白。
    这里用显式 section 栈检查，不依赖浏览器容错。
    """
    bad = []
    p = _SectionNestParser()
    try:
        p.feed(html)
        p.close()
    except Exception as e:
        bad.append("DOM 结构无法解析：%s" % e)
        return bad
    # v3.8 修复：之前只检查 p.unclosed，但从未把栈里剩余的开标签写进去，
    # 导致「删掉最后一个 </section>」也能 PASS。feed 结束后栈里剩下的就是未闭合 section。
    if p.stack:
        p.unclosed = list(p.stack)
    if p.nested:
        sample = "、".join("%s⊂%s" % (a, b) for a, b in p.nested[:8])
        bad.append("DOM 嵌套错误：%d 个 section 被套进另一个 section（%s%s）；"
                   "典型根因是整段替换时吞掉了 </section>，必须保持每个 section.view 平铺、开闭标签一一对应"
                   % (len(p.nested), sample, "…" if len(p.nested) > 8 else ""))
    if p.unclosed:
        bad.append("DOM 有 %d 个未闭合的 section：%s（不能只复制开标签，必须补回对应 </section>）"
                   % (len(p.unclosed), "、".join(p.unclosed[:8])))
    if p.extra_close:
        bad.append("DOM 有 %d 个多余的 </section>：没有对应的开标签，说明整段替换边界错位" % p.extra_close)
    return bad


def visible_text(html):
    s = re.sub(r"<script\b[^>]*>.*?</script>", " ", html, flags=re.S | re.I)
    s = re.sub(r"<style\b[^>]*>.*?</style>", " ", s, flags=re.S | re.I)
    s = re.sub(r"<!--.*?-->", " ", s, flags=re.S)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"&nbsp;|&amp;|&lt;|&gt;|&quot;", " ", s)
    return re.sub(r"\s+", " ", s)


def is_blank_template(html, path=""):
    # v2.6：只有「4 张以下占位日卡 + 四个空数组」才算空白模板；
    # 实测 WorkBuddy 把 S/F 清空却保留 8 张真日卡，旧判定会把它当模板放行全部结构检查。
    # v3.2：空白模板只认 assets/template.html（或文件名含 template）；
    # 生成的「路书.html / 行程.html」如果 S/F/SPOTS 全空，不再当模板放行，直接按空壳 FAIL。
    cards = len(re.findall(r'<div[^>]*class="[^"]*\bdaycard\b[^"]*"', html))
    is_template_name = "template" in os.path.basename(path or "").lower()
    return (is_template_name and ("var F=[]" in html) and ("var S=[]" in html)
            and ("var SPOTS=[]" in html) and cards <= 4)


def check_ticket_module(html, blank=False):
    """v2.8：票卡必须是真 HTML，不许只剩 JS/CSS。
    实测 WorkBuddy 清空示例数据时整块删掉 #railCard/#planeCard/#tkForms，
    $('railCard') 返回 null，renderRail() 直接 return；OCR 识别出的座位无处可写。
    这里逐项硬检 DOM，再查 renderRail/planeHead 仍在，防止「自检 PASS、功能空壳」。
    v3.10：生成页还必须有行程内插入票务入口的实现，不能把入口全堆在日卡之后。"""
    bad = []
    required = [
        ("火车票卡 #railCard", 'id="railCard"'),
        ("火车票卡标题 #tkNo", 'id="tkNo"'),
        ("火车车型 #tkModel", 'id="tkModel"'),
        ("火车检票口 #tkGate", 'id="tkGate"'),
        ("火车座位汇总 #tkSeats", 'id="tkSeats"'),
        ("手动填按钮 #tkEdit", 'id="tkEdit"'),
        ("航班→火车切换 #tkRailOpen", 'id="tkRailOpen"'),
        ("票段容器 #tkForms", 'id="tkForms"'),
        ("行程票据折叠容器 #tripFold", 'id="tripFold"'),
        ("飞机票卡 #planeCard", 'id="planeCard"'),
        ("航班号 #fl_no", 'id="fl_no"'),
        ("起飞日期 #fl_date", 'id="fl_date"'),
        ("出发机场 #fl_from", 'id="fl_from"'),
        ("到达机场 #fl_to", 'id="fl_to"'),
        ("起飞时间 #fl_time", 'id="fl_time"'),
        ("登机口 #fl_gate", 'id="fl_gate"'),
        ("值机柜台 #fl_counter", 'id="fl_counter"'),
        ("OCR 票段切换 #segtabs", 'id="segtabs"'),
    ]
    for label, marker in required:
        if marker not in html:
            bad.append("票卡 DOM 缺失：%s（标记 %r 找不到；只能清值，不能删节点）" % (label, marker))
    if re.search(r'id\s*=\s*["\']tkPlaneOpen["\']', html):
        bad.append("车票卡出现「✈️ 航班座位」按钮 #tkPlaneOpen：用户要求高铁/火车板块不要有航班座位按钮")
    seg_ids = sorted({int(x) for x in re.findall(r'id="t(\d+)_no"', html)})
    if not seg_ids and not re.search(r'id="fl_no"', html):
        bad.append("票卡里没有任何车次段或航班号字段：票卡不能是空壳")
    if seg_ids and seg_ids != list(range(1, seg_ids[-1] + 1)):
        bad.append("车次段编号不连续：%s（必须是 1..N 连续编号，N 按实际段数）" % seg_ids)
    for n in seg_ids:
        missing = []
        for field in ("no", "date", "from", "to", "time", "gate", "note", "n1", "c1", "s1", "k1"):
            if 'id="t%d_%s"' % (n, field) not in html:
                missing.append(field)
        if missing:
            bad.append("第 %d 段缺字段 %s：OCR 结果没有输入框可写" % (n, "、".join(missing)))
    missing = []
    for field in ("n1", "s1", "k1"):
        if 'id="fl_%s"' % field not in html:
            missing.append(field)
    if missing:
        bad.append("航班乘客座位缺字段 %s：机票 OCR 结果没有输入框可写" % "、".join(missing))
    fold_nums = set(int(x) for x in re.findall(r'<a[^>]*\bfoldbtn\b[^>]*\bdata-seg="(\d+)"', html))
    if not fold_nums and "buildTicketEntries" not in html:
        bad.append("行程页缺可见车票/航班入口：必须有 .foldbtn 或 buildTicketEntries() 动态生成，否则 #tripFold 永远 display:none，票卡在 DOM 里用户也点不到")
    elif "buildTicketEntries" not in html and 9 not in fold_nums:
        bad.append("行程页缺航班入口 data-seg=\"9\"：机票卡在 DOM 里也点不到")
    if not blank and "rbInsertInlineTicket" not in html:
        bad.append("票务入口没有走行程内插入（缺 rbInsertInlineTicket）：入口会被堆在全部日卡之后，手机上滑到当天行程也看不到")
    if "for(i=1;i<=4;i++)seats.push" in html:
        bad.append("座位读取仍写死 4 行（for(i=1;i<=4;i++)seats.push）：必须按实际 .paxrow 数量读取")
    if re.search(r"seg\s*===\s*1\s*\|\|\s*seg\s*===\s*2\s*\|\|\s*seg\s*===\s*3", html):
        bad.append("票卡切换仍写死 1/2/3 段（applySeg 一类函数）：第 4 段以后从机票切回车票会失效，必须改成 seg>0&&seg!==9")
    for fn in ("function renderRail(n){", "function planeHead(){"):
        if fn not in html:
            bad.append("票卡渲染函数缺失：%s（只剩 DOM 不会回填）" % fn)
    return bad


def check_ticket_mode(html, blank):
    """v3.7：票卡模式必须显式声明，且不能把火车/航班同时关掉。

    生成动车行程时，页面不能还显示「航班座位」按钮或航班卡；
    生成航班行程时，不能还显示「返回车票」按钮或车次卡。
    显式声明比让模型猜更可靠：模板写 data-train="1" / data-flight="1"，
    生成时按真实行程把不存在的一侧改成 "0"。
    """
    bad = []
    rail = re.search(r'<([a-zA-Z0-9]+)[^>]*\bid="railCard"[^>]*>', html)
    plane = re.search(r'<([a-zA-Z0-9]+)[^>]*\bid="planeCard"[^>]*>', html)
    if rail:
        if not re.search(r'\bdata-train="(0|1)"', rail.group(0)):
            bad.append('#railCard 缺少 data-train="0|1"：无法判断动车行程是否真的有车次；模板必须显式写 1，生成页按实际改成 0/1')
    if plane:
        if not re.search(r'\bdata-flight="(0|1)"', plane.group(0)):
            bad.append('#planeCard 缺少 data-flight="0|1"：动车行程会误显示航班信息；有航班写 1，无航班写 0')
    if rail and plane:
        tm = re.search(r'\bdata-train="(0|1)"', rail.group(0))
        fm = re.search(r'\bdata-flight="(0|1)"', plane.group(0))
        if tm and fm and tm.group(1) == "0" and fm.group(1) == "0":
            bad.append("#railCard 和 #planeCard 的 data 都写 0：这一趟没有任何车次/航班入口，票卡功能被关死")
        # v3.8：模式标记必须和真实字段对应，不能只写 data-train="1" 却把 #tkForms 车次段整块删掉。
        if tm and tm.group(1) == "1" and not re.search(r'id="t\d+_no"', html):
            bad.append('#railCard 标记 data-train="1"，但页面没有任何 t{N}_no 车次字段：车票卡是空壳')
        if fm and fm.group(1) == "1" and 'id="fl_no"' not in html:
            bad.append('#planeCard 标记 data-flight="1"，但页面没有 fl_no 航班字段：机票卡是空壳')
    return bad


def check_flight_entry(html):
    """v3.3：机票入口第一次点击必须先隐藏 #railCard、只显示 #planeCard。

    实测旧生成页的 showPlane 只把 #planeCard 的 display 打开，
    #railCard 还留在最上面，用户点「返程航班 / 值机」先看到的是高铁座位。
    这里抓 showPlane 处理器附近的代码，没调用 showSeg(9) / applySeg(9) 就判 FAIL。
    """
    bad = []
    if "showPlane" not in html:
        return bad
    for marker in ("a.id==='showPlane'", 'a.id=="showPlane"', "t.id==='showPlane'", 't.id=="showPlane"'):
        idx = html.find(marker)
        if idx < 0:
            continue
        chunk = html[idx:idx + 1400]
        if ("showSeg(9)" not in chunk) and ("applySeg(9)" not in chunk):
            bad.append("机票入口 showPlane 没有切到机票卡：必须调用 showSeg(9) / applySeg(9)，先隐藏 #railCard 再显示 #planeCard")
            break
    return bad


def check_home_contract(html, blank):
    """v3.7：首页有且仅有 4 个磁贴；票据识别入口并入行程票卡。

    用户明确要求：首页不许多一条「车次识别」磁贴，也不许用快捷条变相多一个入口。
    OCR 入口必须像原版路书一样放在 #v-itinerary 的 #railCard/#planeCard 票卡按钮里：
    动车段里有「识别票据」，航班段里也有；首页只保留 4 个磁贴。
    """
    bad = []
    home = section_body(html, "v-home")
    if not home:
        bad.append("找不到 <section id=\"v-home\">，首页结构无法核对")
        return bad
    m = re.search(r'<div[^>]*class="[^"]*\btiles\b[^"]*"[^>]*>(.*?)</div>', home, flags=re.S)
    if not m:
        bad.append("首页没有 .tiles 磁贴区（4 个磁贴是框架，不许整块删）")
        return bad
    tile_body = m.group(1)
    tiles = re.findall(r'<a\b[^>]*>', tile_body)
    targets = []
    for a in tiles:
        tm = re.search(r'data-nav="([^"]+)"', a)
        if tm:
            targets.append(tm.group(1))
    required = {"v-prep", "v-itinerary", "v-budget", "v-faq"}
    if len(tiles) != 4:
        bad.append("首页 .tiles 磁贴有 %d 个，必须正好 4 个（准备/行程/预算/其他问题）" % len(tiles))
    if set(targets) != required:
        extra = sorted(set(targets) - required)
        missing = sorted(required - set(targets))
        bad.append("首页磁贴目标不是固定 4 个：多出 %s；缺少 %s（OCR 入口必须并入行程票卡，不能再占首页入口）" % (extra or "无", missing or "无"))
    if 'data-nav="v-ocr"' in home or "v63-ocr-entry" in home:
        bad.append("首页出现了票据识别入口（data-nav=v-ocr 或 v63-ocr-entry）：首页只许 4 个磁贴；"
                   "OCR 入口必须并入 #v-itinerary 的票卡按钮，不许做成第 5 个磁贴或快捷条")
    trip = section_body(html, "v-itinerary")
    if not trip:
        bad.append("找不到 #v-itinerary，无法核对行程内票据识别入口")
    elif 'data-nav="v-ocr"' not in trip or "v63-ocr-entry" not in trip:
        bad.append("行程页票卡里没有票据识别入口（#v-itinerary 内需要 data-nav=\"v-ocr\" 且带 v63-ocr-entry）："
                   "车票/航班识别必须像原版路书一样整合在行程票卡中")
    return bad


def check_ocr_module(html):
    """v3.4：OCR 页面和上传控件必须真实存在，不能只留一个 v-ocr 标题。"""
    bad = []
    if 'id="v-ocr"' not in html:
        bad.append("缺少票据识别板块 #v-ocr；车票/机票识别不是可删功能")
        return bad
    ocr = section_body(html, "v-ocr")
    if not ocr:
        bad.append("票据识别板块 #v-ocr 没有可读正文；不能只留一个空标题")
        return bad
    for label, marker in [
        ("上传票据图片 #tkimg", 'id="tkimg"'),
        ("粘贴订单文字 #tktext", 'id="tktext"'),
        ("自动填入按钮 #tkparse", 'id="tkparse"'),
        ("重新识别 #tkocr", 'id="tkocr"'),
        ("清空表格 #tkclear", 'id="tkclear"'),
        ("票段切换 #segtabs", 'id="segtabs"'),
    ]:
        if marker not in ocr:
            bad.append("票据识别页缺控件：%s（标记 %s）" % (label, marker))
    if not re.search(r'id="t\d+_no"', html) and not re.search(r'id="fl_no"', html):
        bad.append("票据识别页没有任何车次/航班字段：OCR 结果没有输入框可写")
    return bad


def check_structure(html, ids, blank):
    bad = []
    for r in REQUIRED:
        if r not in ids:
            bad.append("缺板块 %s" % r)
    if len(ids) < 30 and not blank:
        bad.append("板块只有 %d 个（模板基线 38，正常路书至少 30；少了就是被整块删了）" % len(ids))
    # v3.8：按真实 a[data-dock] 锚点计数，而不是按去重后的目标集合。
    # 之前重复两个「首页」只算 1 项，Dock 实际有 6 个锚点仍会被误判为 5 项。
    dock_anchors = re.findall(r'<a\b[^>]*\bdata-dock="([^"]+)"', html, flags=re.I)
    docks = set(dock_anchors)
    if len(dock_anchors) < 5:
        bad.append("Dock 只剩 %d 项（至少 5 项：首页/准备/行程/美食/记账）" % len(dock_anchors))
    elif len(dock_anchors) > 5:
        bad.append("Dock 有 %d 个 a[data-dock] 锚点，框架固定 5 项（首页/准备/行程/美食/记账）；"
                   "重复项/额外项都不许加" % len(dock_anchors))
    if len(dock_anchors) == 5 and len(docks) < 5:
        bad.append("Dock 5 个锚点里有重复目标：%s（必须首页/准备/行程/美食/记账各 1 个）" % sorted(dock_anchors))
    for t in sorted(docks):
        if t not in ids:
            bad.append("Dock 指向不存在的板块 %s" % t)
    if 'id="dayTabs"' not in html:
        bad.append("缺少天数 tab 容器 #dayTabs（天数自适应被拆了）")
    return bad


def check_nav_targets(html, ids):
    bad = []
    for attr in ("data-nav", "data-v46-go", "data-v15-go", "data-v564-go", "data-dock"):
        miss = []
        for m in re.finditer(attr + r'="([^"]+)"', html):
            t = m.group(1).strip()
            if not t or any(c in t for c in "+$"):
                continue
            if t.startswith("v-") and t not in ids:
                miss.append(t)
        if miss:
            uniq = sorted(set(miss))
            bad.append("%s 指向不存在的板块 %d 处：%s" % (attr, len(miss), "、".join(uniq[:8]) + ("…" if len(uniq) > 8 else "")))
    return bad



def check_day_selector(html):
    """v2.6：日卡统计只许 .daycard。
    实测 WorkBuddy 新版：querySelectorAll('.daycard, [data-day]') 把 body[data-day]
    和 8 个装饰层 .v514-art[data-day] 也当日卡，8 张真卡算成 16 张，生成 Day 1–16，
    双数 tab 对应装饰层所以点开空白。"""
    bad = []
    if "querySelectorAll('.daycard, [data-day]')" in html:
        bad.append("日卡统计用了并集选择器 querySelectorAll('.daycard, [data-day]')：body[data-day] / .v514-art[data-day] 会被算成日卡 → 8 张卡生成 16 个 tab、双数 tab 空白；只许 .daycard，老页面兜底用 .card[data-day]")
    if "querySelector('.daycard, [data-day]')" in html:
        bad.append("建 tab 插入点也用了并集选择器 .daycard, [data-day]；改成 .daycard，兜底 .card[data-day]")
    if "if(n>=cards.length)" in html:
        bad.append("tab 数量判定用了 n>=cards.length：旧 tab 多于日卡时也会误判为「够了」；改成 n===cards.length")
    return bad


def check_stray_text(html):
    """v2.6：</script> 后不许留裸 '>' 文本节点。
    实测 WorkBuddy 新版在 V5.68-78 追加层 </script> 后留了一个 '>'，
    浏览器把它渲染到屏幕左缘，就是用户红圈里的「尖尖箭头」。"""
    bad = []
    for m in re.finditer(r'</(?:script|style)>\s*>\s*', html):
        ctx = html[max(0, m.start() - 30):m.start() + 30].replace("\n", " ")
        bad.append("发现 </script>/<style> 后的游离 '>' 文本节点（会渲染成左缘尖箭头）：…%s…；删掉这个字符" % ctx)
    return bad


def check_spots(html, blank):
    bad = []
    # v3.9：不再把固定示例城市当目的地规则。
    # 热度榜分组必须和 S 数组里本次行程的真实 c 城市一致；
    # 模板空白页允许 cities=['目的地']，生成页则不允许保留任何示例分组。
    s_start = html.find("var S=")
    if s_start < 0:
        s_start = html.find("var S =")
    if s_start >= 0:
        s_end = html.find("];", s_start)
        s_seg = html[s_start:s_end + 2] if s_end >= 0 else html[s_start:s_start + 60000]
    else:
        s_seg = ""
    s_cities = sorted(set(re.findall(r"\bc\s*:\s*['\"]([^'\"]+)['\"]", s_seg)))
    city_groups = re.findall(r"cities\s*[:=]\s*\[([^\]]*)\]", html, flags=re.S)
    group_cities = []
    for g in city_groups:
        group_cities.extend(re.findall(r"['\"]([^'\"]+)['\"]", g))
    if not blank:
        if not s_cities:
            bad.append("S 数组为空或没有 c 城市字段：热度榜无法按本次行程的真实城市分组")
        elif not city_groups:
            bad.append("找不到 cities=[...] 热度榜分组：不能把分组交给空白模板或示例城市")
        else:
            unknown = sorted(set(c for c in group_cities if c not in s_cities))
            if unknown:
                bad.append("打卡热度榜分组包含 S 实际城市之外的地名 %d 个：%s（按本次行程 S 里的 c 城市分组，不要保留模板示例分组）"
                           % (len(unknown), "、".join(unknown[:8]) + ("…" if len(unknown) > 8 else "")))
    if re.search(r"共\s*0\s*个\s*点位", html):
        bad.append("打卡热度榜出现「共 0 个点位」→ 景点列表是空的")
    if not re.search(r'class="[^"]*\bv46-rank\b', html):
        bad.append("打卡热度榜没有任何 .v46-rank 条目 → 景点是空的")
    return bad


def check_details(html, ids, blank):
    bad = []
    if blank:
        return bad
    i = html.find("var S=")
    if i < 0:
        i = html.find("var S =")
    if i >= 0:
        j = html.find("];", i)
        seg = html[i:j + 2] if j >= 0 else html[i:i + 60000]
    else:
        seg = ""
    ds = re.findall(r"d['\"]?\s*:\s*['\"]([^'\"]+)", seg)
    miss = sorted(set(d for d in ds if d.startswith("v-") and d not in ids))
    if miss:
        bad.append("S 数组里的详情页目标不存在 %d 个：%s" % (len(miss), "、".join(miss[:8]) + ("…" if len(miss) > 8 else "")))
    spots = sorted(x for x in ids if x.startswith("v-spot-"))
    if len(spots) < 1:
        bad.append("景点详情页 0 个（至少要 1 个 v-spot-*；行程只有 1–2 个主景点时也不许多塞假景点）")
    for sid in spots:
        m = re.search(r'<section[^>]*\bid="%s"[^>]*>(.*?)</section>' % re.escape(sid), html, flags=re.S)
        if not m:
            bad.append("详情页 %s 找不到完整 <section> 内容" % sid)
            continue
        body = m.group(1)
        text = re.sub(r"<[^>]+>", "", body)
        text = re.sub(r"\s+", " ", text).strip()
        if len(text) < 80:
            bad.append("详情页 %s 正文只有 %d 字 → 是空壳" % (sid, len(text)))
        if "data-img=" not in body and "v600-detail-photo" not in body:
            bad.append("详情页 %s 没有实拍图位（data-img / v600-detail-photo）" % sid)
        if "<div class=\"hero\"" not in body and "<div class='hero'" not in body and "class=\"hero\"" not in body:
            bad.append("详情页 %s 缺少 .hero 标题区" % sid)
    return bad


def check_photos(html, blank):
    bad = []
    if blank:
        return bad
    i = html.find("V543_IMGS")
    seg = html[i:i + 20000] if i >= 0 else ""
    n = seg.count("data:image/")
    if n < 1:
        bad.append("V543_IMGS 里一张内嵌实拍图都没有（景点图会被运行时联网兜底拖死）")
    return bad


def check_day_covers(html, blank):
    """v2.7：非空白页的景点图 key 不能少于日卡张数。
    实测 WorkBuddy 7 天页：个别日期有内嵌图却取不到，
    因为 SPOTS 精确别名缺城市级写法；这里先卡「图数 < 天数」的硬缺口，
    再由 v27-fix-js 在运行时按 SPOTS 名字前缀逐张校正。"""
    bad = []
    if blank:
        return bad
    cards = len(re.findall(r'<div[^>]*class="[^"]*\bdaycard\b[^"]*"', html))
    i = html.find("window.V543_IMGS=")
    seg = html[i:i + 6000000] if i >= 0 else ""
    keys = re.findall(r'"([^"]+)"\s*:\s*"data:image/', seg)
    if cards and len(keys) < cards:
        bad.append("景点图 key 只有 %d 个，少于 %d 张日卡：必然有几天「找图中/暂无实拍图」" % (len(keys), cards))
    return bad


def check_timeline_nav(html, blank):
    """v3.0：行程时间线不许只写纯文本地名。
    实测 WorkBuddy 生成页：8 天时间线 48 个地点全是纯文本，整条时间线 0 个高德链接；
    其他板块的导航都在，只漏了用户最常点的时间线。模板已加 v30-timeline-nav-js 运行时补链，
    但生成页若把这一层也删了，就必须逐天有静态 uri.amap.com 链接。"""
    bad = []
    if blank:
        return bad
    parts = re.split(r'(?=<div[^>]*class="[^"]*\bdaycard\b)', html)
    total = 0
    missing = []
    tl_count = 0
    for part in parts:
        if not re.match(r'<div[^>]*class="[^"]*\bdaycard\b', part):
            continue
        tls = re.finditer(r'<ul[^>]*class="[^"]*\btl\b[^"]*"[^>]*>(.*?)</ul>', part, flags=re.S)
        for tl in tls:
            tl_count += 1
            n = len(re.findall(r'href="[^"]*uri\.amap\.com[^"]*"', tl.group(1)))
            total += n
            if n == 0:
                day = re.search(r'data-day="(\d+)"', part)
                missing.append(day.group(1) if day else "?")
    if not tl_count:
        bad.append("行程时间线没有 .tl：每天必须有一条按时间排序的 <ul class=\"tl\">（不许把时间线整块删了）")
        return bad
    has_layer = "v30-timeline-nav-js" in html
    if not total and not has_layer:
        bad.append("行程时间线没有高德导航链接，也没有 v30-timeline-nav-js 自动补链层：地名全是纯文本，用户点不动")
    elif missing and not has_layer:
        bad.append("行程时间线第 %s 天没有高德导航链接：每天至少要有 1 个 uri.amap.com 导航，或保留 v30 自动补链层" % "、".join(missing[:8]))
    if not total and has_layer:
        # 有运行时层时不算空壳，但静态源里最好也保留；这里只提示不判失败。
        pass
    return bad


def parse_version(s):
    m = re.match(r"v(\d+)\.(\d+)$", str(s))
    return (int(m.group(1)), int(m.group(2))) if m else None


def check_version(html, expect_version="", prev_version=""):
    bad = []
    m = re.search(r'<section[^>]*id="v-home"[^>]*>(.*?)(?=<section[^>]*\bid="v-(?!home)|$)', html, flags=re.S)
    home = m.group(1) if m else ""
    v = re.search(r'id="rbVer"[^>]*>(.*?)<', home, flags=re.S)
    if not v:
        bad.append('首页没有版本号徽标 <span id="rbVer">v0.1</span>（v2.2 起强制标在首页）')
        return bad
    text = re.sub(r"<[^>]+>", "", v.group(1)).strip()
    if not re.match(r"v\d+\.\d+$", text):
        bad.append("首页版本号 %r 不是 v{十位}.{个位} 格式（第一版 v0.1、第十版 v1.0）" % text)
    tip = re.search(r"本页 (v\d+\.\d+)", html)
    if not tip:
        bad.append("找不到 #wechatTip 的「本页 vX.Y」版本号，三处必须同号")
    elif tip.group(1) != text:
        bad.append("首页版本号 %s 与 #wechatTip 的 %s 不一致，三处必须同号" % (text, tip.group(1)))
    qr = re.search(r'(v\d+\.\d+)\s*[·•]\s*扫码在手机', html)
    if qr and qr.group(1) != text:
        bad.append("二维码副标题写的是 %s，首页却是 %s；三处必须同号" % (qr.group(1), text))
    if expect_version and text != expect_version:
        bad.append("用户要求这一版是 %s，首页却写 %s：改版必须递增版本号，三处同号" % (expect_version, text))
    if prev_version:
        a, b = parse_version(prev_version), parse_version(text)
        if not a:
            bad.append("--prev-version %r 格式不对，必须是 vX.Y" % prev_version)
        elif b and b <= a:
            bad.append("版本号没有递增：上一版 %s，这一版还是 %s；改过一次就必须往上走（v0.1→v0.2→…→v1.0）" % (prev_version, text))
    return bad


def check_days(html):
    bad = []
    tags = re.findall(r'<div[^>]*class="[^"]*\bdaycard\b[^"]*"[^>]*>', html)
    cards = len(tags)
    if cards == 0:
        bad.append("行程页没有 .daycard（一天一张日卡）")
    days = []
    for t in tags:
        m = re.search(r'data-day="(\d+)"', t)
        if m:
            days.append(int(m.group(1)))
    if cards and len(days) != cards:
        bad.append("有 %d 张日卡但只有 %d 张写了 data-day，编号缺失" % (cards, len(days)))
    if days:
        uniq = sorted(set(days))
        if uniq != list(range(1, max(uniq) + 1)):
            bad.append("日卡 data-day 不连续：%s（必须 1..N 连续）" % uniq)
        # v3.8：重复编号（1,1,2,3）虽然去重后连续，但会让 buildTabs 生成重复/错位 Day tab。
        if days != list(range(1, len(days) + 1)):
            bad.append("日卡 data-day 必须按顺序从 1 到 %d 唯一递增，实际是 %s（有重复或乱序）"
                       % (len(days), days))
    if re.search(r"for\s*\(\s*d\s*=\s*0\s*;\s*d\s*<\s*4\s*;", html):
        bad.append("写死 4 天：for(d=0;d<4)")
    if re.search(r"for\s*\(\s*(?:var\s+)?d\s*=\s*1\s*;\s*d\s*<=\s*4\s*;", html):
        bad.append("写死 4 天：for(d=1;d<=4)（日卡/装饰层都必须遍历全部 .daycard）")
    if "四天全部显示" in html:
        bad.append("写死文案：四天全部显示")
    i = html.find('id="v-itinerary"')
    seg = html[i:i + 6000] if i >= 0 else ""
    h1 = re.search(r'<h1[^>]*>(.*?)</h1>', seg, flags=re.S)
    if h1:
        title = re.sub(r"<[^>]+>", "", h1.group(1))
        hm = re.search(r'Day\s*1\s*[–-]\s*(\d+)', title)
        if hm and int(hm.group(1)) != cards:
            bad.append("行程页标题写死 Day 1–%s，但页面有 %d 张 .daycard（标题必须跟日卡数一致）" % (hm.group(1), cards))
    return bad, cards


def check_food(html, blank):
    bad = []
    if blank:
        return bad
    i = html.find("var F=")
    if i < 0:
        i = html.find("var F =")
    if i >= 0:
        # v3.8：与 S 数组同样的截断风险；按最近的 ]; 取完整数组，不再固定 12 万字符。
        j = html.find("];", i)
        seg = html[i:j + 2] if j >= 0 else html[i:i + 120000]
    else:
        seg = ""
    keys = re.findall(r"\{k\s*:\s*['\"]([^'\"]+)", seg)
    n = len(keys)
    r0 = seg.count("route:0")
    r1 = seg.count("route:1")
    if n >= 4 and r0 == 0:
        bad.append("美食 %d 道全部标成顺路（route:0 为 0）：顺路/绕路没有区分" % n)
    if n >= 4 and r1 == 0:
        bad.append("美食 %d 道全是绕路（route:1 为 0）：默认页会空" % n)
    if n >= 3:
        for k in keys:
            chunk = re.search(r"\{k\s*:\s*['\"]%s['\"][\s\S]*?(?=\{k\s*:|$)" % re.escape(k), seg)
            if not chunk:
                continue
            c = chunk.group(0)
            for field in ("c:", "g:", "rests:"):
                if field not in c:
                    bad.append("美食 %s 缺字段 %s（每条必须有城市/天数/代表餐厅）" % (k, field[:-1]))
                    break
    if "v24-foodroute" not in html:
        bad.append("缺少顺路自动判定层 v24-foodroute（只靠手写 route 标记不算）")
    if 'id="v46-near"' not in html:
        bad.append("美食页缺少「附近美食」入口（按定位搜高德 3 公里内餐饮）")
    if re.search(r"groupHTML\(on,", html):
        bad.append("「本地美食」页重复渲染顺路款，两页看起来一样")
    return bad


def check_placeholders(html, blank):
    bad = []
    if blank:
        return bad
    text = visible_text(html)
    for t in ("TODO", "待补", "待填", "暂无内容", "占位", "示例城市", "共 0 个点位", "共0个点位"):
        if t in text:
            bad.append("正文还有占位/示例内容：%s" % t)
    return bad


def check_scripts(html):
    if not shutil.which("node"):
        print("SKIP 本机没有 node，跳过 JS 语法检查（不扣分，但建议装 Node.js 后复跑）")
        return []
    blocks = re.findall(r"<script\b[^>]*>(.*?)</script>", html, flags=re.S | re.I)
    bad = []
    for i, code in enumerate(blocks):
        if not code.strip():
            continue
        fd, tmp = tempfile.mkstemp(suffix=".js")
        os.close(fd)
        with io.open(tmp, "w", encoding="utf-8") as f:
            f.write(code)
        r = subprocess.run(["node", "--check", tmp], capture_output=True, text=True)
        os.unlink(tmp)
        if r.returncode != 0:
            bad.append("第 %d 个 <script> 语法错：%s" % (i + 1, (r.stderr or "").strip().splitlines()[-1] if r.stderr else ""))
    return bad


def check_leftovers(path, allow=""):
    script = os.path.join(HERE, "check_demo_leftovers.py")
    if not os.path.exists(script):
        print("SKIP 找不到 check_demo_leftovers.py")
        return []
    cmd = [sys.executable, script, "--html", path, "--strict-code"]
    if allow:
        cmd += ["--allow", allow]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode == 0:
        return []
    lines = (r.stdout or "").strip().splitlines()
    return ["模板示例残留检查未通过：" + (lines[0] if lines else "退出码 %d" % r.returncode)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True)
    ap.add_argument("--expect-days", type=int, default=0,
                    help="用户明确说的天数；填了就把日卡数卡死，不一致直接 FAIL")
    ap.add_argument("--expect-version", default="",
                    help="用户要求这一版的路书版本（vX.Y）；填了就卡死三处同号")
    ap.add_argument("--prev-version", default="",
                    help="上一版路书版本（vX.Y）；填了就要求这一版必须比它大")
    ap.add_argument("--allow", default="",
                    help="行程真的会去的示例词，逗号分隔（如 本次真实城市,本次真实景点），透传给 check_demo_leftovers.py")
    a = ap.parse_args()
    html = load(a.html)
    size = len(html.encode("utf-8"))
    blank = is_blank_template(html, a.html)
    if size < 1_500_000 and not blank:
        print("FAIL 文件只有 %d KB，像是空壳/没写完整（正常路书 ≥ 1.5MB；空白模板除外）" % (size // 1024))
        return 1

    ids = sections(html)
    fails = []
    fails += check_dom_nesting(html)
    fails += check_structure(html, ids, blank)
    fails += check_home_contract(html, blank)
    fails += check_ocr_module(html)
    fails += check_ticket_module(html, blank)
    fails += check_ticket_mode(html, blank)
    fails += check_flight_entry(html)
    fails += check_nav_targets(html, ids)
    fails += check_timeline_nav(html, blank)
    fails += check_day_selector(html)
    fails += check_stray_text(html)
    fails += check_spots(html, blank)
    fails += check_details(html, ids, blank)
    fails += check_photos(html, blank)
    fails += check_day_covers(html, blank)
    fails += check_version(html, a.expect_version, a.prev_version)
    for label, marker in FEATURES:
        if marker not in html:
            fails.append("功能缺失：%s（标记 %r 找不到，被整块删了？）" % (label, marker))
    day_bad, cards = check_days(html)
    fails += day_bad
    if a.expect_days and cards != a.expect_days:
        fails.append("用户明确要 %d 天，页面却有 %d 张 .daycard（多/少一天都算内容错误）" % (a.expect_days, cards))
    fails += check_food(html, blank)
    fails += check_placeholders(html, blank)
    fails += check_scripts(html)
    fails += check_leftovers(a.html, a.allow)

    if fails:
        print("FAIL 不许交付（%d 项）：" % len(fails))
        for x in fails:
            print("  - " + x)
        print("\n怎么修（照着做，别猜）：")
        print("  1) 缺板块/功能 → 从 assets/template.html 把整块搬回来，只换内容，不许删")
        print("  2) 缺详情页 → 每个 S 里的 d 和行程入口都要有真实 <section id=\"v-spot-*\">，带 hero + data-img")
        print("  3) 天数 → 一天一张 .daycard，data-day 从 1 连续到 N；tab 交给 buildTabs，别写死")
        print("  4) 美食 → 每条写 c/g/rests，route:0 只进「本地美食 · 需绕路」，两页不重复")
        print("  4b) 日卡图 → 图 key 数必须 ≥ 日卡数；缺 v27-fix-js 就补回日卡实拍兜底层，不能靠“找图中”")
        print("  5) Day 1–16 / 双数空白 → 日卡统计只许 .daycard，别把 body[data-day]、.v514-art[data-day] 算进去；判定改 n===cards.length")
        print("  6) 左缘尖箭头 → 删掉 </script> 后那个游离的 > 字符")
        print("  7) 行程时间线 → 每个景点/车站/机场名必须是 uri.amap.com 链接；或保留 v30-timeline-nav-js")
        print("  8) 版本递增 → 改版必须带 --prev-version 与 --expect-version；首页/微信提示/二维码三处同号")
        print("  9) 改完再跑一次：python scripts/verify_roadbook.py --html 路书.html")
        return 1

    print("PASS 可以交付：%d 个板块、%d 张日卡、详情页/图片/导航/版本/美食分类全部过闸门。" % (len(ids), cards))
    return 0


if __name__ == "__main__":
    sys.exit(main())
