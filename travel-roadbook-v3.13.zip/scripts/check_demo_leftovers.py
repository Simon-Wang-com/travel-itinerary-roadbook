#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""交稿前自检：路书里不许残留模板的示例内容（杭州/南京那套 demo）。

为什么要有这个脚本：模板 `assets/template.html` 的 S / F / SPOTS / 美食三 tab /
机位面板 / 官方导览图 / 预算，全是「杭州 + 南京赏秋」示例。生成新路书时若只换一部分，
用户会看到别人的行程（实测踩过：某个 AI 干脆把美食打卡整个模块删了，理由就是
"它内嵌的是杭州/南京示例数据"）。

检查分三层（越靠前越硬）：
  A. 用户能看到的正文：去掉 <script>/<style> 后的文本 + 所有 <h1>/data-title —— 命中即失败。
  B. 数据块：`var S=` / `var F=` / `var SPOTS=` / `var MEALS=` / `V600_ALIAS` —— 命中即失败。
  C. 代码里的遗留命名（如 `#v-fuzimiao` 被复用成别的页面）—— 默认只提示，不判失败。

用法:
    python check_demo_leftovers.py --html 路书.html
    python check_demo_leftovers.py --html 路书.html --allow 南京,夫子庙   # 行程真去这些地方
    python check_demo_leftovers.py --html 路书.html --strict-code        # 连代码残留也判失败
退出码：0 干净 / 1 有残留 / 2 读不到文件
"""
import argparse
import io
import re
import sys

DEMO_TOKENS = [
    "杭州", "西湖", "灵隐", "飞来峰", "宋城", "西溪", "九溪", "法喜寺", "雷峰塔",
    "河坊街", "良渚", "拱宸桥", "满觉陇", "千岛湖", "杭州东站", "萧山", "金衙庄",
    "南京", "牛首山", "夫子庙", "秦淮", "老门东", "钟山", "中山陵", "明孝陵",
    "南京博物院", "红山森林动物园", "玄武湖", "鸡鸣寺", "栖霞山", "大报恩寺",
    "颐和路", "先锋书店", "德基", "新街口", "浦口火车站", "四方当代美术馆",
    "六朝博物馆", "总统府", "科举博物馆", "断桥", "白堤", "北山街",
    # v3.1：补上 v2.0 声称已清、实际还留在静态 HTML / 详情页 / 餐厅表里的南京杭州词
    "灵谷寺", "灵谷景区", "栖霞古镇", "栖霞古寺", "蒋有记", "鸡鸣汤包",
    "陆氏梅花糕", "梅家坞", "奎元馆", "新白鹿", "外婆家", "知味观",
    "片儿川", "鸭血粉丝", "盐水鸭", "紫金山", "美龄宫", "音乐台",
    "石象路", "上城区", "建康大厦", "长白街", "万安桥站",
    "示例城市", "示例街区", "示例湖景", "示例山", "示例寺院",
    "V5.62",
    "D100", "G7626", "G735", "上海虹桥",
    # v3.2：补静态详情/餐次/机位里的旧示例专名（这些之前不在词表里，导致 PASS 假干净）
    "大隐清心", "绿茶餐厅", "弄堂里", "五峰草堂", "莲湖糕团", "桃源村", "草桥",
    "李犟", "蟹满春", "茅家埠", "杨公堤", "龙井", "孤山", "湖滨", "贡院西街",
    "箍桶巷", "三条营", "建康路", "平江府", "仙林", "灵谷", "栖霞",
    "泗水桥", "文德桥", "乌衣巷", "江南贡院", "泮池", "大成殿",
    "杭帮菜", "梭子蟹炒年糕", "湖区牛肉羹", "东坡肉", "油爆虾",
    "小郑", "蓝老大", "糖粥藕", "天王烤鸭包", "美龄粥", "桂花糖芋苗", "赤豆元宵",
    "v-spot-xihu", "v-spot-beishan", "v-spot-lingyin", "v-spot-jiuxi",
    "v-spot-shixiang", "v-spot-mingling", "v-spot-meiling", "v-spot-linggu",
    "v-spot-yinyuetai", "v-spot-zhongshan", "v-spot-lingyuan", "v-spot-xuanwu",
    "v-spot-qixia", "v-meal-1119", "v-meal-1120", "v-meal-1121", "v-meal-1122",
    "hzNjCheck26", "湖光落日", "禅意银杏", "梧桐金秋", "满山红叶", "DEMO 数据",
    # 英文与 URL 也要查：模板里 iCal PRODID / UID、别人路书的外链都藏在这一层
    "Hangzhou", "Nanjing", "hz-nj", "workbuddy.host", "wbpk_",
]



REQUIRED_SECTIONS = ["v-home", "v-prep", "v-itinerary", "v-spots", "v-food", "v-budget"]


def structure_issues(html):
    """结构闸门：Dock / 底部导航指向的板块必须真的存在。

    实测踩过：某个 AI 生成的 7 天路书把 `v-spots` 整块删了，Dock 还留着「打卡」，
    点一下 `__navTo('v-spots')` 找不到目标就回落到首页 —— 用户看到的是「点打卡回首页」。
    """
    issues = []
    ids = set(re.findall(r'<section[^>]*\bclass="[^"]*\bview\b[^"]*"[^>]*\bid="([^"]+)"', html))
    ids |= set(re.findall(r'<section[^>]*\bid="([^"]+)"[^>]*\bclass="[^"]*\bview\b', html))
    for r in REQUIRED_SECTIONS:
        if r not in ids:
            issues.append("缺少必需板块：%s" % r)
    cards = len(re.findall(r'<div[^>]*class="[^"]*\bdaycard\b[^"]*"', html))
    if cards == 0:
        issues.append("行程页没有 .daycard（一天一张日卡是硬契约，缺了就没有 Day tab）")
    if re.search(r"for\s*\(\s*d\s*=\s*0\s*;\s*d\s*<\s*4\s*;", html):
        issues.append("检测到写死 4 天的日 tab 生成代码（for(d=0;d<4)）——必须按 .daycard 张数生成")
    if "四天全部显示" in html:
        issues.append("检测到写死「四天全部显示」文案——必须写「全部 N 天」")
    for m in re.finditer(r'<a[^>]*data-nav="([^"]+)"[^>]*data-dock="[^"]+"', html):
        t = m.group(1)
        if t not in ids:
            issues.append("Dock 指向不存在的板块：%s" % t)
    return issues


def strip_scripts(s):
    s = re.sub(r"<script\b[^>]*>.*?</script>", " ", s, flags=re.S | re.I)
    s = re.sub(r"<style\b[^>]*>.*?</style>", " ", s, flags=re.S | re.I)
    return s


def visible_text(html):
    s = strip_scripts(html)
    s = re.sub(r"<!--.*?-->", " ", s, flags=re.S)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"&nbsp;|&amp;|&lt;|&gt;|&quot;", " ", s)
    return s


def titles(html):
    out = []
    for m in re.finditer(r'data-title="([^"]*)"', html):
        out.append(m.group(1))
    for m in re.finditer(r"<h1[^>]*>(.*?)</h1>", html, re.S | re.I):
        out.append(re.sub(r"<[^>]+>", "", m.group(1)))
    return " ".join(out)


def data_blocks(html):
    blocks = []
    for name in ("var S=", "var F=", "var SPOTS=", "var MEALS=", "window.V600_ALIAS="):
        i = html.find(name)
        if i < 0:
            continue
        end = html.find("];", i)
        if end < 0:
            end = html.find("};", i)
        if end < 0:
            end = i + 4000
        blocks.append(html[i:end + 2])
    return "\n".join(blocks)


def url_query_text(html):
    """把 amap / 小红书链接里的 keyword/city/query 解码后再查。
    v3.0 只查正文，模板里 121 个 %E5%8D%97%E4%BA%AC（南京）链接全漏了；
    v3.1 起 URL 参数也算用户可见内容。"""
    from urllib.parse import unquote
    vals = re.findall(r'(?:keyword|city|query|q)=([^&"\'<>\\ ]+)', html)
    out = []
    for v in vals:
        try:
            out.append(unquote(v))
        except Exception:
            out.append(v)
    return " ".join(out)


def scan(text, tokens, allow):
    hits = {}
    for t in tokens:
        if t in allow:
            continue
        n = text.count(t)
        if n:
            hits[t] = hits.get(t, 0) + n
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True)
    ap.add_argument("--allow", default="", help="行程本身会出现的词，逗号分隔")
    ap.add_argument("--extra", default="", help="额外要查的词，逗号分隔")
    ap.add_argument("--strict-code", action="store_true", help="代码里的残留也判失败")
    a = ap.parse_args()

    try:
        html = io.open(a.html, encoding="utf-8").read()
    except Exception as e:
        print("读不到文件：%s（%s）" % (a.html, e))
        return 2

    allow = set(x.strip() for x in (a.allow or "").split(",") if x.strip())
    tokens = [t for t in DEMO_TOKENS if t not in allow]
    tokens += [x.strip() for x in (a.extra or "").split(",") if x.strip()]

    issues = structure_issues(html)
    if issues:
        print("结构检查不通过（%d 项）：" % len(issues))
        for x in issues:
            print("  - " + x)
        print("\n处理办法：板块 id 是硬契约（v-home / v-prep / v-itinerary / v-spots / v-food / v-budget …），")
        print("生成时只能换里面的内容，不许删板块、不许改名；Dock 的 data-nav 必须指向存在的板块。")
        return 1

    hard = {}
    hard.update({("正文", k): v for k, v in scan(visible_text(html), tokens, allow).items()})
    hard.update({("标题", k): v for k, v in scan(titles(html), tokens, allow).items()})
    hard.update({("数据块", k): v for k, v in scan(data_blocks(html), tokens, allow).items()})
    hard.update({("URL", k): v for k, v in scan(url_query_text(html), tokens, allow).items()})

    soft = scan(html, tokens, allow)

    if not hard and not (a.strict_code and soft):
        print("OK：没有发现模板示例残留（查了 %d 个词）" % len(tokens))
        if soft:
            print("提示：代码/样式里还剩这些旧命名（不影响页面，但看着像没换干净）：")
            print("  " + "、".join("%s×%d" % (k, v) for k, v in sorted(soft.items(), key=lambda x: -x[1])))
        return 0

    if hard:
        print("发现模板示例残留（用户可见）%d 处：" % len(hard))
        for (where, t), n in sorted(hard.items(), key=lambda x: -x[1]):
            m = re.search(re.escape(t), html)
            ctx = html[max(0, m.start() - 50):m.start() + 50].replace("\n", " ") if m else ""
            print("  [%s] %-10s ×%-4d %s" % (where, t, n, ctx[:100]))
        print("\n处理办法：这些是模板自带的「杭州+南京赏秋」示例。生成新路书时必须整块换：")
        print("  S（景点）/ F（美食）/ SPOTS（机位 key）/ 美食三 tab / 每日时间线 /")
        print("  概览与预算 / 官方导览图。行程真会去这些地方时用 --allow 列出。")
        return 1

    print("正文/标题/数据块干净；但代码里还有旧命名（加 --strict-code 时判失败）：")
    for k, v in sorted(soft.items(), key=lambda x: -x[1]):
        print("  %s×%d" % (k, v))
    return 1


if __name__ == "__main__":
    sys.exit(main())
