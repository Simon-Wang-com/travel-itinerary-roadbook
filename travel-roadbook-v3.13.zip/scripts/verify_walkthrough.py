#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""v3.8 用户视角无头走查。

和 verify_roadbook.py 的静态检查交叉验证：
- 首页必须有且仅有 4 个磁贴，且没有 OCR 入口（OCR 已并回行程票卡）；
- 走真实点击路径：打开行程票卡 → 点票卡内的「识别票据」→ 进入 #v-ocr；
- 按实际 .trainseg 段数逐个点开车票入口，核对每个 `trainseg.on` 与折叠入口；
- v3.10：票务入口必须全部位于当天 `.daycard .tl` 内（不能堆在全部日卡之后），且当前页至少一个真实可见；
- 车票/航班模式互斥、机票卡「返回车票」可切回；车票卡禁止出现「航班座位」/ #tkPlaneOpen 按钮；动车-only 不出现航班卡/入口，航班-only 不出现车次卡/入口；
- 切板块后的滚动位置必须回到离开时的位置；
- 点不存在的板块必须原地提示，不许静默回首页；
- 每个 v-spot-* 详情页进入后必须真实可见、尺寸不为 0、正文非空；详情页「返回上一级」必须可见且能回到 v-spots；
- Dock 必须真实可见且正好 5 项；Day tab 数必须跟 .daycard 张数一致。

用法：
    python scripts/verify_walkthrough.py --html 路书.html --expect-days N

依赖：Edge + websocket-client（python -m pip install websocket-client）。
只用无头浏览器，不打开虚拟桌面、不占用用户桌面。
"""
import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

try:
    import websocket
except Exception as e:
    print("FAIL 缺少 websocket-client：python -m pip install websocket-client（%s）" % e)
    sys.exit(1)

EDGE_CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def run(html, expect_days=0):
    edge = next((p for p in EDGE_CANDIDATES if os.path.exists(p)), None)
    if not edge:
        print("FAIL 找不到 Edge（msedge.exe），无法做无头走查")
        return 1
    tmp = tempfile.mkdtemp(prefix="rb-walk-")
    page = os.path.join(tmp, "route.html")
    shutil.copyfile(html, page)
    # 固定端口会和上一次未退出的 Edge/其他调试进程冲突；让系统分配空闲端口。
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    proc = subprocess.Popen([
        edge, "--headless=new", "--disable-gpu", "--hide-scrollbars",
        "--user-data-dir=" + os.path.join(tmp, "edge-profile"),
        "--remote-debugging-port=%d" % port, "--remote-allow-origins=*",
        "file:///" + page.replace("\\", "/")
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    ws = None
    try:
        time.sleep(2.5)
        tabs = json.load(urllib.request.urlopen("http://127.0.0.1:%d/json" % port))
        target = None
        for t in tabs:
            if t.get("type") == "page" and str(t.get("url", "")).startswith("file:///"):
                target = t
                break
        if not target:
            print("FAIL 无头浏览器没有打开页面")
            return 1
        ws = websocket.create_connection(target["webSocketDebuggerUrl"], timeout=120)
        expr = r"""
(async function(){
 function wait(ms){return new Promise(function(r){setTimeout(r,ms);});}
 function view(){var v=document.querySelector('.view.on');return v?v.id:'';}
 function q(s){return document.querySelector(s);}
 function qa(s){return Array.prototype.slice.call(document.querySelectorAll(s));}
 async function go(id){window.__navTo(id);await wait(2600);return {view:view(),y:window.scrollY};}
 function click(el){if(!el)return false;el.click();return true;}
 function showDay(n){
  var tab=q('#dayTabs .ptab[data-i="'+String(Number(n)-1)+'"]');
  if(!tab)return false;tab.click();return true;
 }
 function vis(el){
  if(!el)return false;
  var r=el.getBoundingClientRect();
  if(!(r.width>0&&r.height>0))return false;
  var p=el;
  while(p&&p.nodeType===1){
   var st=getComputedStyle(p);
   if(st.display==='none'||st.visibility==='hidden'||parseFloat(st.opacity)===0)return false;
   p=p.parentElement;
  }
  return true;
 }
 function info(el){
  if(!el)return {exists:false,visible:false,width:0,height:0,opacity:'',display:'',visibility:''};
  var s=getComputedStyle(el),r=el.getBoundingClientRect();
  return {exists:true,visible:vis(el),width:Math.round(r.width*100)/100,height:Math.round(r.height*100)/100,
   opacity:s.opacity,display:s.display,visibility:s.visibility};
 }
 function displayOk(el){if(!el)return false;var s=getComputedStyle(el);return s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';}
 function norm(s){return String(s||'').replace(/\s+/g,'').toLowerCase();}
 function fieldVal(id){var e=q('#'+id);return e?norm(e.value):'';}
 /* 首屏转场层可能短暂搬走 #dock/#dayTabs；固定等待 900ms 再取快照，避免把过渡态当成功能缺失。 */
 await wait(900);
 var out={};
 var home=q('#v-home');
 var tiles=qa('#v-home .tiles a');
 out.homeTiles=tiles.length;
 out.homeTileTargets=tiles.map(function(a){return a.getAttribute('data-nav')||'';});
 out.homeTileVisible=tiles.map(function(a){return vis(a);});
 /* v3.7：首页只许 4 个磁贴，票据识别入口必须在行程票卡里 */
 out.homeOcrEntry=!!q('#v-home [data-nav="v-ocr"]');
 out.homeOcrMarker=!!q('#v-home .v63-ocr-entry');
 out.itineraryOcrMarker=!!q('#v-itinerary .v63-ocr-entry');
 var dock=q('#dock');
 out.dock=info(dock);
 out.dockCount=document.querySelectorAll('#dock').length;
 out.dayTabsCount=document.querySelectorAll('#dayTabs').length;
 out.dockTargets=qa('#dock a[data-dock]').map(function(a){return a.getAttribute('data-dock')||'';});
 out.dockLinks=qa('#dock a[data-dock]').length;
 out.dockLinksVisible=qa('#dock a[data-dock]').map(function(a){return vis(a);});
 out.planeFields=!!q('#fl_no')&&!!q('#planeCard');
 out.railFields=!!q('#railCard')&&!!q('#tkNo');
 var cards=qa('#v-itinerary .daycard').length;
 var tabs=qa('#dayTabs .ptab').length;
 out.daycards=cards; out.daytabs=tabs;
 await go('v-itinerary');
 var mode=(window.__rbTicketMode?window.__rbTicketMode():{train:true,flight:true});
 out.ticketMode=mode;
 out.trainEnabled=!!mode.train; out.flightEnabled=!!mode.flight;
 out.foldCount=qa('#v-itinerary .foldbtn[data-seg]').length;
 out.foldSegs=qa('#v-itinerary .foldbtn[data-seg]').map(function(a){return a.getAttribute('data-seg');});
 /* v3.10：入口必须在日卡时间线内，不允许全部堆在日卡之后；这里同时看 DOM 位置和实际可见性。 */
 out.foldInDaycard=qa('#v-itinerary .foldbtn[data-seg]').filter(function(a){
  return !!a.closest('.daycard')&&!!a.closest('.tl');
 }).length;
 out.foldInDaycardVisible=qa('#v-itinerary .foldbtn[data-seg]').filter(function(a){
  return !!a.closest('.daycard')&&!!a.closest('.tl')&&vis(a);
 }).length;
 out.bottomFoldRows=qa('#v-itinerary .ticketfold-row').length;
 /* v3.12：入口不仅要“在 .tl 内”，还必须紧跟对应车次/航班的时间行；
    否则全部塞在 Day1 末尾也会被旧检查放行。 */
 out.foldPlacement=qa('#v-itinerary .foldbtn[data-seg]').map(function(a){
  var seg=String(a.getAttribute('data-seg')||'');
  var li=a.closest('li'),prev=li?li.previousElementSibling:null;
  var vals=seg==='9'?[fieldVal('fl_no'),fieldVal('fl_time')]:[fieldVal('t'+seg+'_no'),fieldVal('t'+seg+'_time')];
  var prevTxt=prev?norm(prev.textContent):'',hit=false,vi;
  for(vi=0;vi<vals.length;vi++){if(vals[vi]&&prevTxt.indexOf(vals[vi])>=0)hit=true;}
  return {seg:seg,prev:prevTxt.slice(0,90),vals:vals,hit:hit};
 });
 var trainSegs=qa('#tkForms .trainseg');
 out.trainSegs=trainSegs.map(function(s){return s.getAttribute('data-seg');});
 out.trainCount=trainSegs.length;
 out.ocrSegTabs=qa('#segtabs .segtab').length;
 out.ocrSegTabData=qa('#segtabs .segtab').map(function(a){return a.getAttribute('data-seg');});
 out.flightEntry=!!q('#v-itinerary .foldbtn[data-seg="9"]')&&!!q('#planeCard');
 out.tkPlaneBtn=info(q('#tkPlaneOpen')); out.tkRailBtn=info(q('#tkRailOpen'));
 out.expectedFold=(out.trainEnabled?out.trainCount:0)+(out.flightEnabled?1:0);
 out.segChecks=[];
 if(out.trainEnabled){
  for(var si=0;si<trainSegs.length;si++){
   var sn=trainSegs[si].getAttribute('data-seg');
   var sb=q('#v-itinerary .foldbtn[data-seg="'+sn+'"]');
   if(!sb){out.segChecks.push({seg:sn,clicked:false});continue;}
   var sd=sb.closest('.daycard');if(sd&&sd.getAttribute('data-day')){showDay(sd.getAttribute('data-day'));await wait(240);}
   click(sb);await wait(280);
   var on=q('#tkForms .trainseg.on');
   out.segChecks.push({seg:sn,clicked:true,active:on?on.getAttribute('data-seg'):null,foldOpen:displayOk(q('#tripFold'))});
  }
 }
 var fb=q('#v-itinerary .foldbtn[data-seg="1"]')||q('#v-itinerary .foldbtn[data-seg="9"]');
 if(fb&&!out.trainEnabled){var fbd=fb.closest('.daycard');if(fbd&&fbd.getAttribute('data-day')){showDay(fbd.getAttribute('data-day'));await wait(240);}click(fb);await wait(500);}
 out.tripFoldOpen=displayOk(q('#tripFold'));
 /* v3.10：原版行为是点击时间线入口后，把整个 #tripFold 明细卡搬进当天 .daycard .tl，而不是只在页尾展开。 */
 var tf=q('#tripFold');
 out.foldInline=!!tf&&!!tf.closest('.daycard .tl')&&displayOk(tf);
 out.tkPlaneBtnAfterFold=info(q('#tkPlaneOpen'));
 out.railW=q('#railCard')?q('#railCard').getBoundingClientRect().width:0;
 out.rail0=displayOk(q('#railCard')); out.plane0=displayOk(q('#planeCard'));
 out.layout={vw:innerWidth,railW:q('#railCard')?q('#railCard').getBoundingClientRect().width:null,railOff:q('#railCard')?q('#railCard').offsetWidth:null,railDisplay:q('#railCard')?getComputedStyle(q('#railCard')).display:null,railParent:q('#railCard')&&q('#railCard').parentElement?getComputedStyle(q('#railCard').parentElement).display:null,itW:q('#v-itinerary')?q('#v-itinerary').getBoundingClientRect().width:null};
 /* 票卡里的 OCR 按钮必须在打开票卡后真实可见；首页不再有 OCR 入口 */
 out.itineraryOcrVisible=false;
 var itOcr=qa('#v-itinerary [data-nav="v-ocr"]').filter(vis)[0];
 out.itineraryOcrVisible=!!itOcr;
 if(itOcr){click(itOcr);await wait(2600);out.ocrView=view();}
 out.ocrFields={img:!!q('#tkimg'),text:!!q('#tktext'),parse:!!q('#tkparse'),segtabs:!!q('#segtabs'),clear:!!q('#tkclear')};
 await go('v-itinerary');
 var f9=q('#v-itinerary .foldbtn[data-seg="9"]');
 if(out.flightEnabled&&f9){
  var f9d=f9.closest('.daycard');if(f9d&&f9d.getAttribute('data-day')){showDay(f9d.getAttribute('data-day'));await wait(240);}
  click(f9);await wait(500);
  out.railAfterPlane=displayOk(q('#railCard')); out.planeAfterPlane=displayOk(q('#planeCard'));
  out.tkRailBtnAfterFlight=info(q('#tkRailOpen'));
  if(out.trainEnabled){
   var backRail=q('#tkRailOpen');
   if(backRail&&vis(backRail)){click(backRail);await wait(500);}
   out.railBack=displayOk(q('#railCard')); out.planeBack=displayOk(q('#planeCard'));
  }
 }
 out.lastTrainSeg='';
 if(out.trainEnabled&&trainSegs.length){
  var lastTrain=trainSegs[trainSegs.length-1];
  out.lastTrainSeg=lastTrain.getAttribute('data-seg');
  var lb=q('#v-itinerary .foldbtn[data-seg="'+out.lastTrainSeg+'"]');
  if(lb){var lbd=lb.closest('.daycard');if(lbd&&lbd.getAttribute('data-day')){showDay(lbd.getAttribute('data-day'));await wait(240);}click(lb);await wait(360);}
  out.lastTrainRail=displayOk(q('#railCard'));
  out.lastTrainPlane=displayOk(q('#planeCard'));
  out.lastTrainActive=(q('#tkForms .trainseg.on')||{}).getAttribute?q('#tkForms .trainseg.on').getAttribute('data-seg'):null;
 }
 out.budgetN=q('#spN')?q('#spN').value:'';
 out.budgetMembers=qa('#spParts label').length;
 out.budgetHero=String((q('#v-budget .hero p')||{}).textContent||'');
 out.ticketPax=q('#v543Pax')?q('#v543Pax').value:'';
 var tkclear=q('#tkclear');
 if(tkclear){click(tkclear);await wait(220);}
 out.ticketPaxAfterClear=q('#v543Pax')?q('#v543Pax').value:'';
 /* 用户场景：初始就在顶部，切走再切回必须还在顶部，不能变成底部/中部 */
 window.scrollTo(0,0); await wait(120);
 out.topStart={view:view(),y:window.scrollY};
 out.foodTop=await go('v-food');
 out.backTop=await go('v-itinerary');
 // 给首页/行程页加长内容，确保 420 不是页面底部
 var h=q('#v-home'), it=q('#v-itinerary');
 if(h){var d=document.createElement('div');d.style.height='1600px';h.appendChild(d);}
 if(it){var d2=document.createElement('div');d2.style.height='2600px';it.appendChild(d2);}
 await go('v-itinerary');
 window.scrollTo(0,420); await wait(180);
 out.scrollStart={view:view(),y:window.scrollY};
 out.food=await go('v-food');
 out.back=await go('v-itinerary');
 out.home=await go('v-home');
 out.homeBack=await go('v-itinerary');
 out.dockAtItinerary=info(dock);
 out.dockLinksVisibleAtItinerary=qa('#dock a[data-dock]').map(function(a){return vis(a);});
 /* 每个景点详情都要真实点开；不是只看 DOM 里有没有 section，而是看 .on 页面、可见性、实际尺寸和正文长度 */
 await go('v-spots');
 var spotSections=qa('section.view[id^="v-spot-"]');
 out.spotCount=spotSections.length;
 out.spotChecks=[];
 for(var sk=0;sk<spotSections.length;sk++){
  var sid=spotSections[sk].id;
  window.__navTo(sid); await wait(1400);
  var sv=q('#'+sid);
  var sw=sv?sv.querySelector('.wrap'):null;
  out.spotChecks.push({id:sid,on:view(),visible:vis(sv),wrapVisible:vis(sw),
   width:sv?Math.round(sv.getBoundingClientRect().width*100)/100:0,
   height:sv?Math.round(sv.getBoundingClientRect().height*100)/100:0,
   opacity:sv?getComputedStyle(sv).opacity:'',
   text:sv?String(sv.textContent||'').replace(/\s+/g,'').length:0});
 }
 /* 景点详情的返回/关闭是原版功能；不能只证明页面能进去，还要证明能按来路退回 */
 out.spotBack={};
 if(spotSections.length){
  var fs=spotSections[0];
  await go('v-spots');
  var fsLink=q('#v-spots .idxlist a[data-nav="'+fs.id+'"]');
  if(fsLink){click(fsLink);await wait(2600);}
  else {window.__navTo(fs.id);await wait(1600);}
  var fback=fs.querySelector('.v564-back');
  out.spotBack={exists:!!fback,visible:vis(fback),from:view()};
  if(fback&&vis(fback)){click(fback);await wait(2600);out.spotBack.view=view();}
 } await go('v-itinerary');
 click(q('#dock a[data-nav="v-home"]')); await wait(2600); out.dockHome=view();
 var beforeMissing=view();
 window.__navTo('v-does-not-exist'); await wait(150);
 out.missingTip=!!q('#navMissingTip')&&vis(q('#navMissingTip'));
 out.missingStayed=view()===beforeMissing;
 out.version=(q('#rbVer')||{}).textContent||'';
 return out;
})()
"""
        resp = ws.send(json.dumps({
            "id": 1, "method": "Runtime.evaluate",
            "params": {"expression": expr, "awaitPromise": True, "returnByValue": True}
        }))
        while True:
            msg = json.loads(ws.recv())
            if msg.get("id") == 1:
                value = msg.get("result", {}).get("result", {}).get("value", {})
                exc = msg.get("result", {}).get("exceptionDetails")
                if exc:
                    print("JS_EXCEPTION " + json.dumps(exc, ensure_ascii=False))
                break
        fails = []
        is_template = "template" in os.path.basename(html).lower()
        if value.get("homeTiles") != 4:
            fails.append("首页磁贴数为 %r，必须 4 个" % value.get("homeTiles"))
        expect_targets = ["v-prep", "v-itinerary", "v-budget", "v-faq"]
        if sorted(value.get("homeTileTargets") or []) != sorted(expect_targets):
            fails.append("首页磁贴目标为 %r，必须是 %s" % (value.get("homeTileTargets"), expect_targets))
        if not all(value.get("homeTileVisible") or []):
            fails.append("首页磁贴有不可见的（display/visibility/opacity 或实际尺寸为 0）：%r" % (value.get("homeTileVisible"),))
        if value.get("homeOcrEntry") or value.get("homeOcrMarker"):
            fails.append("首页出现了票据识别入口（data-nav=v-ocr=%r、v63-ocr-entry=%r）：用户要求首页有且仅有 4 个磁贴，OCR 必须并入行程票卡"
                         % (value.get("homeOcrEntry"), value.get("homeOcrMarker")))
        if not value.get("itineraryOcrMarker"):
            fails.append("行程票卡里没有 v63-ocr-entry 票据识别入口")
        if not value.get("itineraryOcrVisible"):
            fails.append("打开票卡后，行程内票据识别按钮不可见（不能只靠 DOM 里存在）")
        if value.get("ocrView") != "v-ocr":
            fails.append("点击行程内票据识别按钮没有进入 v-ocr（实际 %r）" % value.get("ocrView"))
        if not all(value.get("ocrFields", {}).values()):
            fails.append("票据识别页缺少上传/粘贴/票段控件：%r" % value.get("ocrFields"))
        if value.get("dockLinks") != 5:
            fails.append("Dock 不是固定 5 项（实际 %r 个：%r）" % (value.get("dockLinks"), value.get("dockTargets") or []))
        if not value.get("dockAtItinerary", {}).get("visible"):
            fails.append("行程页 Dock 实际不可见或尺寸为 0：%r（不是“DOM 里有 5 个 a”就算通过）" % (value.get("dockAtItinerary"),))
        if not all(value.get("dockLinksVisibleAtItinerary") or []):
            fails.append("Dock 内有不可见的导航项：%r" % (value.get("dockLinksVisibleAtItinerary"),))
        if not value.get("railFields") or not value.get("planeFields"):
            fails.append("车票卡或机票卡 DOM/字段不完整")
        if value.get("daytabs") != value.get("daycards") + 1:
            fails.append("Day tab 数 %r 与日卡数 %r 不一致（应多一个「全部」）" % (value.get("daytabs"), value.get("daycards")))
        if expect_days and value.get("daycards") != expect_days:
            fails.append("用户要求 %d 天，页面日卡 %r 张" % (expect_days, value.get("daycards")))
        train_count = int(value.get("trainCount") or 0)
        active_train = train_count if value.get("trainEnabled") else 0
        flight_enabled = bool(value.get("flightEnabled"))
        fold_count = int(value.get("foldCount") or 0)
        expected_fold = int(value.get("expectedFold") or 0)
        if fold_count < 1:
            fails.append("行程页没有可见的车票/机票折叠入口（.foldbtn[data-seg] 数量为 %r）" % value.get("foldCount"))
        if fold_count != expected_fold:
            fails.append("折叠入口数量 %r 与实际模式不匹配（%r 段车票 + 航班=%r，应有 %r；固定按钮/禁用模式多出来的就是硬编码）"
                         % (fold_count, active_train, flight_enabled, expected_fold))
        if not is_template and expected_fold and int(value.get("foldInDaycard") or 0) != expected_fold:
            fails.append("票务入口没有全部嵌进日卡时间线：%r/%r 个入口在 .daycard .tl 内（其余堆在日卡之后，手机上首屏看不到）"
                         % (value.get("foldInDaycard"), expected_fold))
        if not is_template and expected_fold and int(value.get("bottomFoldRows") or 0) > 0:
            fails.append("票务入口仍有 %r 个 .ticketfold-row 留在全部日卡之后（底部旧入口没有清掉）"
                         % (value.get("bottomFoldRows"),))
        if not is_template and expected_fold and int(value.get("foldInDaycardVisible") or 0) < 1:
            fails.append("日卡时间线内没有任何实际可见的票务入口（不能只检查 DOM 存在）：%r/%r"
                         % (value.get("foldInDaycardVisible"), expected_fold))
        bad_placement = [p for p in (value.get("foldPlacement") or [])
                         if any(str(v or "") for v in (p.get("vals") or [])) and not p.get("hit")]
        if not is_template and expected_fold and bad_placement:
            fails.append("票务入口没有贴在实际交通行后面（只看在 .tl 内不算）：%r；"
                         "每个入口的前一行必须包含对应车次/航班号或发车/起飞时间" % (bad_placement,))
        if not is_template and expected_fold and not value.get("foldInline"):
            fails.append("点击内嵌入口后 #tripFold 没有搬进当天 .daycard .tl，仍留在页尾：foldInline=%r"
                         % (value.get("foldInline"),))
        want_fold = [str(i) for i in range(1, active_train + 1)] + (["9"] if flight_enabled else [])
        if sorted(value.get("foldSegs") or []) != sorted(want_fold):
            fails.append("折叠入口段号 %r 与实际模式不匹配（应为 %r）" % (value.get("foldSegs"), want_fold))
        if not value.get("tripFoldOpen"):
            fails.append("点击车票入口后 #tripFold 没有打开")
        if active_train and (not value.get("railW") or float(value.get("railW") or 0) <= 0):
            fails.append("车票卡实际宽度为 0，票卡虽在 DOM 里但用户看不到")
        checks = value.get("segChecks") or []
        for c in checks:
            if not c.get("clicked") or c.get("active") != c.get("seg") or not c.get("foldOpen"):
                fails.append("第 %s 段车票入口没有切到对应票段：%r" % (c.get("seg"), c))
        if active_train and len(checks) != active_train:
            fails.append("实际车票段有 %r 段，但只走了 %r 段入口" % (active_train, len(checks)))
        if not flight_enabled and value.get("flightEntry"):
            fails.append("航班模式已关闭，却仍然生成了航班折叠入口（动车行程不能出现航班入口）")
        if flight_enabled and not value.get("flightEntry"):
            fails.append("航班模式开启，却没有航班折叠入口 a.foldbtn[data-seg=\"9\"]")
        if value.get("tkPlaneBtn", {}).get("exists"):
            fails.append("车票卡出现「✈️ 航班座位」按钮 #tkPlaneOpen：用户要求高铁/火车板块不要有航班座位按钮")
        if value.get("tkPlaneBtnAfterFold", {}).get("exists"):
            fails.append("打开票卡后仍出现「✈️ 航班座位」按钮 #tkPlaneOpen：用户要求高铁/火车板块不要有航班座位按钮")
        if not flight_enabled:
            if value.get("plane0"):
                fails.append("航班模式已关闭，#planeCard 仍然可见（动车行程不能出现航班信息）")
            if value.get("tkPlaneBtn", {}).get("visible"):
                fails.append("航班模式已关闭，#tkPlaneOpen 仍然可见（动车行程不能出现航班跳转按钮）")
            if value.get("tkPlaneBtnAfterFold", {}).get("visible"):
                fails.append("航班模式已关闭，打开票卡后 #tkPlaneOpen 仍然可见（动车行程不能出现航班跳转按钮）")
        if not value.get("trainEnabled"):
            if value.get("rail0"):
                fails.append("车次模式已关闭，#railCard 仍然可见（航班行程不能出现动车信息）")
            if value.get("tkRailBtn", {}).get("visible"):
                fails.append("车次模式已关闭，#tkRailOpen 仍然可见（航班行程不能出现动车跳转按钮）")
            if value.get("tkRailBtnAfterFlight", {}).get("visible"):
                fails.append("车次模式已关闭，打开航班卡后 #tkRailOpen 仍然可见（航班行程不能出现动车跳转按钮）")
        if value.get("lastTrainSeg"):
            if not value.get("lastTrainRail") or value.get("lastTrainPlane"):
                fails.append("从机票切回第 %s 段后票卡状态错误：rail=%r plane=%r" % (value.get("lastTrainSeg"), value.get("lastTrainRail"), value.get("lastTrainPlane")))
            if value.get("lastTrainActive") != value.get("lastTrainSeg"):
                fails.append("从机票切回第 %s 段后，当前高亮段是 %r（第 4 段以后也必须能切回）" % (value.get("lastTrainSeg"), value.get("lastTrainActive")))
        if value.get("budgetN"):
            try:
                bn = int(value.get("budgetN"))
            except Exception:
                bn = 0
            if bn and int(value.get("budgetMembers") or 0) != bn:
                fails.append("预算页人数选择器为 %r，但成员勾选只有 %r 个" % (value.get("budgetN"), value.get("budgetMembers")))
            if bn and ("%d 人共享记账" % bn) not in (value.get("budgetHero") or ""):
                fails.append("预算页标题没有跟随人数 %d：%r" % (bn, value.get("budgetHero")))
            if bn and value.get("ticketPax") and str(value.get("ticketPax")) != str(bn):
                fails.append("票卡同程人数 %r 与预算页人数 %r 不一致（默认人数不能写死 4）" % (value.get("ticketPax"), value.get("budgetN")))
            if bn and value.get("ticketPaxAfterClear") and str(value.get("ticketPaxAfterClear")) != str(bn):
                fails.append("清空票据后同程人数回落到 %r，没有保持实际 %r 人" % (value.get("ticketPaxAfterClear"), bn))
        expected_tabs = active_train + (1 if flight_enabled else 0)
        expected_tab_data = [str(i) for i in range(1, active_train + 1)] + (["9"] if flight_enabled else [])
        if value.get("ocrSegTabs") != expected_tabs:
            fails.append("OCR 票段 tab 数 %r 与实际模式不匹配（车次 %r + 航班=%r，应为 %r；不固定 3 段）"
                         % (value.get("ocrSegTabs"), active_train, flight_enabled, expected_tabs))
        if value.get("ocrSegTabData") != expected_tab_data:
            fails.append("OCR 票段 tab 段号 %r 与实际段号不匹配（应为 %r）" % (value.get("ocrSegTabData"), expected_tab_data))
        if value.get("trainEnabled") and (not value.get("rail0") or value.get("plane0")):
            fails.append("进入行程页默认票卡状态错误：rail=%r plane=%r" % (value.get("rail0"), value.get("plane0")))
        if flight_enabled and not value.get("trainEnabled") and (value.get("rail0") or not value.get("plane0")):
            fails.append("航班-only 行程默认票卡状态错误：rail=%r plane=%r" % (value.get("rail0"), value.get("plane0")))
        if flight_enabled:
            if value.get("railAfterPlane") or not value.get("planeAfterPlane"):
                fails.append("点机票入口没有先隐藏高铁卡：rail=%r plane=%r" % (value.get("railAfterPlane"), value.get("planeAfterPlane")))
            if value.get("trainEnabled") and (not value.get("railBack") or value.get("planeBack")):
                fails.append("机票卡回切高铁失败：rail=%r plane=%r" % (value.get("railBack"), value.get("planeBack")))
        if value.get("spotCount", 0) < 1:
            fails.append("页面没有 v-spot-* 景点详情页，打卡指引必然点不进内容")
        for s in (value.get("spotChecks") or []):
            if s.get("on") != s.get("id") or not s.get("visible") or not s.get("wrapVisible"):
                fails.append("景点详情 %s 进入后不可见/尺寸为 0：%r（打卡点进去空白，常见于被隐藏父层包住）" % (s.get("id"), s))
            elif int(s.get("text") or 0) < 20:
                fails.append("景点详情 %s 正文只有 %r 个字符，像是空白页" % (s.get("id"), s.get("text")))
        sb = value.get("spotBack") or {}
        if not sb.get("exists") or not sb.get("visible"):
            fails.append("景点详情没有真实可见的「返回上一级」按钮：%r（原版功能被删/被隐藏父层带走）" % sb)
        elif sb.get("from") and sb.get("view") != "v-spots":
            fails.append("景点详情点「返回上一级」没有回到 v-spots（实际 %r，入口时 %r）" % (sb.get("view"), sb.get("from")))
        if value.get("scrollStart", {}).get("y") != 420:
            fails.append("测试初始滚动没有到 420：%r" % value.get("scrollStart"))
        if value.get("topStart", {}).get("y") != 0 or value.get("backTop", {}).get("y") != 0:
            fails.append("初始顶部切走再切回没有回顶部：topStart=%r backTop=%r" % (value.get("topStart"), value.get("backTop")))
        if value.get("back", {}).get("y") != 420:
            fails.append("行程→美食→行程没有回 420：%r" % value.get("back"))
        if value.get("homeBack", {}).get("y") != 420:
            fails.append("行程→首页→行程没有回 420：%r" % value.get("homeBack"))
        if value.get("dockHome") != "v-home":
            fails.append("点击 Dock 首页没有回到 v-home（实际 %r）" % value.get("dockHome"))
        if not value.get("missingTip") or not value.get("missingStayed"):
            fails.append("导航到不存在板块时没有原地提示/停留：%r" % value)
        if fails:
            print("FAIL 用户视角走查未通过（%d 项）：" % len(fails))
            for f in fails:
                print("  - " + f)
            print(json.dumps(value, ensure_ascii=False, indent=2))
            return 1
        print("PASS 用户视角走查：首页仅 4 磁贴、行程票卡内 OCR、Dock/景点详情真实可见、票卡模式互斥、滚动记忆、缺失导航、Day tab 全部通过。")
        return 0
    finally:
        try:
            if ws:
                ws.close()
        except Exception:
            pass
        try:
            proc.terminate()
        except Exception:
            pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True)
    ap.add_argument("--expect-days", type=int, default=0)
    a = ap.parse_args()
    if not os.path.exists(a.html):
        print("FAIL 读不到文件：%s" % a.html)
        return 1
    return run(a.html, a.expect_days)


if __name__ == "__main__":
    sys.exit(main())
