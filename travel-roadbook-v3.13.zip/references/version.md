# 版本号规则与修改记录

## 规则（写死，从 v1.2 起严格执行）

1. **对外版本号 = 用户要求修改本 skill 的累计次数**，写成 `v{十位}.{个位}`：
   - 12 次 → `v1.2`
   - 13 次 → `v1.3`
   - 9 次 → `v0.9`
   - 10 次 → `v1.0`
   - 23 次 → `v2.3`
   （小于 10 次补 `0.`；个位数直接落在小数位上，不是「1.12」）
2. 每次修改都要动这四处，缺一处就算没改完：
   - 本文件的「累计次数」+1、追加一行记录；
   - 压缩包命名 `travel-roadbook-v3.13.zip`（跟着版本走）；
   - 生成的路书页面里可见的版本标识（`#wechatTip` 的「本页 vX.Y」——这里的 vX.Y 是**这本路书自己的**版本，不是 skill 版本）；
   - 交付二维码卡片的副标题（`--sub "v2.1 · 扫码在手机 / 微信打开"`）。
3. 代码里的 `v600-photo-js` / `v601-guard-js` / `v13-spotdetail-js` 这类**层编号只是构建批次标记**，不对外；对外只说 `v3.13`。
4. 修改次数只统计「用户明确要求改 skill 本体」的轮次；单纯要压缩包、问是否安装、确认是否最新，**不计**。

## 累计次数

**当前：43 次 → v3.13**

| # | 用户要求 | 落点 |
|---|---|---|
| 1 | 自定义背景下切板块，背景短暂变形 | v594–v599 转场层 |
| 2 | 还是轻微变形 + 背景高斯模糊太重 | `makeBlur` 把模糊降到 0 |
| 3 | 第三次反馈「没修好，还是会变形」 | v599 浮层零绘制，靠重复类名顶特异性 (0,6,2) |
| 4 | 切板块时白幕盖住背景 + 背景跟着左右滑 | `body.hasbg .view.v512-in` 透明化 + 伪元素 `content:none` |
| 5 | 「你真的解决了吗，主要在浏览器内打开」 | 无头 CDP 逐帧取证流程写进 SKILL |
| 6 | 确认改的是 skill 不是单个行程 | 改 `assets/template.html` + 文档，不改链接 |
| 7 | 是否已安装、要不要重启 | 明确 `.user_skills` 即安装位，改完即生效 |
| 8 | 要 skill 压缩包 | 打包流程与排除 `.bak` 规则 |
| 9 | 确认是最新完整版 | 解包比对 + 脚本数校验 |
| 10 | 景点打卡要能显示图、行程页必须是实拍不许 AI 图 | V6.00 实拍硬规则、`V600_ALIAS`、`.v46-shot` |
| 11 | Workbody 四条（南京示例数据 / 图源太少 / 点行程不能滑 / 别的 AI 也能用） | 整套替换清单 + 抓图/写入/自检脚本 + `v601-guard-js` |
| 12 | 二维码太素，要卡片式 | `make_qr.py` 重写为卡片码，规格进 SKILL |
| 13 | 「景点打卡指引点进去还是没有景点图片」 | v1.3：详情页补实拍头图（`v13-spotdetail-js`）；顺带修掉 `fetchSpotPhoto` 内嵌图不查别名、以及一开页就并发抓十几张图 |

| 14 | 深色「Day 1」看不清（浅色也要清楚）+ 景点页「返回/关闭」按来路走 | v1.4：`v14-fix-js`（选中标签深青底白字、待出发徽标奶黄底深棕字；导航栈 + 返回条改挂 `data-v14-go`；进详情前给热度榜弹层拍快照，返回可还原） |

| 15 | 景点指引的图要和行程顶部一样：自动识别景点，再去小红书 / 高德 / 美团 / 携程 / 飞猪 / 百度 / 维基 / 360 搜图 | v1.5：`fetch_spot_photos.py` 增 搜狗 + 百度百科两个直连源，8 家平台 `site:` 站内检索全部默认开跑；三处（行程顶图 / 热度榜缩略图 / 详情页头图）共用 `V543_IMGS`+`V600_ALIAS` 写死进 SKILL |

| 16 | 7 天行程顶部只显示 4 个 Day 按钮、其余天堆在下面；点景点打卡回首页 | v1.6：`buildTabs` 改为按 `.daycard` 数量自动生成（不再写死 4 天），标题自动 `Day 1–N`；新增 `v15-anyday-js` 老页面兜底重建 tab；`__navTo` 对缺失板块原地提示不跳首页；`check_demo_leftovers.py` 增结构闸门（缺板块/Dock 指空判失败） |

| 17 | 天数必须是变量，不许写死 7/8 天；加一条红线：所有大模型严格执行 skill、禁止删改框架 | v1.7：SKILL 顶部新增「红线」四条（天数变量化 / 板块与功能禁止删改 / 导航目标必须存在 / 交稿必须自检）；`check_demo_leftovers.py` 增「写死 4 天代码」「没有 .daycard」「四天全部显示」三项硬检 |

| 18 | 提高兼容性，让不擅长写码的模型也能顺利执行 | v1.8：新增 `scripts/verify_roadbook.py` 一键自检（板块/Dock/天数/示例残留/JS 语法，FAIL 时给修法）；SKILL 增「傻瓜执行清单」5 步；日卡选择器容错 `.daycard / [data-day]`，`#dayTabs` 缺失时自建 |

| 19 | 再加一条红线：所有大模型必须严格、完全执行 skill 的全部功能 | v1.9：红线新增「功能必须全量实现」（Curve Day tab / 实拍图 / 热度榜 / 美食三 tab / 返回条 / Dock / 滚动记忆 / 背景 / 票据 / 记账 / 导览图 / 二维码，禁止删改或空壳）；`verify_roadbook.py` 增 9 项功能标记硬检 |

| 20 | skill 里不能保留南京行程的详细内容，只留框架 | v2.0：模板清空 `S/F/SPOTS`、`V543_IMGS`、`V600_ALIAS`；4 张日卡换成占位卡；8 个 `v-meal-*` 餐次页改成静态中性骨架（没有 `var MEALS`）；可见文案里的地名/日期/价格全部通用化；体量从 3.85MB 降到 1.97MB；38 个板块与全部交互保留 |

| 21 | 模板里连注释也不能留示例地名 | v2.1：删掉 4 处含示例地名的注释；脚本里残留的地名（浏览器标题兜底、抢票提醒、热度榜来源文案、主题名、官方导览图标签）统一换成通用词；`check_demo_leftovers.py --strict-code` 从「48 词全过 + 27 处代码残留」变成 **0 残留** |

| 22 | 景点详情页必须存在 / 首页必须有 `#rbVer` / 热度榜不许写死杭州南京 | v2.2：`verify_roadbook.py` 增三项硬检；`check_details()` 逐页查 `v-spot-*` 正文、hero、实拍图位 |

| 23 | 切板块回来弹到底部/中部 | v2.3：新增 `v23-scrollfix-js`，导航前保存位置（0 也算有效），落地后六次校正；目标页更矮时按顶部处理 |

| 24 | 顺路/不顺路美食没区别 | v2.4：新增 `v24-foodroute` 按 `g` 的 Day 范围 + 城市比对日卡正文；本地页只渲染 `route:0`；新增 `#v46-near` 附近美食 |

| 25 | 红线要更严格，不许其他模型偷工减料 | v2.5：`verify_roadbook.py` 重写为多层硬闸门（板块≥30 / Dock≥5 / 详情页 / 图片 / 版本 / 美食 / 占位 / 语法） |

| 26 | WorkBuddy 新版首页左缘多一个尖箭头；7 天行程变成 Day 1–16、双数空白 | v2.6：`buildTabs` 与 `v15-anyday-js` 的日卡统计从 `.daycard, [data-day]` 改为只认 `.daycard`（老页面兜底 `.card[data-day]`），tab 判定改 `n===cards.length`；模板/样本同步修；`verify_roadbook.py` 新增并集选择器、`n>=`、标题天数不一致、`</script>` 后裸 `>` 四类硬检，以及 `--expect-days N`（用户说几天就卡几天）；模板不再把 `body[data-day]`/`.v514-art[data-day]` 当日卡 |

| 27 | 图1 红框下隐约图片 / 两天景点图找不到 / Day 按钮点一下变深色 | v2.7：`v27-fix-css` 隐藏 `.v50-wash`/`.v50-mid`/`.v50-dayart` 装饰底纹（深/浅同规则）；`findSpot` 增 2–4 字名称前缀兜底；`v27-fix-js` 从页面自身 `var SPOTS` 解析景点名，自动补 `V600_ALIAS` 城市级别名并逐张补 `.dimg` 封面；Day tab 改白底深字 + 1px 描边 + 3px 外环 + 底部 3px 色条，不再深色填充；`verify_roadbook.py` 增 v27 标记与日卡图 key 数硬检 |

| 28 | WorkBuddy 反馈：v2.7 空白模板清空示例数据时把 `#railCard` / `#planeCard` / `#tkForms` 整块 HTML 删掉，只剩 JS/CSS；`renderRail()` 找不到元素直接 return，OCR 识别出的车次/检票口/座位无处可写；车票座位还写死 4 人（本次 5 人） | v2.8：`assets/template.html` 补回真 HTML（`#railCard`、3 段 `#tkForms`、`#planeCard`、`#tkSeats`、`#tkNo`、`#tkGate`、`#tkEdit`）；每段只放 1 行乘客模板，由 `buildPax()` 动态克隆到 8 行、`applyPax()` 按人数显示；`segData()` 改为按页面实际 `.paxrow` 读取，删掉 `for(i=1;i<=4;i++)`；`renderRail()` 不再写「4 人」；OCR 页补 `#segtabs`；车票/机票 OCR 都能回填；`verify_roadbook.py` 增票卡 DOM、座位字段、`renderRail()`/`planeHead()` 硬检，并拦截写死 4 天的装饰循环 |

| 29 | 复查票卡回填：要求车票 OCR 同时能填航班号/日期/机场/登机口/值机柜台/座位舱位；座位按 1–8 人动态；`verify_roadbook.py` 不能出现 PASS 空壳；并加红线要求所有模型严格完整执行、禁止删改 | v2.9：修复 `planeCard` 手动填按钮只在 `if(!act)` 内绑定的问题（静态 `.v44-act` 导致按钮无事件，现幂等绑定）；`showSeg` 用 important 隐藏修复 `#railCard` 的 `display:flex!important` 冲突；`buildPax`/`applyPax` 实测 8 行克隆、5 人显示；OCR 同时填车票/航班；`verify_roadbook.py` 票卡 DOM/3 段字段/航班字段/写死 4 行/写死 4 天硬检；SKILL 新增第 13 条红线「所有大模型严格完整执行、禁止删改」，红线总数 13 |

| 30 | 复查发现时间线 48 个地点全是纯文本、0 个高德链接；WorkBuddy 两次改版后版本号仍是 v0.1，自检只查格式不查递增 | v3.0：模板新增 `v30-timeline-nav-js`（从 `S`/`SPOTS`/`V600_ALIAS` 读地名，自动给时间线 `.tl .c` 补 `uri.amap.com` 链接，只补没有链接的条目）；`verify_roadbook.py` 新增 `check_timeline_nav()`，按日卡检查时间线是否 0 链接，并新增 `--expect-version` / `--prev-version`，版本没递增或不是用户要求版本直接 FAIL；SKILL 新增第 14 条红线「时间线导航不许漏 + 版本号改一次必须递增」，红线总数 14 |

| 31 | 审查模板发现 WorkBuddy 仍能看到南京/杭州示例详情、餐厅表、官方导览图与示例高德链接；`check_demo_leftovers.py` 漏检编码 URL；Day 标签被 v2.7 白底描边覆盖，和原版路书不一致 | v3.1：模板把示例地名/餐厅/路线/车次/日期/`当地…` 文案全部泛化，110 个静态高德 `keyword` 与 757 个 `city` 参数清成通用值，4 张官方导览图大 JPEG 换透明占位，`v-fuzimiao`→`v-oldstreet`、`v-official-qixia`→`v-official-map3`；`check_demo_leftovers.py` 词表 48→80，新增 `url_query_text()` 对 `keyword/city/query/q` URL 解码后检查；`verify_roadbook.py` 空白模板 <1.5MB 放行、`REQUIRED` 扩到 10 个板块、`FEATURES` 增补 5 个板块、`check_timeline_nav()` 遍历同一日卡的所有 `.tl`、`check_version()` 比对二维码副标题；Day 标签去掉 v2.7 白底描边覆盖，恢复原版深青选中 + 白字，保留「待出发」奶油徽标 |

| 32 | 复查发现“PASS 是假干净”：模板还留着旧餐次/街区/景点详情、`DEMO` 注释、首页可见 `V5.62` 构建号；`THEME` 写死 4 个旧主题；`check_demo_leftovers.py` 词表漏掉餐厅/街巷/菜品/旧 ID；`verify_roadbook.py` 默认不带 strict，容易放行空壳 | v3.2：`assets/template.html` 的 8 个 `v-meal-*`、13 个 `v-spot-*`、步行图、总览图、4 个官方导览图改成中性骨架（保留 section/`.hero`/`data-img`/`.fcard`/导航按钮）；删除 3 处 `DEMO` 注释与首页可见 `V5.62`；`THEME` 改为 `themeOf(i)` 从 `data-theme` 读取；`check_demo_leftovers.py` 词表 80→143（补餐厅/街巷/菜品/旧 ID/旧主题），`verify_roadbook.py` 的 `check_leftovers()` 默认 `--strict-code`，`FEATURES` 增“按餐次餐厅页 / 预算明细页”；空白模板只认文件名含 template 的模板，生成的 `路书.html` 若 S/F/SPOTS 全空且 <1.5MB 按空壳 FAIL；`go()` 对显式不存在的板块原地提示、不再静默回首页；红线新增第 15 条“模板只许保留框架，示例详情/注释必须清空” |

| 33 | 点「返程航班 / 值机 / 航班座位」的机票入口，页面先显示 `#railCard` 的高铁座位，用户以为进错窗口；同时板块切换后滚动位置会跑到页尾/中部 | v3.3：`assets/template.html` 的 `showPlane` 入口改为第一次点击强制 `showSeg(9)`（先隐藏 `#railCard`、再显示 `#planeCard`），第二次点击才收回到车票卡；进入行程页补 `showSeg(curSeg)`，高铁卡与机票卡不再同时显示；另一处 capture 处理器同步用 `applySeg(9)`；旧 `go()` 核心不再在转场动画里写 `scrollMemo`，`v23` save 只在目标板块落地后保存，修掉 2843 大数覆盖；`FEATURES` 增“机票入口先切机票卡 / 默认只显示当前票卡”；`check_demo_leftovers.py` 词表 143→144（补 `V5.62`），模板内 V5.62 构建注释已中性化；SKILL 新增第 16 条红线“机票入口必须先显示机票卡，禁止先显示高铁卡”，红线总数 16 |

| 34 | WorkBuddy 为补票据识别入口，在首页加了第 5 个磁贴「票据识别」，旧 `verify_roadbook.py` 仍打印 PASS；用户要求加强自检种类、交叉检查、用户视角走查，并检查旧功能是否丢失 | v3.4：模板首页改为 **4 个 `.tiles` 磁贴 + `.tiles` 外 `a.v63-ocr-entry` 快捷条**（`data-nav="v-ocr"`，文案「🎫 车票 / 机票识别」），不加第 5 个磁贴；`verify_roadbook.py` 新增 `check_home_contract()`（`.tiles` 正好 4 个、目标固定 `v-prep/v-itinerary/v-budget/v-faq`、`v-ocr` 不得进磁贴、首页必须有 `v63-ocr-entry`）和 `check_ocr_module()`（`#v-ocr`/`#tkimg`/`#tktext`/`#tkparse`/`#tkocr`/`#tkclear`/`#segtabs`/3 段 `t{1..3}_no`）；Dock 改固定 5 项；新增 `scripts/verify_walkthrough.py`（无头 Edge+CDP 用户视角走查：首页 4 磁贴、OCR 快捷条可点、票卡双向、滚动记忆、缺失导航、Day tab）；`__navTo` 最后一层补缺失板块原地提示；SKILL 新增第 17 条首页红线、第 18 条双层验收，红线总数 16→18；本轮补：OCR 上传控件限定 `#v-ocr`、`t{1..3}_no` 仍全局检查、`#tripFold` 必须有可见 `foldbtn` 入口、Dock 首页点击检查、走查改动态端口 |

| 35 | 用户指出票卡永远固定「3 段车票」：实际行程可能是 1/2/3/4 段车次，甚至只有航班；固定 3 段会让票卡入口、OCR 票段、保存/清空、自检与走查全部和真实行程不符 | v3.5：模板 `.trainseg` 改为 **1 段骨架**；`buildTicketEntries()` 按 `#tkForms .trainseg` 实际数量动态生成 `.foldbtn[data-seg=N]`，`buildSegTabs()` 动态生成 OCR 票段（无车次时给航班段 `9`，`#planeCard[data-flight="0"]` 时无航班入口/航班 tab）；`keys`、`tkclear`、`setSeg` 不再写死 `1..3`；`verify_roadbook.py` 从硬检 `t{1..3}`/1/2/3/9 改为「段号连续 1..N、每段字段完整、至少车次或航班之一」；`verify_walkthrough.py` 按实际段数逐个点开并核对 `trainseg.on`，折叠入口数必须等于实际车次段数 + 航班入口；SKILL 第 12 条、framework 票据章节同步改为 1..N；包名 `travel-roadbook-v3.5.zip` |

| 36 | 用户要求横向检查还有没有与“固定 3 段车票”同类的写死数量/写死下标问题，范围覆盖车次段、航班段、人数、天数、入口数量 | v3.6：`applySeg()` 从 `seg===1||2||3` 改为 `seg>0&&seg!==9`，第 4 段以后从机票切回车票不再失效；票卡/预算默认人数不再回落 4，`defaultPaxCount()` 从页面真实 `#spNames` 姓名数与 `#spN` 选择值推断，`#v543Pax/#v543PaxAir`、`tkclear`、`getNum(KEY_PAX)` 全部改用真实人数；预算可见文案 `÷4`、云端“4 人共享”、清空“4 个人”改为动态；行前背包数、打车段数、应急地图张数也改为 `N`；`verify_roadbook.py` 增加 `seg===1||2||3` 静态拦截，景点详情最低数从 3 改为 1（不塞假景点）；`verify_walkthrough.py` 增加“机票 → 最后一段车票”切回、预算人数/成员/票卡人数/清空后人数四处一致检查；包名 `travel-roadbook-v3.6.zip` |

| 37 | 别的大模型跑出的福建 5 日路书没有 Dock、打卡详情空白；首页仍多第 5 个 OCR 入口；动车/航班票卡互串；验收只看标记与 `el.click()`，不看 DOM 嵌套和渲染可见性；且不许无授权删旧代码 | v3.7：模板首页删除 OCR 快捷条（只保留 4 磁贴），票据识别入口并回 `#railCard`/`#planeCard` 的 `v63-ocr-entry` 按钮；新增 `data-train/data-flight`、`trainEnabled()/flightEnabled()`、`syncTicketMode()`、`showSeg()` 模式互斥、`buildTicketEntries()/buildSegTabs()` 条件生成（双模式不漏航班 tab）；跨两个脚本 IIFE 用 `window.__rbTrainEnabled/__rbFlightEnabled` 导出，避免 `ReferenceError`；`verify_roadbook.py` 增 `check_dom_nesting()`（HTMLParser section 栈，抓嵌套/未闭合/多余闭合）与 `check_ticket_mode()`，首页契约反向卡「无首页 OCR、行程内必须有 OCR」；`verify_walkthrough.py` 增 `vis()/info()`（祖先链 + computed opacity + 实际尺寸），实测 `#dock`、每个 `v-spot-*` 详情、票卡模式互斥与 OCR 可见性，CDP 超时 40s→120s；`references/framework.md` 同步首页/票卡/验收章节；包名 `travel-roadbook-v3.7.zip` |

| 38 | 复查 v3.7 闸门本身：未闭合 section 不报、重复 data-day / 重复 Dock 锚点漏检、模板固定回退 4 人未真正修掉；景点占位城市、票卡模式标记与真实字段、长 S 数组仍有只用标记放行的风险 | v3.8：`verify_roadbook.py` 的 section 栈在 `feed/close` 后把剩余栈写入 `unclosed`（删最后一个 `</section>` 现在 FAIL「1 个未闭合」，嵌套 fixture 同时报 37 嵌套 + 38 未闭合）；`check_days()` 增加 `days == 1..N` 检查（`1,1,2,3` 现在 FAIL）；`check_structure()` 按真实 `a[data-dock]` 锚点数计数并检查 5 个目标不重复（重复「首页」现在 FAIL）；模板 `defaultPaxCount/defaultPax/initBudget` 的 `n||4`、`:4`、`inferred=4` 全部改为按真实姓名/选择推断，无姓名/无选择器不再回退 4；`check_ticket_mode()` 增加 data-train=1 必须有 t{N}_no、data-flight=1 必须有 fl_no；`check_spots()` 按 S 实际 c 城市对照 cities 分组，不预设固定目的地；`check_details()`/`check_food()` 按最近 `];` 截取数组，不再固定字符数；`verify_walkthrough.py` 增加景点详情「返回上一级」实测并修 docstring；模板静态、严格示例与用户走查全部 PASS |

| 39 | 用户指出 v3.8 的景点热度榜检查仍把某个示例城市当固定规则；目的地是用户输入变量，不能写死任何城市 | v3.9：`check_spots()` 删除固定示例城市硬编码，改为从 `S` 数组提取本次真实 `c` 城市，再与 `cities` 分组对照；分组出现 `S` 之外任何城市（含模板历史示例城市或占位「目的地」）→ FAIL；空白模板 `S=[]` 仍允许占位。`SKILL.md` 第 8 条、静态章节、`--allow` 示例和白名单说明改为目的地中立；`framework.md` 补 4.37；用任意临时城市字符串和过期分组三种 fixture 验证：任意本次城市 PASS、分组与 S 一致 PASS、过期分组 FAIL；模板静态、严格示例、用户走查均 PASS |
| 40 | 车票/航班识别入口全部堆在 5 张日卡之后，手机上滑到当天行程完全看不到；用户要求像原版路书一样嵌进当天 `.daycard .tl` 的交通行后面 | v3.10：模板新增 `rbInsertInlineTicket()`，按 `t{N}_no`/`fl_no` 与时间线文本匹配后，在交通行后插入 `li.foldli > a.foldbtn[data-seg=N]`；`buildTicketEntries()` 清理旧 `.ticketfold-row` 后全部内嵌，仅在找不到目标时保留日卡后兜底；`load()` 后重建一次，恢复 localStorage 后仍能匹配；对旧页增加 `typeof trainEnabled` 兼容。`verify_roadbook.py` 增 `rbInsertInlineTicket` 功能标记与生成页硬检；`verify_walkthrough.py` 增 `foldInDaycard`/`foldInDaycardVisible`，要求入口数等于实际段数、全部在 `.daycard .tl` 内且当前页至少一个真实可见；`#tripFold` 明细卡保留在底部，点击内嵌入口时把整张卡搬进当天 `.daycard .tl` 再展开。模板静态与用户走查 PASS |
| 41 | 车票/航班入口找不到目标时仍会生成日卡之后的 `.ticketfold-row`；旧页没有 `trainEnabled()` 时简单默认“有车”，可能给航班-only 旧页多生成车票入口；验收只检查主入口，不检查底部旧入口是否清干净 | v3.11：`buildTicketEntries()` 增加 `rbInsertFallbackTicket()`，没有匹配交通行时把入口追加到第一张有 `.tl` 的日卡时间线，绝不回到日卡之后；只在存在 `.daycard .tl` 时清理旧 `.ticketfold-row`，空白模板保留静态骨架；新增 `rbTrainOnCompat()` / `rbFlightOnCompat()`，优先读本页模式函数和 `window.__rb*Enabled`，再用 `data-train/data-flight`、真实车次/航班字段判断，避免旧页航班-only 被补出车票入口；`verify_roadbook.py` 增 `rbInsertFallbackTicket`、`rbTrainOnCompat`、`rbFlightOnCompat` 功能标记；`verify_walkthrough.py` 增 `bottomFoldRows`，生成页底部旧入口必须为 0；模板静态/走查 PASS，无匹配目标 fixture 与旧页真实代码替换 fixture 已验证 |
| 42 | 用 skill 生成的福建 5 日路书里，三条票务入口全部落在 Day 1 末尾；旧 `.foldli` 没有 `data-rb-inline-ticket`，当前代码误判为已放好；自检只看“在 `.tl` 内”，没看是否紧跟对应交通行 | v3.12：`rbClearInlineTickets()` 连同旧 `.daycard .tl .foldli` 一起清理；`rbInsertInlineTicket()` 不再把无 `data-rb-inline-ticket` 的旧条目当成已放好，先移除再按 `rbTicketTarget()` 重新定位；`verify_walkthrough.py` 新增 `foldPlacement`，逐条核对入口前一行是否包含对应车次/航班号或发车/起飞时间，并在点击每个入口前先切到它所属的 Day tab；模板静态/走查 PASS，修正后的福建页三条入口分别落到 Day 1 10:04、Day 2 13:53、Day 5 15:15，修正后页面走查 PASS；旧页原始版本只报 `foldPlacement` FAIL，证明新闸门能抓住原问题 |
| 43 | 车票/高铁卡里仍然出现「✈️ 航班座位」按钮，用户要求高铁/火车板块不要有航班座位按钮 | v3.13：模板移除车票卡的 `#tkPlaneOpen` 与「✈️ 航班座位」入口，只保留机票卡的「🚆 返回车票」；`syncTicketMode()` 不再处理车票卡航班按钮；`verify_roadbook.py` 的票卡检查改为硬拦 `id="tkPlaneOpen"`；`verify_walkthrough.py` 无论航班模式开关都检查 `#tkPlaneOpen` 不得存在；SKILL 第 16 条与用户走查说明同步；福建路书 v0.3 已移除该按钮并通过静态/走查 |
