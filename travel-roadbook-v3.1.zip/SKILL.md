---
name: travel-roadbook
version: 3.1.0
display_name: 旅行路书
display_name_en: Travel Roadbook
description_zh: 生成可交互的单文件 HTML 旅行路书，包含按天行程、景点实拍图、打卡详情、美食、记账、预算、导览与二维码等完整功能。
description_en: Create a single-file interactive HTML travel roadbook with day-by-day itineraries, real spot photos, spot detail pages, food, expense tracking, budget, guides, and QR delivery.
metadata:
  display_name: 旅行路书
  display_description: 生成可交互的单文件 HTML 旅行路书，包含按天行程、景点实拍图、打卡详情、美食、记账、预算、导览与二维码等完整功能。
  icon: ./assets/icon.png
  version: 3.1.0
description: 生成可交互的单文件 HTML 旅行路书（出行攻略页）。提供一个完整可运行的路书框架：行程路线图（按天 tab、景点/交通时间线）、机票火车票自动识别（含复兴号/和谐号车型识别）、高德导航与小红书跳转、美食/景点打卡、多人记账与预算、天气穿搭与出门清单、景区官方导览图等；并支持行程顶部景点图与「景点打卡·热度榜」的「自动识别景点 + 联网抓真实照片 + 构建期内嵌」（V6.00 起**景点图只允许实拍**，程序化插画不得顶替）。当用户要求制作旅行攻略/路书、把某趟行程做成可点击的网页版路书、或把既有路书框架改换成新目的地（只换内容不改框架）时使用。
---

# 旅行路书（Travel Roadbook）

**当前版本：v3.1**（= 你要求修改本 skill 的累计次数 31；规则见下节与 `references/version.md`）

本技能把一次多日行程做成**单文件 HTML 路书**：手机/电脑直接打开即用，所有板块、过渡动画、交互功能都内嵌在一个文件里，断网也能看正文（联网交互除外）。

## 版本号规则（写死，每次改动都要遵守）

- **skill 版本 = 用户要求修改本 skill 的累计次数**，写成 `v{十位}.{个位}`：12 次 → `v1.2`，20 次 → `v2.0`，21 次 → `v2.1`，22 次 → `v2.2`，23 次 → `v2.3`，24 次 → `v2.4`，25 次 → `v2.5`，26 次 → `v2.6`，27 次 → `v2.7`，28 次 → `v2.8`，29 次 → `v2.9`，30 次 → `v3.0`，31 次 → `v3.1`，9 次 → `v0.9`，10 次 → `v1.0`。不是「1.12」，也不是自造的 6.x。
- 每改一次 skill，三处同步：`references/version.md` 的次数与记录、压缩包名 `travel-roadbook-v3.1.zip`、skill 交付说明；**不要**把这个号写进生成的路书或二维码。
- **路书版本 = 这本路书自己被要求修改的累计次数，跟 skill 版本无关**：第一次交付 `v0.1`，第二次 `v0.2`，第十次 `v1.0`，第十一次 `v1.1`（不是 v10，也不是跟着 skill 的 v2.2）。版本号必须**标在首页**（`#rbVer` 徽标，例如 `<span class="tag" id="rbVer">v0.1</span>`），同时 `#wechatTip` 写「本页 v0.1」、二维码副标题写 `v0.1 · 扫码在手机 / 微信打开`——三处同号。用户没提修改就交付第一版，一律 v0.1。
- 代码里的 `v600-photo-js` / `v601-guard-js` 只是构建批次标记，不对外。
- 只统计「用户明确要求改 skill 本体」的轮次；单纯要压缩包、问是否安装、确认是否最新，不计。

## 红线（Red Line，违反任一条即判返工）

**判定标准：机器闸门 FAIL = 未完成。任何解释、口头保证、截图都不替代 PASS 输出；不许改 `verify_roadbook.py` 放行。**

这份 skill 是**框架 + 内容**的组合：框架（板块结构、导航、天数机制、既有功能）属于 skill 本体，**任何大模型都只有替换内容的权限，没有删改框架的权限**。

1. **天数必须是变量，禁止写死**。行程几天，就渲染几个 Day tab：模板与 `v15-anyday-js` 都只认页面里的 `.daycard` 张数（`N = document.querySelectorAll('#v-itinerary .daycard').length`），标题写 `Day 1–N`、`全部 N 天`；**禁止出现 `for(d=0;d<4)`、`Day 1–4`、`四天全部显示` 这类固定天数**。用户要 2 天就 2 个 tab，要 12 天就 12 个，不许「凑够 4 个」也不许「只显示前 4 个」。交稿自检必须带上用户明确说的天数：`python scripts/verify_roadbook.py --html 路书.html --expect-days N`，页面日卡数与 N 不一致直接 FAIL（用户说 7 天，页面就不能写 8 天）。
2. **板块 id 与功能禁止删、改、关**。至少保住 `v-home / v-prep / v-itinerary / v-spots / v-food / v-budget` 及各个 `v-spot-*` 详情页；Dock、返回/关闭、滚动记忆、自定义背景、实拍图链路（`V543_IMGS` + `V600_ALIAS`）、票据识别、记账、二维码这些既有能力，**只能换里面的内容，不许整块删除、不许改名、不许以「简化」为由关掉**。
3. **导航目标必须存在，且每一个景点都有详情页**。新增/改写任何「点进去」的入口（`data-nav`、`data-v46-go`、`data-v15-go`、`data-v564-go`、`data-dock`），落点必须是真实存在的 `section.view`；**`SPOTS` 里的每个景点 key 都必须能在打卡页点开**，不许只写榜单不建详情页。`__navTo` 找不到目标会原地提示并中止，`verify_roadbook.py` 会逐条列出不存在的目标并判 FAIL。
4. **功能必须全量实现，一条都不许少**。这份 skill 的每一项能力——行程 Day tab、景点实拍图（`V543_IMGS`/`V600_ALIAS`）、机位详情、景点打卡热度榜、美食三 tab、返回/关闭条、Dock、滚动位置记忆、自定义背景、票据识别、多人记账与预算、景区导览图、二维码——**所有大模型都必须完整执行**。禁止以「内容不一样」「简化一下」「这个模块用不到」「示例是别人的」为理由删掉、关掉、注释掉、或只做个空壳；只要用户没明确说「这一版不要这个功能」，就必须留。
5. **交稿前必须跑自检**：`python scripts/verify_roadbook.py --html 路书.html --expect-days N --prev-version v上一版 --expect-version v这一版` 必须打印 `PASS 可以交付`（它会顺带跑 `check_demo_leftovers.py`）。任何一项不过，不许说「做完了」。**改版不升版本号 = 没改完；第一版用 `--expect-version v0.1`，第二版必须 `--prev-version v0.1 --expect-version v0.2`。** 如果本次行程真的会去模板示例地名（如南京、杭州、夫子庙），追加 `--allow 南京,杭州,夫子庙`，只放行真实目的地，不许用 `--allow` 掩盖模板残留。
6. **切板块必须回到原来的位置，不许底部/中部乱跳**。从顶部切走再切回，必须还是顶部；在中间切走再切回，必须回到离开时的位置。`v23-scrollfix-js` 这一层禁止删：它在导航前保存位置（**0 也算有效位置**），落地后校正；旧位置比目标页最大滚动还大时按顶部处理。
7. **顺路美食必须按动线真区分，不许全标顺路**。默认页只放 `__v24Route` 判定为动线内的；`route:0` 或 `g` 含「本次未安排 / 需绕路」的必须进「本地美食 · 需绕路」页；两页**不许出现同一批卡片**。每条 `F` 至少写 `c`（城市）与 `g`（Day 范围），全标 `route:1` 直接算返工；`v46-near` 的「附近美食」入口（按定位搜高德 3 公里）也不许删。
8. **景点打卡不许交空壳**。热度榜必须按本次行程的景点分组，**禁止保留模板的杭州/南京分组**（`cities=['杭州','南京']` 一出现，新景点永远是「共 0 个点位」）；每个 `v-spot-*` 详情页至少要有标题、当天景点名、一张实拍图位；点「景点打卡指引」必须进得去、返回/关闭能按来路退回。`verify_roadbook.py` 会把「0 个点位」「无 .v46-rank」「data-nav 指向空气」全部判 FAIL。

9. **日卡统计只认 `.daycard`，禁止并集 `[data-day]`**。`body[data-day]` 是当前天的状态、`.v514-art[data-day]` 是日卡底部装饰层，**都不是日卡**；`buildTabs` 与 `v15-anyday-js` 两处选择器都必须是 `.daycard`（老页面兜底仅 `.card[data-day]`），tab 数量判定必须 `n===cards.length`。出现 `querySelectorAll('.daycard, [data-day]')`、`querySelector('.daycard, [data-day]')` 或 `if(n>=cards.length)` 直接返工——实测 8 张日卡会被算成 16 张，生成 Day 1–16，双数 tab 全空白。
10. **页面顶层禁止裸文本节点**。`</script>` / `<style>` 结束后不许留 `>`、`›` 这类游离字符；浏览器会把它渲染到屏幕左缘，看起来就是一个「尖尖的箭头」。`verify_roadbook.py` 会自动扫这种节点，命中就 FAIL。

11. **日卡封面必须有能命中的实拍图，禁止“今天有图、明天没图”**。`V543_IMGS` 的 key 数不得少于 `.daycard` 张数；`V600_ALIAS` / `SPOTS` 必须覆盖日标题里的城市级写法（如「广州」「稻城」「成都」）；生成页必须带 `v27-fix-js` 兜底层（从页面自身 `SPOTS` 解析名称前缀，运行时逐张补 `.dimg`）。任何一天出现「找图中 / 暂无实拍图」= 返工。禁止只在单个页面手改，必须改 `assets/template.html` 本体。

12. **票卡必须是真 HTML，禁止只留 JS/CSS**。清空示例数据时只许清 `value`，不许删节点：`#railCard`、`#tkForms`、`#planeCard`、`#tkNo`、`#tkSeats`、`#tkGate`、`#tkEdit`，以及每段 `t{1..3}_no/date/from/to/time/gate/note`、`t{1..3}_n1/c1/s1/k1`、`fl_no/date/from/to/time/gate/counter`、`fl_n1/s1/k1` 必须在页面里真实存在。车票 OCR 与机票 OCR 都必须能回填（车票填 `#railCard`，机票填 `#planeCard`）；乘客行数按识别到的座位条数/页面实际 `.paxrow` 动态显示（1–8 人），**禁止写死 4 行或 5 行**。`verify_roadbook.py` 会逐项硬检这些 DOM 与 `renderRail()` / `planeHead()`，缺一即 FAIL，绝不允许「自检 PASS 但功能是空壳」。

13. **所有大模型必须严格、完整执行本 skill 的全部功能，禁止删改**。不论模型能力强弱、任务多复杂、数据多难找，都只能按本文件与 `references/framework.md` 的框架换内容，**不许删板块、删票卡、删脚本、删 CSS、关功能、改 id、把交互改成静态页，也不许以「简化」「模板没有」「用不到」为借口偷工减料**。执行前逐条对照「必须保留的功能」，执行后 `verify_roadbook.py` 必须 `PASS`；任何一项没过就不算完成，禁止口头保证或只改单本路书冒充 skill 已修。**这一条对所有使用本 skill 的大模型生效。**

14. **行程时间线导航不许漏，版本号改一次必须递增**。每个 `.daycard` 的 `.tl` 至少要有 1 个 `uri.amap.com` 高德导航链接；景点/车站/机场名称不许只写纯文本，必须让用户点得动。模板的 `v30-timeline-nav-js` 会自动补链，**不许删**；如果删了，就必须逐天写静态高德链接。版本号方面：第一次交付 `v0.1`，用户每要求改一次就 `v0.2`、`v0.3`……第十次 `v1.0`；**不许改完还写 v0.1**。交稿必须跑 `--prev-version v上一版 --expect-version v这一版`，验证器会卡版本没有递增。

**这 14 条不是建议，是机器闸门。** `verify_roadbook.py` 不通过，就不许说「做完了」；它列出的每一项都要改完再复跑，不许挑着改、不许删检查项。当前硬检包括：

- **结构**：板块少于 30 个、Dock 少于 5 项、缺 `#dayTabs` → FAIL（防整块删框架）。
- **日卡**：`.daycard` 统计必须只认 `.daycard`；出现 `.daycard, [data-day]` 并集选择器、`if(n>=cards.length)`、`.daycard` 的 `data-day` 不连续、行程页标题 `Day 1–N` 的 N 与日卡数不一致 → FAIL。
- **顶层字符**：`</script>` / `<style>` 后出现裸 `>` 文本节点 → FAIL（手机左缘会多一个尖箭头）。
- **导航**：`data-nav / data-v46-go / data-v15-go / data-v564-go / data-dock` 任一目标不存在 → FAIL。
- **时间线**：非空白页的任一 `.daycard .tl` 没有任何 `uri.amap.com` 链接，且页面没有 `v30-timeline-nav-js` 自动补链层 → FAIL；每天至少 1 个导航，地名不许全是纯文本。
- **详情页**：`S` 数组里的 `d:'v-spot-*'` 目标不存在、`v-spot-*` 少于 3 个、详情页正文少于 80 字、没有 `data-img`/`v600-detail-photo`、没有 `.hero` → FAIL。
- **图片**：`V543_IMGS` 里一张 `data:image/` 都没有 → FAIL（不许全指望运行时联网）；非空白页的图 key 数少于 `.daycard` 张数 → FAIL（必有一天无图）。
- **版本**：首页没有 `#rbVer`、格式不是 `vX.Y`、与 `#wechatTip` 不同号、改了版却没有递增（`--prev-version` 不小于 `--expect-version`）→ FAIL。
- **美食**：`F` 有 4 条以上却全 `route:1` 或全 `route:0`、缺 `c:/g:/rests:`、缺 `v24-foodroute`、缺 `#v46-near`、本地页还 `groupHTML(on,…)` → FAIL。
- **票卡**：缺 `#railCard` / `#planeCard` / `#tkForms` / `#tkNo` / `#tkSeats` / `#tkGate` / `#tkEdit` / `t{1..3}_*` / `fl_*` 任一，或座位读取仍写死 4 行，或 `renderRail()` / `planeHead()` 被删 → FAIL（防「模板只剩 JS/CSS、OCR 无处可写」）。
- **占位**：非空白模板的正文出现 `TODO / 待补 / 待填 / 暂无内容 / 占位 / 示例城市 / 共 0 个点位` → FAIL。
- **v2.7 兜底层**：缺 `v27-fix-js`（日卡实拍兜底）或 `v27-fix-css`（隐藏旧装饰底纹 / 选中态）→ FAIL。
- **脚本与示例**：内联 `<script>` 逐个 `node --check`、`check_demo_leftovers.py` 退出码必须 0。

## 傻瓜执行清单（任何模型照抄，不许跳步）

> 目标：即使模型不会读代码，只按下面 5 步做，也能产出一份结构正确、板块齐全、天数正确、能扫码打开的路书。

1. **复制框架，不要重写**：把 `assets/template.html` 整份复制成 `路书.html`；只在里面替换内容，不新建 HTML、不删 `<section>`。
2. **行程写成「一天一张卡」**：每天一个 `<div class="card daycard" data-day="1">…</div>`，`data-day` 从 1 连续写到 N（N = 实际玩几天）。**不要写 `#dayTabs` 的内容**——tab 由脚本按日卡张数自动生成，你手写的会被覆盖或写死。
   - **同一步必须建景点详情页**：`SPOTS` 里每个 `k` 都要有 `<section class="view" id="v-spot-<k>">…</section>`，行程里的「📸 景点打卡指引」用 `data-nav="v-spot-<k>"` 指过去；打卡页的热度榜要用本次景点分组，**不要碰 `cities=['杭州','南京']` 这段旧代码**。少建一个详情页，就是图二那种「点进去提示板块不存在」。
   - **美食顺路/绕路分开**：`F` 每条写真 `c` 与 `g`，默认页只放动线内的；不在动线的 `route:0` 或 `g` 写「本次未安排」，只进「本地美食 · 需绕路」页，两页不重复。
   - **首页版本号**：在 `#v-home` 的 `.hero` 里放 `<span class="tag" id="rbVer">v0.1</span>`（第一版 v0.1，第二次 v0.2，第十次 v1.0）；`#wechatTip` 的「本页 v0.1」与二维码副标题同步，**不要写 skill 的版本号**。
   - **日卡选择器**：只写 `class="card daycard" data-day="N"`；**不要**把 `data-day` 挂到 `body`、装饰图 `.v514-art` 或其他非日卡元素上。生成后不要改 `buildTabs` / `v15-anyday-js` 的选择器，它们只认 `.daycard`。
3. **景点图走构建期**：
   ```bash
   python scripts/fetch_spot_photos.py --spots spots.json --out photos.json --preview preview
   python scripts/embed_photos.py --html 路书.html --photos photos.json --alias alias.json
   ```
   `spots.json` 一行一个景点：`{"k":"duke","name":"独克宗古城","q":"独克宗古城 转经筒 实拍"}`。
4. **交稿前跑一键自检（必做）**：
   ```bash
   python scripts/verify_roadbook.py --html 路书.html --expect-days N --prev-version v上一版 --expect-version v这一版
   ```
   看到 `PASS 可以交付` 才算完成；看到 `FAIL` 就按它列出的「怎么修」改，改完再跑一次。
5. **交付三件套**：路书链接 + 卡片二维码（`scripts/make_qr.py`，副标题写**这本路书自己的** `vX.Y`）+ skill 压缩包（压缩包写 skill 版本，两个版本号不许混）。
6. **版本自检**：`verify_roadbook.py` 会检查 `#rbVer` 是否存在、格式是否 `v0.1/v1.0`、与 `#wechatTip` 是否同号；改版时必须传 `--prev-version` 与 `--expect-version`，版本没递增、首页/微信提示不同号都直接 FAIL。
7. **日卡图自检**：每张 `.daycard` 的 `.dimg` 必须有实拍图（`data:image/jpeg;base64,...`），不许出现「找图中 / 暂无实拍图」；`v27-fix-js` 兜底层不许删。

**卡住时对照**：点入口回首页 = 目标板块被删了（跑第 4 步会指出缺哪个）；只有 4 个 Day = 日卡不足或写了 `for(d=0;d<4)`；景点没图 = `spots.json` 的 `k` 与 `V600_ALIAS` 没对上；**打卡页「共 0 个点位」= 热度榜还按模板杭州/南京分组，或 `SPOTS` 没填**；**点「景点打卡指引」提示「板块不存在」= 漏建 `v-spot-<k>` 详情页**。
**Day 1–16 且双数空白 = 日卡选择器把 `.v514-art[data-day]` 也当日卡了**（只改 `.daycard`，跑 verify 会直接指出）；**首页左缘多一个尖箭头 = `</script>` 后留了裸 `>` 文本节点**（删掉该字符）。

## 核心原则：框架与内容分离

`assets/template.html` 是完整可运行的**空白框架**（只保留板块与占位卡，不含任何具体行程内容）。生成新路书时：

- **只改内容**：目的地、日期、人数、景点名、交通/住宿/餐饮、预算数字、天气、提醒等。
- **绝不动框架**：CSS 变量与动画、板块结构、tab/转场/Dock、JS 交互逻辑（票据识别、记账、图片自动配图、小红书/导航跳转）一律原样保留。

切换不同景点地址时，框架不变，只有内容变——这正是本技能存在的意义。

## 内容必须整套替换：模板里的示例数据一个都不许留（V6.01 写死）

自 v2.0 起，`template.html` 已经**清空了所有示例行程内容**（`S` / `F` / `SPOTS` / `MEALS` / 内嵌图 / 别名全部为空，日卡只剩占位卡）。但你如果用旧模板、或在旧路书上改，就必须整块换成本次行程——实测踩过：某个 AI 发现「美食打卡三 tab 里是南京的数据」，处理方式是把整个模块删掉、换成静态「按餐次查看」11 页——**删模块 = 不合格**，正确做法是把数据换成这次行程的。

必须整块替换的清单（少一个都算没做完）：

| 数据块 | 位置 | 换什么 |
|---|---|---|
| `var S=[…]` | 行程页景点索引 | 景点名 / 城市 / 建议时长 / 顺路标签 |
| `var F=[…]` | 美食 | 餐厅名、人均、必点菜、位置 |
| **美食打卡三 tab** | `v46` 弹层 | 「按景点 / 按餐次 / 榜单」三视图里的全部条目（**必须保留三 tab 结构**） |
| `var SPOTS=[…]` + 机位面板 | `v-spot-*` | 每台机位的 hero、时间、光线、交通 |
| 逐日时间线 | `#v-itinerary .daycard` | 每天的站点、车次、门票、住宿 |
| 概览 / 预算 / 记账默认值 | `v-home`、`v-budget*` | 人数、总预算、分类 |
| 官方导览图 | `v-official*` | 换成本次景区自己的官方图/信息页（不许留「西湖导览图 / 钟山线路图」） |
| 首页 hero + `<title>` | 顶部 | 目的地、日期、人数 |

空白模板里数据块是 `var S=[]; var F=[]; var SPOTS=[]; var MEALS=[];`，生成时必须按本次行程把四个数组填满（不是留空交付）。

交稿前必须跑自检（纯 Python，任何 AI 都能跑）：

```bash
python scripts/check_demo_leftovers.py --html 路书.html
# 行程真的会去这些地方（比如本来就去南京）时，把词列进白名单
python scripts/check_demo_leftovers.py --html 路书.html --allow 南京,夫子庙
```

退出码 1 = 还有**用户可见**的示例残留，不许交付。检查分三层：正文/标题（硬失败）、数据块（硬失败）、代码里的旧命名（只提示，比如 `#v-fuzimiao` 被复用成「独克宗古城步行图」这种就没事）。

## 生成流程

1. 先读 `assets/template.html`，理解框架结构（详见 `references/framework.md`）。
2. 确认行程数据：天数/日期、城市、每天主景区、交通（车次/航班）、住宿、餐饮、预算、人数。
3. 在模板上做**内容替换**：改 `<title>`、首页 hero、行程数据、SPOTS 词库、美食/机位数据、预算与记账默认值。
4. 为每天的主景区准备封面图（见下）。
5. 输出**单个 `.html` 文件**（UTF-8，无外部依赖），用 `present_files` 交付。

## 景点图硬规则：只允许实拍（V6.00 起写死，任何一版都不许回退）

用户原话：「行程版景点展示不是实图，而是这种 AI 生成的图」「之前有个版本点进景点打卡界面也是能显示景点图片的」「以上两条规则要写死进 skill」。所以：

- **规则 ① 行程页「当天主景区」必须是实拍图**。`paintHero()` 的 `!src` 分支**禁止**再调 `cover()` 画程序化"风景图"冒充景点——那正是被当成「AI 生成图」的东西。缺图只允许四步：内嵌 `IMGS[景点 k]` → `localStorage` 缓存 → `fetchSpotPhoto()` 联网抓 → 都没有就中性占位（`.v600-noph` 深绿渐变）+ 角标「暂无实拍图 · 景点名」。`cover()` 仅保留给 `window.__v543CoverFor` 这类工具，**不许接回 paintHero**。
- **规则 ② 「美食 → 景点打卡 · 热度榜」每一行都要有实拍缩略图**。`.v46-rank` 行原本没有任何图片节点（这就是「点进去看不到景点照片」的原因）。V6.00 由 `v600-photo-js` 给每行注入 `.v46-shot`（整行横幅 92px，`order:-1`），图源与规则①同一条链路，**断网/无图时显示「无图」而不是画假图**。
- **装饰插画不许压在照片上**：`.v47-dayscene`（日卡上的程序化场景）与 `.v46-rank::before`（热度榜行的程序化相框）一律关掉。它们是"实拍照看着像 AI 图"的元凶。

图源顺序（`fetchSpotPhoto()` / `v600-photo-js` 的 `pick()`）：

1. `window.V543_IMGS[景点k]` —— 构建期内嵌的 base64 实拍图（**主路径，断网也出图**）。
2. `window.V600_ALIAS[名称片段] → k` —— 热度榜行只有景点名，用别名表映射回 `k`；`pick()` 先精确匹配，再退化为"行名里含别名"的包含匹配。
3. `localStorage`（`v600s:<景点名>`）—— 上次联网抓到的图，避免每次切板块重抓。
4. `fetchSpotPhoto()` —— 维基 REST 摘要 + 维基搜索接口（`origin=*`），候选串 = 原名 / 分隔符切片 / `sub` / 去后缀；单景点总预算 12s。
5. 都没有 → 占位 + 「暂无实拍图」（**绝不回退程序化风景图**）。

构建期动作（生成新路书时必须做，做完才算交付）：

1. 写 `spots.json`，一个景点一行：`k`（写进 `V543_IMGS` 的 key）、`name`（热度榜行名里会出现的景点名）、`q`（检索词，带「实拍/风景/全景」更容易出好图）：

   ```json
   [{"k":"duke","name":"独克宗古城","q":"独克宗古城 转经筒 实拍"},
    {"k":"songzan","name":"松赞林寺","q":"松赞林寺 晨雾 实拍"}]
   ```

2. 抓图（**纯 Python，无豆包专有能力**；按 360 → 搜狗 → 百度 → 百度百科 → Bing → 维基 依次尝试；
   小红书 / 高德 / 美团 / 携程 / 飞猪 / 百度 / 维基 / 360 另外各有 `site:` 站内检索，一条景点会把这八家都查一遍）：

   ```bash
   # 默认就查 8 家平台；--platforms 可改成中文别名（小红书/高德/美团/携程/飞猪/百度/维基/360）
   python scripts/fetch_spot_photos.py --spots spots.json --out photos.json --preview preview
   ```

   - 脚本自带**标题闸门**：候选图的标题里必须出现检索词，否则丢弃。这条不能去——实测过 Bing 的 `murl` 列表会混进完全无关的图（查「松赞林寺」返回人物像），没有闸门就会把路书配成毫不相干的东西。
   - 同时输出 `preview/<k>.jpg`，**必须肉眼过一遍**再写进路书；水印大、主体不清、文不对题的换 `q` 重抓。
   - 没有图的 key 会列出来：改用 Agent 自己的 `image_search` 挑图，或给该条加 `"file": "D:/pics/xx.jpg"` 本地路径。

3. 写进 HTML（幂等，可分批补图；不会覆盖别的内容）：

   ```bash
   python scripts/embed_photos.py --html 路书.html --photos photos.json --alias alias.json
   ```

   `alias.json` 就是 `V600_ALIAS`：`{"独克宗古城":"duke","松赞林寺":"songzan"}`。热度榜行名里出现左边任一片段，就用右边 key 的图。

4. **同一天多张日卡允许复用同一张图**，但不同景点不许共用一张（撞图 = 没做）。压图参数固定：长边 ≤1100px、`quality≈68`、`progressive=False`（渐进式会在手机上糊一帧）。

图源实测（本机 2026-11，直接抄结论，别再重复试）：

| 图源 | 接口 | 运行时（浏览器内 fetch） | 构建期（Python） |
|---|---|---|---|
| 360 图片 | `image.so.com/j` | ⛔ 无 CORS 头 | ✅ 可用（首选，CDN 图能直下） |
| Bing 图片 | `bing.com/images/async` | ⛔ 无 CORS 头 | ✅ 可用（需标题闸门） |
| 百度图片 | `image.baidu.com/search/acjson` | ⛔ `ACAO` 只回 `image.baidu.com`，`callback` 也失效 | ⚠️ 常返回 `antiFlag`，尽力而为 |
| 搜狗图片 | `pic.sogou.com/napi/pc/searchList` | ⛔ 无 CORS 头 | ✅ 可用（国内直连） |
| 百度百科 | `baike.baidu.com/api/openapi/BaikeLemmaCardApi` | ⛔ 无 CORS 头 | ✅ 可用（词条主图，最贴景点） |
| 维基百科 | `zh.wikipedia.org` REST | ⛔ 被墙（本机 20s 超时） | ⛔ 同样超时（海外可用） |
| 小红书 / 高德 / 美团 / 携程 / 飞猪 | 平台站内检索 | ⛔ 需登录态或私有 key | ✅ 用 `site:xiaohongshu.com` 等站内检索走 360/搜狗/Bing 取回已收录的实拍图 |

**天数与板块是硬契约（用户 2026-11 明确要求，别再回退）：**
1. **行程几天就生成几个 Day tab，不许写死 4 天**。模板已改成从页面里的 `.daycard` 自动数天数（`buildTabs` 的 defs 由 `.daycard` 数量生成），老页面还有 `v15-anyday-js` 兜底重建 tab；生成时只要保证「一天一张 `.daycard`」，tab、`Day 1–N` 标题、`全部` 都会自动对齐。
2. **板块 id 不许删、不许改名**（至少保住 `v-home / v-prep / v-itinerary / v-spots / v-food / v-budget`）。Dock 的 `data-nav` 必须指向真实存在的板块；缺一个，`__navTo` 就会回落到首页——用户看到的就是「点景点打卡回首页」。`v15-anyday-js` 已加了守护：目标缺失时原地提示，不再跳首页；`check_demo_leftovers.py` 也会把「缺板块 / Dock 指向空」判为失败。

**结论写死（用户 2026-11 明确要求，别再回退）：**
1. **行程顶部景点图、打卡热度榜缩略图、机位详情页头图，三处共用同一套 `V543_IMGS` + `V600_ALIAS`**，同一景点同一张实拍图，不许各画各的。
2. **构建期必须多图源搜图**：`fetch_spot_photos.py` 默认把 360、搜狗、百度、百度百科、Bing、维基，以及小红书 / 高德 / 美团 / 携程 / 飞猪 / 百度 / 维基 / 360 的 `site:` 站内检索全部跑一遍；一个源失败自动换下一个，不许「维基一失败就没图」。
3. 运行时联网只是兜底，抓不到就显「暂无实拍图」，绝不许画程序化风景图冒充。

验收（无头 CDP 即可，不许开虚拟桌面/不许操控电脑）：

| 检查 | 期望 |
|---|---|
| `#v-itinerary .daycard img.v591-photo` 或 `.dimg` 背景 | 都是 `data:image/jpeg`，且 8 天各不相同（按景点） |
| `.v543-auto` 角标 | 正常路书里应当**查不到**「自动题图」；只有没配图的景点才允许出现「暂无实拍图」 |
| `.daycard .v47-dayscene` | `display:none`（全站） |
| 打开「景点打卡」后 `.v46-shot` | 条数 = `.v46-rank` 条数，且 `backgroundImage` 全是 `data:image/jpeg`，`loading/empty` 均为 0 |
| `.v46-rank::before` | `content:none`（不再有程序化相框） |

## 列车车型识别（复兴号 / 和谐号 / 普速）

车票卡 `#railCard` 与时间线折叠条上的「车次 + 车型」由 `meta(no)` 生成，规则写死在模板里，**不要按车次首字母猜品牌**：

- **车次首字母只决定列车等级**：`G`=高铁、`D`=动车、`C`=城际、`Z`=直达特快、`T`=特快、`K`=快速、`S`/`Y`=市域/旅游。它**不能**证明是复兴号还是和谐号——同样跑 `G`/`D` 的车次，既有复兴号 CR400 系列，也有和谐号 CRH380/CRH2 系列。
- **品牌只认 `DB` 车型库**：模板里的 `var DB={'车次':['FUXING'|'HEXIE','显示名']}` 只放**已核实**的车次。查到具体车型就补一行，例如 `'D3802':['HEXIE','和谐号 · 动车']`；`FUXING` 用红金图标，`HEXIE` 用蓝色图标，`UNKNOWN` 用中性灰。
- **查不到就写「车型待核」**：`G`/`D`/`C` 未入 `DB` 时显示「高铁 · 车型待核」「动车 · 车型待核」「城际 · 车型待核」，**严禁默认标成复兴号**。`Z`/`T`/`K` 等普速默认 `HEXIE`（和谐号机车牵引），显示为直达特快/特快/快速。
- **怎么查**：按「车次 + 车型」联网检索（12306/铁路迷资料/百科），确认 CR400 系列、CR200J（绿巨人）属复兴号，CRH 系列属和谐号；同一车次不同日期可能换车型，以用户出行日期为准，拿不准就保留「车型待核」并提醒用户核对 12306。示例：`D3802`（广州南—昆明）实测为 CRH2A → 和谐号；`C642`（昆明—香格里拉）为 CR200J 重联 → 复兴号。
- **列车插画按用户要求删除，不要加回来**：车票卡 `#railCard::before` 与时间线折叠条 `.foldbtn[data-seg]::before` 上的列车图一律 `display:none!important`（写死在模板末尾 `#v63-rules-css`）。删图的同时必须把 `#railCard` 为插画预留的 `min-height:300px / padding-bottom:120px` 改成 `min-height:0 / padding-bottom:18px`，否则卡片底部会留一块 ~120px 的空白。**机票卡 `#planeCard` 的客机图保留**，不要一起删。
- **客机插画只用原版那张场景图，不许换、不许重画**：`--v511-plane-scene` / `--v514-plane` 里的 base64 就是原版「杭州南京」那张 `viewBox="0 0 900 300"`（3:1），画面是「天空 + 客机 + 站台散点」。换素材或自己重画都会和原版不一致。
- **留下的客机图，容器必须和素材同比例**：贴底容器写成 `left:0;right:0;bottom:0;height:0;padding-top:33.3333%`（宽:高 = 3:1），再配 `background-size:100% 100%` —— 盒子比例=图比例时是**零变形**。**盒子比图矮就会裁图**：`.tkcard` 顶栏那条 `height:92px` 一旦压到 `#planeCard::before` 上，只剩机身下半截，看起来像一条扁带。所以兜底必须显式写 `height:0;padding-top:33.3333%`，不许继承 92px。

## 三个已修复的视觉坑（改模板时不要回退）

1. **Day 封面四角圆角**：`.dayhero` 必须 `border-radius:22px`（四角一致），`.dayhero .dimg` 同样 22px；`.daybody` 用 `margin-top:8px` + `border-radius:22px` 与封面分开。历史上 `.dayhero{border-radius:22px 22px 0 0}` 会让封面左下/右下变成直角，与原版不符。
2. **首条行程不许压插画**：`.daybody` 顶部的装饰带 `.v50-dayart`（`top:-18px;height:148px`）会盖住「linkrow + 第一个时间点」，模板已用 `html body #v-itinerary .card.daycard .v50-dayart{display:none!important}` 关闭；当日主题图只走底部 `.v514-art`（配合 `.v514-themed` 的 `padding-bottom:152px`）。**`placeArt()` 不能写死 `for(d=1;d<=4;d++)`**——超过 4 天的行程第 5 天起没被处理，顶部装饰带就会露出来压字；模板已改为遍历全部 `.daycard`，第 5 天起循环复用 1–4 号插画。
3. **交通插画不拉伸、也不被裁**：只对保留下来的客机图生效——固定用原版 `viewBox="0 0 900 300"` 那张场景图，`#planeCard::before` 做成 **3:1 贴底盒**（`left:0;right:0;bottom:0;height:0;padding-top:33.3333%`）+ `background-size:100% 100%` + `center bottom`。历史上出过两种错：①`100% 100%` 套在非 3:1 的盒子上（`height:92px` 顶栏 / 整卡），车头被横向拉扁；②盒子比图矮（92px vs 图高 137px），天空和车窗带被裁掉，只剩一条红带。列车图现在整块删除，不再受这条约束。

## 美食配图按「菜品 + 所在景点」自动重绘（**景点图例外，见上节硬规则**）

模板里有 11 张写死的食品图（`f_noodle / f_soup / f_claypot / f_bun / f_duck / f_pork / f_shrimp / f_platter / f_cake / f_sweet / f_pancake`）和站点自带的 8 个景点图标。**这些只当兜底，不许当默认**：真实路书里 20 道菜会全部撞成同两三张图，景点热度榜的头两个缩略图也会是同一张灰白占位。

V5.64 层的做法（模板末尾 `v564-art-js` / `v564-bind-js` / `v564-art-css`）：

1. **先认景点**：`harvest()` 从 `#v-spots .idxlist>a`、`.v46-rank .v46-rn`、`section.view[id^="v-spot-"] h1` 里收集景点名（自动去掉 `📸` 前缀、`· 副标题`、`11/22` 这类日期尾巴，超过 16 字丢弃）。
2. **再认这张卡在哪**：`spotOf()` 在卡片文字（菜名 + 描述 + 「XX 20 分钟圈」那一行 + 最近的分组标题）里找**最长命中**的景点名；找不到就退到分组标题的地区（`香格里拉 · Day 1–2` → `香格里拉`）。
3. **按地貌出景**：`kindOf()` 把景点归为 `temple / town / lake / river / garden / sea / snow / city / mountain` 九类，每类一套配色 + 专属远景（寺庙金顶 / 古城屋脊 / 江湾曲线 / 湖面倒影 / 园林垂柳 / 海面帆影 / 雪山雪帽 / 城市天际线 / 丘陵）。
4. **按菜品出器皿**：`catOf()` 归到 `noodle / soup / claypot / bun / duck / pork / shrimp / fish / cake / sweet / pancake / platter`，菜名哈希 `h32()` 再做确定性微调（蒸汽数量、配料位置、远景偏移）。
5. **写进 CSS 变量**：`--v564-fimg`（美食卡 `::before`）、`--v564-mimg`（餐次入口磁贴），由 `v564-art-css` 里的 `html body …[data-v564]::before{background-image:var(--v564-fimg)!important}` 覆盖旧图。
   **`--v564-simg`（热度榜缩略图）自 V6.00 起作废**：热度榜那行必须是实拍图（`.v46-shot`），程序化相框 `.v46-rank::before` 已被 `content:none` 关掉。变量还在写也无害，因为没人再渲染它。

**硬规则**：

- 同一份路书里，**不同菜品必须出不同的器皿**；同一景点同款菜才允许同图。**景点图不在此列**——景点只能用实拍（见「景点图硬规则」）。
- 不许靠「删掉某几张固定图」来假装解决——旧的 `FOOD_RULES/foodArt/paintFood` 继续写 `--v543-*` 也无害，新变量优先级更高。
- 生成新路书时**美食图不用手写**：菜名照原样写、卡片里带上「XX 20 分钟圈」这类地名行更准，页面加载后会自动重绘。但**景点图必须手写实拍图**（见上节构建期动作）。
- 美食图是运行时程序化 SVG（静态页不能联网、不能调模型）；要「AI 手绘质感」只能在构建期另出图写进 `IMGS`。**这条只适用于美食，不适用于景点**——景点没有实拍就不许上假图，宁可显「暂无实拍图」。

## 机位详情页必须有「返回上一级」

模板里 13 个 `v-spot-*` 面板原本只有 hero + 卡片，**没有返回条**——从「景点打卡」点进去就只剩浏览器返回键。V5.64 层在运行时注入，写死在 `v564-fix-js`：

- 每个 `section.view[id^="v-spot-"]` 的 `.wrap` 首位插入 `<div class="v564-backbar">`：左边 `← 返回上一级`、右边 `✕ 关闭`（`margin-left:auto`）。
- 返回目标不是写死的 `v-spots`：`v564-fix-js` 在点击 `[data-nav]` 进机位前记住当前板块 `LAST`，返回就回那里；默认仍回落 `v-spots`，关闭回 `v-itinerary`。
- 幂等：`data-v564-back="1"` 标记，加载后 + 1200ms + 2600ms 各补一次，之后每 900ms 兜一次（生成时漏建机位也能补上）。
- 样式：白底/深绿字胶囊 + 右侧浅灰关闭键，深色与自定义背景下各有一套配色（`html body.hasbg` / `prefers-color-scheme: dark` 两条分支）。

**不要在生成时手写返回条**，交给运行时；但如果手写了 `class="backbar"` 之类，记得别和 `v564-backbar` 抢位置。

## 每次生成完必须做的「三态可读性」检查（死规则）

以前只看浅色模式，结果深色下 `.box` 变成「浅灰底 + 浅色字」、Day 徽标糊在文字上。**以后每生成/修改一份路书，交付前必须按三种状态各看一遍**：

| 状态 | 怎么进 | 必看 |
|---|---|---|
| 浅色 | 系统浅色 + 浏览器默认 | `.box/.b-gray/.b-info/.b-warn/.b-ok/.b-bad`、`.todaydot`、时间线、卡片文字 |
| 深色 | 系统深色（或 `msedge --force-dark-mode` 无头取证） | 同上；**重点 `.box.b-gray`**（历史坑：只有浅色渐变，没写深色分支） |
| 自定义背景 | 首页上传一张图（`body.hasbg` 生效）后切板块 | hero 文字、`.box`、Dock、返回条、Day 徽标 |
| **深色 + 自定义背景** | `--force-dark-mode` + `body.hasbg`（缺一不可） | 壁纸是否整屏可见、hero 以下有没有亮色带、暗罩后正文对比度 |

判据：正文与底色对比度 **≥ 4.5:1**（`#E4F1EF` on `rgba(26,44,48,.94)` ≈ 10:1 合格）；文字不许压在插画/照片上；毛玻璃层里不许出现「浅底浅字」。

模板已把这三态写死（`v564-fix-css`）：

- 深色：`.box / .b-gray / .b-ok / .b-warn / .b-bad / .b-info` 全部实色深底 + 亮字（`!important`），`b-gray` 也用 `rgba(26,44,48,.94)` 渐变，不再漏。
- 自定义背景（浅色）：`.box` 类钉成 `rgba(255,255,255,.95)` 白底 + 深字，四种彩色变体各给实色浅底。
- 这两条都用 `html body` 提权，新增样式不许把它们压回去。

## Day 标签上的「待出发」徽标

历史坑：`#dayTabs .ptab` 是 flex，文字是匿名项，「待出发」徽标 `static` 且没留间距 → 徽标贴着/压住 `Day 1`；徽标里的 `::before` 圆点原来是白色，落在奶油底上等于隐形，中间某版又被刷成深绿 `#0f766e`，压在红色胶囊上同样糊。

模板写死（`v564-fix-css` 管布局 + `v586-addon-css` 管配色）：

- `html body #dayTabs .ptab{flex:0 0 auto;min-width:max-content;overflow:visible;white-space:nowrap}`，`#prepTabs/.ptabs` 同样 `flex:0 0 auto`。
- `.todaydot{flex:0 0 auto;margin-left:8px;padding:0 6px}`；**基础态**（红胶囊）`color:#fff` + **白点** `#fff`。
- **待出发态** `.todaydot.is-wait`：`color:#7A2E12`（深棕）on `background:#FFEFD8`（奶油），边框 `#E9B27E`，圆点 `#B23A00`（深橙）。文字对比度 ≈ 8.6:1、圆点 ≈ 5.1:1；深色分支沿用原版 `#ffe9cd` on 深橙渐变。
- 验收：浅色、深色两态各截 2 倍图，看「Day 1」右侧的胶囊——文字、边框、圆点三层都要能分辨。

## Dock 回首页：下沉是纯 CSS 过渡（照原版，不许自造）

**结论先行**：原版路书（线上 `hz-nj-autumn-roadbook`）的下沉没有一行是手写动画——全靠 `#dock` 自己的 CSS 过渡。任何 WAAPI、逐帧写内联 `opacity/transform`、自制 watchdog 都会和它抢属性，结果就是「一帧消失、看不到下沉」。前几版反复失败的根因就在这里。

原版链路（模板已按此逐字还原）：

1. 基础规则（模板 ~56k 处）：`#dock{opacity:0;transform:translateY(18px) scale(.96);pointer-events:none;transition:opacity .2s linear,transform .26s var(--ease-out)}`；可见态由 `body.dockon #dock{opacity:1;transform:none;pointer-events:auto}` 提供。
2. `v570-addon-css` 把时长拉齐页面滑动：`html:root #dock{transition:opacity var(--v570-dur,.42s) linear,transform var(--v570-dur,.42s) ease!important}`。
3. 转场期强制可见：`html body.v512-slide #dock#dock{opacity:1!important;transform:none!important;pointer-events:none!important}`；落地那一帧撤掉这个类。
4. 落地释放（`v570-addon-js` 的 `releaseDock`）：`dockon` 在 → 清内联交还 CSS；不在 → `dock.style.opacity='1'` → `void dock.offsetWidth` → 两帧 `raf` 后 `dock.style.opacity='0'`。**它只把内联从 1 放到 0，位移和曲线交给 CSS。**
5. `v576-addon-js` 的 `sink()` 用 `data-v58="hold"/"sink"` 两个属性态承载下沉：`hold{opacity:1;transform:none;transition:.30s}` → 40ms 后 `sink{opacity:0;transform:translate3d(0,96px,0);transition:.30s}`；只在「回首页」触发，落在板块一律 `unpinDock()` 交还站点。

**与原版线上页的同链实测**（CDP 真实时间，520×900，同一段脚本：首页磁贴进板块 → 点 Dock 回首页）

| 采样点 | 线上原版 | 本地模板 |
|---|---|---|
| 转场结束 | t=480ms，`data-v58=hold`，inline `opacity:1` | t=480ms，`hold`，inline `opacity:1` |
| +60ms | op 0.944 / translateY 3.72px | op 0.778 / 33.17px |
| +120ms | op 0.722 / 44.99px | op 0.556 / 71.14px |
| +180ms | op 0.500 / 77.06px | op 0.389 / 85.68px |
| +240ms | op 0.277 / 91.23px | op 0.167 / 94.41px |
| +300ms | op 0.111 / 95.33px | — |
| 收敛 | op 0 / 96px | op 0 / 96px |

同一条 `transition:opacity .30s linear, transform .30s ease`、同一个终点 `translate3d(0,96px,0)`，肉眼就是「整条胶囊往下沉出屏幕并淡掉」。

**禁止清单（回退立刻复发）**：不许给 `#dock` 写 `Element.prototype.animate` 包；不许在 rAF 里逐帧 `setAttribute('style','opacity:..!important;transform:..!important')`；不许加 `#dock.v84sink` 这类自制类或 480ms 看门狗；不许把 `transform` 从基础规则里删掉（删了只剩淡出，没有下沉）。

### 手机「减弱动态效果」打开时会一帧消失（v587 已修，勿删）

这是历史上被漏掉的一条路径：桌面/无头正常态曲线一直是对的，但真机若打开了「减弱动态效果（Reduce Motion）」，Dock 会**一帧从 1 跳到 0 / 96px**，看起来就是「没有下沉」。

压制链（三条同时生效，最后一条才是真凶）：

1. `@media (prefers-reduced-motion:reduce){#dock{transition:none}}`（模板 ~58k 处）。
2. `*,*::before,*::after{transition-duration:.01ms!important}`（全局 ~31k 处）。
3. `html body:not(.v512-slide) #dock#dock{transition:none!important}`（reduce 分支内，优先级 (2 id,1 class,2 type)）。

`v587-addon-css` 的解法：在同一个 reduce 媒体查询里，用**多带一个 `:root` 伪类**的选择器把优先级抬到 (2 id,2 class,2 type)，并用字面量时长（不依赖 `--v570-dur`）：

```css
@media (prefers-reduced-motion: reduce){
  html:root body #dock#dock,
  html:root body:not(.v512-slide) #dock#dock{
    transition:opacity .30s linear, transform .30s ease !important;
  }
  html:root body #dockLiquid#dockLiquid,
  html:root body:not(.v512-slide) #dockLiquid#dockLiquid{
    transition:transform .34s linear, width .12s linear, opacity .26s linear !important;
  }
}
```

两个踩过的坑：

- **不许写 `-webkit-transition` 前缀**。样本里加了 `-webkit-transition:opacity .30s linear, -webkit-transform .30s ease` 后，正常态出现「transform 在下沉、opacity 直接归零」（Chrome 把前缀简写当独立声明盖掉了标准简写）。
- 时长必须写字面量：`var(--v570-dur,.30s)` 在这条覆盖里会因变量已存在但解析失败而整条声明作废。

实测（390×844 + DPR2 + `Emulation.setTouchEmulationEnabled` + `Input.dispatchTouchEvent` 真触摸；同链：点首页磁贴进板块 → 点 Dock 回首页）：

| 场景 | `transitionDuration` | 采样曲线（每 60ms） |
|---|---|---|
| 正常 | `0.3s, 0.3s` | 1.000/none → 0.833/21.2px → 0.667/55.3 → 0.445/81.8 → 0.167/94.4 → 0/96 |
| reduce（修复前） | `0s` | 1.000/none → **0.000/96px 一帧消失** |
| reduce（修复后） | `0.3s, 0.3s` | 1.000/hold → 0.944/3.69px → 0.722/45.0 → 0.500/77.0 → 0.333/88.8 → 0.111/95.3 → 0/96 |

验收要求：**必须跑两遍**（一遍默认、一遍 `Emulation.setEmulatedMedia{prefers-reduced-motion:reduce}`），两遍都要看到 `transitionDuration` 非 `0s` 且中间帧位移递增；只测一遍就宣布「已对齐」是历史上被用户连续否定的直接原因。

## 自定义背景（body.hasbg）：壁纸必须透出来，转场全程保持模糊

原版把这件事拆成静态层与转场层，模板 = 原版逐字：

**静态层（`v578-addon-css`，与模板字节级一致）**

- `html:root body.hasbg{background:transparent!important}` —— 「深色模式看不见背景」的解药：深色主题给 body 铺的是不透明 `#081114` 渐变，负 z 的壁纸层被整块盖住。
- `html:root body.hasbg::before{inset:-34px;z-index:-2;filter:blur(6px) saturate(1.05) brightness(.9x);background:var(--hero-bg) center/cover no-repeat}` —— 壁纸本体。
- `html:root body.hasbg::after{left/top/right/bottom:-34px;z-index:-1;background:linear-gradient(rgba(6,14,17,.18),rgba(6,14,17,.34))}` —— 暗罩。
- **两层 inset 必须同为 -34px**。历史写法是 `::before -26px` / `::after 0`，差的这一圈正是首页磁贴下方那条「灰白区域」：壁纸只铺到视口外 26px、纱幕只铺视口内，底部露出页面底色。
- 深色两套入口都要写：`@media (prefers-color-scheme: dark)` 与 `body.hasbg.dark`（站点脚本直接给 body 加 `dark` 时走这条），同参数同结构。
- 转场浮层 `body.hasbg .view.v512-in::after/::before` 用同一组 inset / filter / 渐变复刻，落地撤层时无色差、无「先取消模糊再恢复」。

**不许再做**：不要给 `body.hasbg` 补 canvas 预模糊层（`--v564-bg-soft`）；也不要把 hero / 磁贴刷成实色深底去「压住背景」——那会把壁纸整块盖掉，是「深色看不见背景」的另一半原因。可读性靠 `::after` 暗罩 + 卡片自身毛玻璃。

### 「背景时不时抽动」的真实成因（v587 已修，勿回退）

不是壁纸层本身抖，是 **`v568-addon-js` 的 `syncHero()` 自己把自己写成了死循环**：

- 它挂了两个 `MutationObserver`：一个监听 `body.class`，一个监听 **`documentElement` 的 `style` 属性**。
- 而它自己正是往 `documentElement.style` 里写 `--v568-hero-img`（一整段 base64 壁纸）和 `--v568-bodybg`。
- 于是：写变量 → 触发 `style` 属性变更 → 回调再次 `syncHero()` → 再写一次 …，样式失效与重绘永不收敛。手机上（壁纸层是 `position:fixed` + `filter:blur`）表现就是「隔一会儿抖一下」，还会持续吃电。

修法（`v587`，19 行以内）：写之前先比对现值，值相同就不写——

```js
var setVar = function (n, v) {
  try { if (R.style.getPropertyValue(n) !== v) R.style.setProperty(n, v); } catch (e) {}
};
```

实测（390×844 + DPR2，真实照片 900px 当壁纸、只 `setProperty('--hero-bg')` 一次 + 加 `hasbg`，与用户点「自定义背景」的写入路径一致）：

| 指标 | 修复前 | 修复后（空转 10s） |
|---|---|---|
| `documentElement.style.setProperty` 调用次数 | 持续不停（每 400ms 至少一次，且链式叠加） | **0** |
| `documentElement` 的 `style` 属性变更次数 | 持续不停 | **0** |
| 壁纸区帧差（12 帧 ×160ms） | — | 逐帧 `mean=0.00`、`bbox=None` |

排查经验：`mk_hasbg.py` 那类探针内部有 `setInterval` 每 400ms 重刷 `--hero-bg`，会**污染写入监测**，让日志里出现的 400ms 周期看起来像站点行为。做「抽动」实验必须用真实照片、只写一次。

另两条同属 `v587` 的防御（机理明确、无头环境无法直接证明「真机不抖」，故按防御性措施记录）：

- 壁纸层提升独立合成层：`body.hasbg::before{will-change:transform,filter; transform:translateZ(0) scale(1.05); backface-visibility:hidden}` —— 避免滚动/重排时每帧重新执行 `blur(6px)`。
- 手机地址栏收起/展开会改变 `position:fixed` 层的视口高度，`cover` 重新裁剪 = 肉眼「跳一下」。`@supports (height:100lvh)` 下把两层几何钉成 `top:-34px; height:calc(100lvh + 68px)`，地址栏变化不再改变壁纸尺寸。
- **验收边界（诚实记录）**：CDP 的 `Emulation.setDeviceMetricsOverride` 里 `lvh === vh`，无头环境无法复现「地址栏切换导致 lvh≠vh」的差异，只能验证规则已生效（`height: calc(100lvh + 68px)` 解析为 `vh+68`）。真机是否彻底不抖，需要用户在手机上滚动+地址栏收展实测。

### 「切换准备/行程时闪一下、还掉帧」的真实成因（v588 已修，勿回退）

**根因是我自己上一轮加进 `v568-addon-js` 的 animate 包装**，不是站点动画：`wrappedAnimate` 挂在 `Element.prototype.animate` 上，把原版一条 260ms 缓出改成「创建后暂停 4 帧预热 + 尾部追加 30% 定格保持帧 + `commitStyles()` 后 `cancel()`」。

380×844 下的逐帧 `getComputedStyle().transform`（准备↔行程 两向，rAF 采样）：

| 采样 | 包装还在 | 包装停用（= 现在） |
|---|---|---|
| 起始 | `390px` 一直保持到 ~108ms | `390px` 到 ~60ms 后开始走 |
| 中段 | 141ms `250` → 179ms `83` → 207ms `24.9`（33~38ms 一跳） | 78ms `337` → 112ms `239` → 145ms `161` → 179ms `105` → 211ms `66` |
| 收敛 | 308ms 到 `0`，之后停 230ms 才 `none` | 311ms `10.8` → 345ms `3.9` → 378ms `0.6` → 412ms `none` |

也就是说：**新页面先停在屏外不动 ~130ms，再在 170ms 内猛冲进来** —— 真机肉眼就是「闪一下 / 掉帧」。线上原版同链对照（`cdp_orig_cmp.py`）确认原版只有两条 WAAPI：`[opacity .9 + translate3d(0,7px,0)] 170ms` 淡入 + `[translate3d(±100%,0,0) → 0] 260ms` 滑入，没有任何包装。

**结论：转场不要碰 `Element.prototype.animate`，也不要碰 `Animation.prototype.cancel`。** 同层另外两处也要保持停用：

- `②-C 落地帧禁过渡`（`v568-land`：`v512-slide` 由有到无那一帧给 body 加类、把 `.view` 的 `transition` 置 `none` 60~80ms）——它和站点撤 `.v512-in` 抢同一帧，属性还在变就硬切一帧。
- 浮层壁纸原来是 `.view.v512-in::after{position:fixed + filter:blur(4px)}`，但它处在正在 `translate3d` 的浮层里：`fixed` 在 transform 祖先内退化为随层移动，等于 260ms 里每帧重做一次整屏高斯模糊。`v588` 改成 `makeBlur()` 用 canvas 预模糊一次（同 `blur(4px) + saturate(1.04)`）写进 `--v568-hero-blur`，并置 `--v588-after-filter:none`；没算好之前仍回落实时模糊。实测转场期 `::after{filter:none, background-image=url(28,326 字符预模糊图)}`。

用户录屏抽帧印证：`f055`（准备滑入首帧）与 `f097`（行程滑入首帧）都是「整页发糊的一帧，下一帧才变清晰」，之后才是正常滑动。

### 「行程页景点封面图那里闪」的排查结论与 v589（勿回退）

用户第三次报的问题是**行程页 `.dayhero` 那块大封面图（inline base64 JPEG）闪**。先把「是不是有东西在周期性重写」查死，再动代码：

| 检查（进行程页后静置不动屏） | 结果 |
|---|---|
| `#v-itinerary` 子树 6s mutation | 40 条，**全是 `childList`**；`style` / `class` / `src` / `data-v564` 变更 **0** |
| 周期性重写者只有站点自己的定时器 | `v44-plane-head`+`foldbtn` 每 ~1.6s、`tkIco/tkNo/tkModel/tkGate/tkSeats` 每 ~2.0s，都是**文本节点重建** |
| `document.head` 8s（含 characterData） | **0 条** mutation（32 个 `<style>`，仅 1 个无 id）→ `placeDayScenes()` 那种「重写 style 里的背景图」假设不成立 |
| 逐帧 screencast（jpeg q60 + 0.06s pump，41 帧）静置 | 每帧 `diff 0.0` |
| 切 Day 标签（48 帧） | 只有第 3→4 帧一次整块换天，**无中间糊帧/空帧** |
| 封面区 6s 逐 rAF 几何采样（352 帧） | `hero.top 221.9` / `hero.height 399.6` / `card.height 2028.2` **全程单值**，没有 1px 抖动 |

所以「闪」不是重写导致的，而是**合成层首次栅格化**那一类：大 JPEG 要现场解码，兄弟节点重排又会把这层重画。v589 三条对策：

1. **把封面图单独提一层**：`html:root .dayhero .dimg{transform:translateZ(0);backface-visibility:hidden}` —— 车票卡里每 1.6s 重建的文本节点不再波及照片。
2. **主题插画层也独立成层**：`.v47-dayscene` **不是** `.dayhero` 的子节点，它是 `.card.daycard` 的直接子元素（`position:absolute;right:0;top:0;width:78%;height:56%;z-index:0`），所以选择器必须写 `html:root #v-itinerary .card.daycard .v47-dayscene`；写成 `.dayhero .v47-dayscene` 会静默不命中（实测 computed `transform:none`）。
3. **空闲时预热解码**（`v589-addon-js`）：遍历 `#v-itinerary .dayhero .dimg/.dsl/.dayhero` 取 computed `backgroundImage` 的 data URL，用 `new Image()` + `decode()` 塞进解码缓存；`ready` 后 0/700/2000/4000ms 各一次，`#v-itinerary` 的 class 观察器在退出 `v512-in` 后 260ms 再补一次。实测 `warmed 8 / dimg 8`。
4. `.dsl{will-change:auto!important}`：那是「8 天 × 3 张」的常驻轮播图层，本路书里根本没有 `.dsl` 元素（`querySelector` 返回 null），去掉后不会误伤。

**V5.89 顺带修了一个自造回归**：v588 的预模糊壁纸（`--v568-hero-blur`）只有转场浮层 `::after` 用得到，第一次用就是滑动首帧 —— 现场解码会空一帧（整屏背景闪一下）。现行是在 `makeBlur()` 里生成完立刻 `new Image().src=out; decode()`。

**验收边界（诚实记录）**：无头 Edge（`--disable-gpu`）复现不出用户描述的那种闪 —— 静置、切标签、进入转场三条路径都拿到了「无糊帧、无空帧」的帧序列（进入转场 4 帧的 edge-std 为 42.97 → 54.06 → 56.78 → 56.78，单调上升，没有掉清晰度的帧）。所以 v589 是**按机理做的稳定化**，真机「不再闪」仍需要用户在手机上复看。

### 内嵌图必须是「基线式 JPEG」（v590，进度式会把封面糊一帧）

用户第四次报「景点展示图片那里还是闪」。这次拿到录屏逐帧看：**第 85 帧封面整块变成一张极度模糊的糊块（能隐约看出列车轮廓），第 86 帧立刻恢复清晰**——不是 DOM 重写、不是层被清空，而是 **JPEG 解码的中间态**。

查文件才发现根因：**模板与路书里 14 张内嵌大图全部是渐进式 JPEG（progressive）**。渐进式 JPEG 解码是「先出第一遍低频扫描（整幅糊图）→ 再逐层细化」，一旦这张图被浏览器丢弃后重新解码，屏幕上就会出现一帧整块糊。录屏里那一帧的封面区亮度从 118.9 跳到 181.1（132 行像素带 diffmean 最高 117.2），而文字仍是清晰的——完全符合「图像在解码、文字在合成层」的表现。

换成**基线式（baseline）**：基线 JPEG 逐行解码，最差也只会看到「上半张有、下半张空」，不会出现整张糊；配合 `v589` 的 `decode()` 预热，解码在滑入前就完成。实测转换后：14 张大图 `big baseline: 14 / big progressive: 0`，路书与模板的换图前后整屏截图 `mean diff 0.67 / max 44`（只是重编码噪声，肉眼无差别）。

**写新路书时的死规则**：所有内嵌 JPEG（`data:image/jpeg;base64`）必须 `progressive=False` 输出，长边 ≤1200px、quality 80–84。PIL 写法：

```python
im.save(buf, format="JPEG", quality=82, optimize=True, progressive=False)
```

**别再做的事**：不要靠 `will-change`、`translateZ(0)`、预热解码单独去治这个闪（v589 做了这些，闪仍在）——那些只能减少层被重画的概率，治不了「解码中间态」。判断这类问题的最快方法：拿录屏逐帧差分，看糊帧是**整块糊**（解码中间态）还是**内容错位/发白**（层/布局问题）。

### 封面图改用 `<img decoding="sync">`（v591，治「糊一帧」的最后一层）

v590 把图改成基线式之后，机制上还剩一条路：基线的解码也是**逐行**画的，重新解码时仍可能先画半张/半糊。真正的关节点在**转场交接那一刻**——实测 `#v-itinerary` 在 t≈448ms 从 `position:fixed; z-index:41; will-change:transform` 变回 `static`，整页重新栅格化，CSS 背景图被要求重新解码，浏览器就把解到一半的画面先画出来（录屏第 85 帧：封面整块糊、文字清晰）。

v591 的做法：把 `.dayhero .dimg` 的 inline `background-image` 换成 `<img class="v591-photo" decoding="sync">`（`object-fit:cover`、`border-radius:inherit`、`pointer-events:none`）。`decoding="sync"` 要求**整张解完才允许绘制**，直接消灭“半张/糊块”的中间态；`img onload` 成功后才把原背景置 `none`，JS 异常时仍有背景兜底。

实测（390×844@2x）：8 个 `.dimg` → 8 个 `img.v591-photo`，`complete=true / naturalWidth=1200`，背景全部置 `none`；换实现前后整屏截图 `mean diff 0.36 / max 43`（肉眼无差别）。

**顺序要求**：这条必须和 v590（baseline 图）一起存在。只做 v590 不够（逐行解码仍会闪），只做 v591 而图是渐进式也不够（sync 解码会阻塞首帧、表现为掉帧）。

### 行程页「景点图 / Day 1 胶囊」单帧糊（v592 已修，勿回退）

**用户症状（原话）**：从首页直接点「行程」，顶部那张景区图必然抽一下；从「美食」「记账」点回「行程」，只有左上角 `Day 1` 那一块抽。

**帧级证据**（576×1280、30fps 录屏逐帧差分，单帧闪 = 与前后帧都不同、前后帧彼此几乎相同）：

| 帧 | 变化强度 | 变化区（严格被卡片边界包住） | 结论 |
|---|---|---|---|
| f38（首页→行程） | 差 32.6 / 前后仅差 0.2 | y 401–1177（整张 `.daycard`，含标签条、胶囊、标题、照片） | 整卡一帧糊 |
| f107（美食→行程） | 差 16.8 / 前后仅差 0.3 | y 401–681（只有标签条 + `Day 1` 胶囊那一条），照片段全为 0 | 局部一帧糊 |

**根因**：`.daychip{backdrop-filter:blur(12px) saturate(1.7)}` 与 `.ptab{blur(8px) saturate(1.65)}` 是整页**唯二**带 `backdrop-filter` 的元素。`backdrop-filter` 必须把「背后已合成的内容」实时抓成纹理再模糊；转场结束时 `#v-itinerary` 由 `fixed/z-index:41` 变回 `static`，整页重栅格化 → 背景纹理作废 → 重抓的那一帧就是糊的。f107 的糊区正好等于这两个元素的并集；f38 的糊区等于整张卡片——卡片因含 `backdrop-filter` 子元素被提升为「背景根（backdrop root）」，一重绘就是整卡低分辨率放大。页头的 `.hero` 也有 `blur(10px)`，但它是均匀绿色渐变，模糊前后像素无差（实测这两帧页头区差 0.0），所以用户看不到。

**修法（`v592-addon-css`）**：把这两处的实时模糊换成静态半透明底，并保留玻璃观感：

```css
html:root #dayTabs .ptab, html:root #dayTabs .ptab.on,
html:root #v-itinerary .daychip, html:root #v-itinerary .dayhero .daychip{
  -webkit-backdrop-filter:none!important; backdrop-filter:none!important;
}
html:root #v-itinerary .daychip{ background:rgba(8,20,26,.74)!important;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.16),0 8px 20px -12px rgba(0,0,0,.55)!important }
```

**验收**：
1. 计算值必须为 `backdrop-filter: none`（`#v-itinerary .daychip`、`#dayTabs .ptab` 各查一次）。
2. `#v-itinerary` 内仍有 `backdrop-filter != none` 的只剩 0 尺寸元素或自带不透明底的 `p.small`、`.tkhead` 等（当前 22 个命中里，可见且有实际模糊效果的只有已处理的这两处）。
3. 与上一版截图做差：整页 `mean diff ≤ 0.5`、胶囊区 `≤ 5`（实测 0.39 / 4.16），确认没有视觉回归。

**不许再做**：不要给这两处恢复 `backdrop-filter`（哪怕减小 blur 半径，重抓纹理照样糊一帧）；也不要用 `filter:blur()` 或 `transform:translateZ(0)` 去"补偿"玻璃感。
### 滚动位置记忆 = 有意功能，不许关掉；「自动滑一段」另有所指（v594 已修）

站点 `go()` 里有一套 `scrollMemo`：离开板块时记下滚到哪，回来时恢复。**这是要保留的功能**（上一轮曾按“进板块一律回顶”改过，已被用户否定并撤回）。

用户报的「首页点行程会自己滑一段」+「切换板块时上一版块叠在下一版块下面」，**只有在自定义背景（`body.hasbg`）下出现**，两者同一个根因：

- `v568` 把转场浮层底色写成 `background:var(--v568-bodybg)`；
- 而 `body.hasbg` 的 computed background 就是 `transparent` → 浮层整块透明；
- 垫底只靠 `::after`（壁纸，`z-index:-2`）与 `::before`（纱幕，`z-index:-1`）两个伪元素；真机合成里这两个负 z 伪元素会被排到浮层之外 → 上一版块直接透出来；
- 浮层内部的滚动又在对齐 `scrollMemo` 记忆位，透明叠加之下就表现为「页面自己在滑」。

**修法（`v594-addon-css`）**：不再依赖伪元素，把「纱幕 + 预模糊壁纸」直接画到浮层自己的 `background` 上，并给不透明兜底色：

```css
html:root body.hasbg .view.v512-in{
  background-color:#f4f7f6!important;
  background-image:linear-gradient(rgba(248,250,249,.44),rgba(248,250,249,.58)),
                    var(--v568-hero-blur,var(--v568-hero-img,none))!important;
  background-size:auto,cover!important; background-position:0 0,center!important;
}
html:root body.hasbg .view.v512-in::after,
html:root body.hasbg .view.v512-in::before{ content:none!important; }
```

深色分支同构（`#101c1e` 底 + 纱幕 + `rgba(6,14,16,.54)` 暗罩 + 壁纸）。

**验收**：自定义背景下切换板块，`getComputedStyle(.view.v512-in).backgroundColor` 必须是不透明色（修前实测 `rgba(0,0,0,0)`，修后 `rgb(244,247,246)`）；`::after` 的 `content` 为 `none`；滚动记忆复测：把美食页滚到 534 → 回首页 → 再回美食，落点仍为 534。

**排查经验**：凡是「只有自定义背景才出现」的毛病，先查 `body.hasbg` 这条链路（`--hero-bg` / `--v568-hero-img` / `--v568-hero-blur` / `--v568-bodybg` 四个变量是否都有值），再看靠负 z-index 伪元素垫底的层是否被合成器排开。

### 自定义背景下「切换板块，背景短暂变形后恢复」（v595 已修）

症状：只在 `body.hasbg` 下出现，切板块时壁纸像被压扁/缩小一下，落地瞬间弹回正常。

根因是**两层的壁纸几何不一致**：

| 层 | 画法 | 390×844 屏、720×1280 图上等效尺寸 |
|---|---|---|
| 静态 `body::before` | `inset:-26px`（442×912）`cover`，再 `transform:scale(1.05)` | ≈ **539×958** |
| 转场浮层 `.view.v512-in` | `background-size:cover` 铺满 390×844 | ≈ **475×844**（小 12%） |

所以转场那 260ms 里壁纸是「小一号」的，落地撤层时一次性换成静态层的尺寸 → 肉眼就是「变形一下又恢复」。像素证据：修前转场中壁纸网格间距 16.3px、静态 22.7px（只有 72%）；修后 89.8px vs 89.8px 完全一致。

**修法（`v595-addon-js`）**：把静态层的等效尺寸算出来写进 `--v594-bg-size`，浮层按像素铺，两边一模一样：

1. 读 `getComputedStyle(body,'::before')` 的 `width/height`（已含 `inset:-26px`）与 `transform` 的缩放；
2. 读壁纸原图（`--v568-hero-img`）的 `naturalWidth/Height`，`cover` 缩放系数取 `max(bw/w, bh/h)`；
3. `--v594-bg-size` = `宽×缩放×transform缩放 px`；CSS 里 `background-size:auto,var(--v594-bg-size,cover)`；
4. 在 load / 400ms / 1500ms / `body.class` 变化 / resize / 横竖屏切换时重算。

**验收**：转场中取 `getComputedStyle(.view.v512-in).backgroundSize`，必须是 `auto, 539px 958px` 这类**像素值**（等于 `body::before` 尺寸 × transform）；拿高对比网格当壁纸，转场中与静态的网格间距必须相等。

**v595 之后仍有残余，v596~v598 又试了三轮（模糊量对齐 / 纸层反向位移 / 与静态层同源绘制）都没修好，最后由 v599 推倒重来（见下节）。** 教训：只要「在浮层上再画一层壁纸」，真机就一定有窗口露出兜底色或让壁纸跟着滑。

### 自定义背景下「切板块：白幕盖住背景 / 背景跟着左右滑」（v599 已修；v594–v598 四轮都栽在同一个坑）

用户复测原话：①行程下滑后切美食再切回，「自定义背景先被一层白色图层覆盖，然后白色图层消失、背景再显现」；②「切换板块时背景会跟着左右移动」。

**根因（一句话）**：v594–v598 全都在做同一件事 —— **在转场浮层上再画一层壁纸**，用「不透明兜底色 + JS 建纸层 + 每帧写 `--v596-px` 反向位移」去假装背景没动。这套依赖三个运行时条件同时成立：`--v568-hero-img` 有值、`MutationObserver` 准时、媒体查询/`isDark()` 分支命中。真机上只要任一条不成立，浮层就露出兜底色 `#f4f7f6` = **白幕**；纸层晚到或反向位移滞后 = **壁纸跟着页面左右滑**。两个症状同源，而且**永远修不完**，因为它靠运行时图层「按时到位」。

**v599 的改法（只加 CSS，一个 JS 都不加）**：转场浮层「什么都不画」，壁纸只由静态那一层呈现。

```css
html:root body.hasbg .view.v512-in{background-color:transparent!important;background-image:none!important}
html:root body.hasbg .view.v512-in::before,
html:root body.hasbg .view.v512-in::after{content:none!important}
html:root body.hasbg .view.v512-out{opacity:0!important;transition:opacity .16s linear!important;pointer-events:none!important}
```

**不变量（这才是关键）**：转场期屏幕上只有 `body.hasbg::before` 这一层壁纸。它是 `position:fixed`、又不在任何 `transform` 祖先里 → **不可能被盖住、不可能位移**。为避免 v594 治过的「旧页从新页卡片缝里透出来」，旧页内容在 160ms 内淡出（顺带避免新页还没入场时的整屏空白）。

**验收（必须真实点击采样，别用合成浮层）**

| 采样 | 期望 |
|---|---|
| 转场期 `.view.v512-in` 的 `backgroundColor` | `rgba(0, 0, 0, 0)`（**不许**出现 `rgb(244,247,246)` 这类不透明兜底色） |
| 转场期 `.view.v512-in` 的 `backgroundImage` | `none`（浮层不许画壁纸） |
| 转场期 `.view.v512-out` 的 `opacity` | 1 → ≈0.69（t≈60ms） → 0（t≈160ms） |
| 任意一帧截图 | 壁纸区域与落地态**同一张像素**（同一层，天然相等；不必再比位移，也不该存在 `.v596-paper` 这种元素） |
| t≈400ms | `body.v512-slide` 已撤、页面正常落地 |

**特异性必须顶到 (0,6,2)（踩过一次）**：浮层里的壁纸/纱幕是伪元素，历史上被 `v568`（(0,4,2)）、`v578`（`body.hasbg:not(.dark)` 与 `body.hasbg.dark`，(0,5,2)）反复加成。普通写法 `html:root body.hasbg .view.v512-in::before/::after{content:none}` 只压得住 (0,4,2) 那一条。所以 v599 用重复类名：`html:root body.hasbg.hasbg .view.v512-in.v512-in`（(0,6,2)），并同时写 `background:none` / `filter:none`，一次压死，深色浅色同一套。

**实测（无头 CDP，390×844@2，同一个真实点击路径「行程(下滑520) → 美食」）**

| 版本 | 转场期浮层 `.v512-in` 的 `backgroundColor` | 浮层 `::after` | 结论 |
|---|---|---|---|
| v598（旧） | `rgb(244, 247, 246)` = 兜底白板 | `content:""` + 壁纸，随浮层 `tx 390 → 290` 一起走 | 白幕 + 壁纸横移，用户看到的就是这两个 |
| v599（新） | `rgba(0, 0, 0, 0)` | `content:none`、`backgroundImage:none` | 浮层不画任何东西，壁纸只剩静态一层 |

**已知边界（诚实记录）**：观感从「旧页停在原地被盖住」变成「旧页内容淡出 + 新页滑入」—— 这是换取「背景绝对不动、绝对不会被盖」的代价，必须接受这个形态变化。深色 + 自定义背景走同一条规则（浮层同样透明），因此不再有「深色分支没做同构」的遗留问题。

## 首页不许长内容（写死，生成新路书必须遵守）

`#v-home` 只允许三样东西：hero（标题 / 日期·人数·人均 / 两个 tag / 自定义背景）+ 可选 `#wechatTip` 微信提示 + 4 个 `.tiles` 磁贴（出发前准备 / 行程路线图 / 预算与费用 / 其他问题）。**首页严禁出现**「一句话路线」「三条硬提醒（先看这三条）」「这份路书怎么用」「行前三件事」这类正文块——模板本身是干净的，历史上这几块是生成时被额外塞进首页的。

这些内容各有唯一落点：

| 内容 | 落到哪 |
|---|---|
| 一句话路线 | `#v-prep` 第一个 tab「📌 行前必读」（`<div class="card v63-readfirst">` 里的「一句话路线」块） |
| 三条硬提醒（先看这三条） | 同一张行前必读卡里的「⚠️ 三条硬提醒」块 |
| 行前三件事 | 同一张行前必读卡里的「✅ 行前三件事」块 |
| 这份路书怎么用 | `#v-faq` 第一张卡（`<div class="card v63-howto">`，排在「1 为什么这么排」之前） |

**动 `#v-prep` 的卡片必须同步改 tab 映射**：`buildTabs('prepTabs','v-prep',[…])` 的 `els` 用的是 `pc=getElementsByClassName('card')` 的序号，插一张新卡就要把后面所有 `pc[n]` 顺延一位，并把新 tab 放进数组第一位（`defIdx=0` 让它默认展开）。现行顺序：`pc[0]` 行前必读 / `pc[1]` 违禁物品 / `pc[2]` 天气 / `pc[3]` 穿搭 / `pc[4]` 出门检查 / `pc[5]` 酒店导航 / `ph[0]+pc[6]+pc[7]` 预约提醒。

## 景点打卡指引（必须比美食打卡更显眼）

- **每一行「景点行」都要有打卡芯片**，指向 `v-spot-<k>` 机位面板：`<a class="spotlink" href="javascript:void(0)" data-nav="v-spot-xihu">📸 景点打卡指引</a>`，插在 `<em>` 备注之前，保证「正文 → 芯片 → 备注」的阅读顺序。
- **生成时漏写也有运行时兜底**：模板里的 `markSpotLinks()`（放在 `findSpot` 同一个 IIFE 内，紧跟 `placeArt` 那批初始化）在加载后与 1200ms 后各跑一次，遍历 `#v-itinerary .card.daycard` 的所有 `ul.tl>li .c`；命中 `findSpot()`、`document.getElementById('v-spot-'+k)` 存在、该行还没有 `.spotlink`、且不是美食行（带 `.foodlink`）时自动补一个芯片。**同一张日卡同一景点只补一次**，避免连排三行同款按钮。
- **景点 > 美食，靠视觉区分**：`a.spotlink` 是**填色深绿实心胶囊**（`#12A99A→#087569` 渐变、白字、27px 高、白色相机圆标、带投影），`::after` 文案固定「景点打卡指引」；`.foodlink` 保持浅橙描边（`#fff7ed` 底 + `#fed7aa` 边 + 12px 字）。任何新增/覆盖 `.spotlink` 的样式都必须用 `html body a.spotlink` 提权并带 `!important`，否则会被模板里旧的 `.spotlink` 规则压回去。
- **没面板的景点不补芯片**（刻意的：不给无处可跳的按钮）。所以生成新路书时，凡是上了时间线的景点都要建 `v-spot-<k>` 面板（机位 / 构图 / 最佳时段），并在 `#v-spots` 索引里给入口。

## 滚动锁兜底：`lgx-ovlock` / `v46-modal` 残留会把整页锁死（V6.01）

**症状**：刚打开路书、点进「行程」页面，怎么上下滑都不动；刷新一下又好。某种安卓 WebView / 微信内置浏览器里必现。

**成因**：`v46` 弹层（景点打卡 / 美食 / 本地美食）打开时会给 `<html>` 加 `lgx-ovlock`、给 `<body>` 加 `v46-modal`，CSS 是 `position:fixed + overflow:hidden`（为了锁住背景滚动）。关闭走的是「class 变化 + 一次 `sync()`」，如果转场动画事件没触发、或页面刚加载时 `sync()` 早于弹层状态就绪，这两个 class 会留在 body 上——页面从此不能滚。

**修法（`v601-guard-js`，在 `</body>` 前，纯 JS 无依赖）**：只在「确实没有弹层」（`.v46-ov.on` 不可见、`#lb.on` 不存在）时清残留：

- 启动后前 12 秒每 0.8s、之后每 2s 兜一次；
- 点 Dock / 任何 `[data-nav]` 之后 700ms 再兜一次（转场 260ms 已结束）；
- `visibilitychange` 回前台、`pageshow` 各兜一次；
- 手指按下时还锁着 → 立即解；
- 解锁时读 `--lgx-sy` 还原滚动位置（**不许把用户滑到的位置弄丢**，这是有意的功能）。

验收：无头 CDP 里手动加 `documentElement.classList.add('lgx-ovlock')` + `body.classList.add('v46-modal')` + `body.style.position='fixed'`，1.6s 后应变成 `class='' / static / clip visible`，且随后「行程→美食→行程」切换后 `window.scrollY` 仍能变化（实测 tpl 385、路书 953）。

## 可移植性：不依赖豆包，任何 AI 都能完整跑

本技能只有「纯 Python 脚本 + 一个单文件 HTML」，**没有豆包专有工具依赖**，也不要求虚拟桌面/电脑操控：

| 能力 | 脚本 | 依赖 | 任何 AI 都能跑 |
|---|---|---|---|
| 景点实拍图抓取 | `scripts/fetch_spot_photos.py` | 标准库 + Pillow | ✅ |
| 图片写进 HTML（`V543_IMGS` / `V600_ALIAS`） | `scripts/embed_photos.py` | 标准库 | ✅ |
| 示例数据残留自检 | `scripts/check_demo_leftovers.py` | 标准库 | ✅ |
| 交付二维码 | `scripts/make_qr.py`（卡片式，随版本号走） | `segno` + `Pillow` | ✅ |

外部硬依赖只有 `python -m pip install pillow segno` 两条；抓图只走 HTTP，不签名、不要 key。图片也可以由任意 AI 的 `image_search` 出图后，用 `spots.json` 的 `"file"` 字段直接喂给 `fetch_spot_photos.py`。

`FileBatchUpload` 只是「把本地 HTML 变成手机可扫的 https 链接」这一步；换任何能提供静态托管的工具（对象存储、静态站点、任意上传服务）都等价，二维码照旧用 `make_qr.py` 生成。

## 二维码（死规则：每次生成完必须给，且必须是「卡片式」）

每次用本技能生成或更新路书，**交付时必须同时给一张二维码 PNG**，用户拿手机一扫就能打开这份路书。少这一步就算没交付完。**裸码不合格**——用户明确说过「二维码太素了」，要的是带标题/版本/链接的卡片（对照他给的那张参考图）。

1. 用 `FileBatchUpload` 把最终 `.html` 上传，拿到 `https://…` 链接（这类链接返回 `text/html`，手机浏览器扫码即开，不是下载）。
2. 跑技能自带生成器（默认就是卡片式，不需要额外参数）：

   ```bash
   python scripts/make_qr.py "<链接>" "<输出png>" 560 \
          --title "香格里拉 · 稻城亚丁 · 成都" \
          --sub "v0.1 · 扫码在手机 / 微信打开"
   ```

   依赖 `segno` + `Pillow`：`python -m pip install segno pillow`。只要裸码加 `--bare`（不推荐）。
3. 二维码 PNG 与 `.html` 一起交付，回复里明确写「扫码打开」。
4. 页面 `#wechatTip` 里如果还有示例二维码，换成这次链接（现版模板该处已改成纯文字提示，无需再换）。

**卡片规格（不满足就重做）：**

| 项 | 要求 |
|---|---|
| 画布 | 浅灰页面底 `#f4f6f5` + 白色圆角卡片（圆角 26）+ 细边框 `#e2eae7`；宽度 = 码区 + 左右各 36 留白 + 56，实测 688×820 左右 |
| 标题 | 深墨绿 `#0E5C54`，加粗，一行；太长自动缩字号（`fit_text`），不许换行、不许截断 |
| 副标题 | 灰色 `#7c8a88`：`v2.1 · 扫码在手机 / 微信打开`（版本号按规则走） |
| 码点 | 深墨绿，**圆角码点**（半径 ≈ 0.22 模块）+ 三个定位角做成「圆角方框 + 白框 + 实心圆角方块」 |
| 纠错 | 等级 **H**（约 30%），圆角和配色吃掉的面积靠它兜住 |
| 静区 | 码区四周 ≥3 模块纯白 |
| 底部 | 一行灰色链接（去掉 `https://`）+ 一行更淡的「微信内若看到旧版，退出重进链接即可」 |
| 底色 | **不许**深底浅码、不许渐变压码、不许在码上叠图/水印/半透明 logo |

**验收**：生成后用解码器回读，必须解出原链接。本机可用 `pyzbar`（`python -m pip install pyzbar`）：

```python
from PIL import Image
from pyzbar.pyzbar import decode
print([r.data.decode() for r in decode(Image.open("路书二维码.png"))])
```

实测本版卡片码在 100% / 75% / 55% / 40% 四档缩放下都能解出 `https://aka.doubaocdn.com/s/bF28tyfmAU`。另外：链接必须是 `http(s)://`——`file:///` 生成的码手机扫了打不开，等于没给。

## 必须保留的功能（缺一不可）

- 机票 / 火车票识别：上传票据截图走 OCR 自动填车次/检票口/座位，也支持粘贴订单文字解析、剪贴板；车票结果写入 `#railCard`/`#tkForms`，机票结果同时写入 `#planeCard`（航班号、日期、机场、登机口、值机柜台、座位/舱位）；座位明细按实际人数动态显示（1–8 人），不再写死 4 人。
- 列车车型识别：见上节，复兴号/和谐号/普速按 `DB` 判定，未知标「车型待核」。
- 跳转链接：高德导航（`uri.amap.com/search`）、景区官方导览图（内嵌 + 查看原 PDF）、小红书（`xhsdiscover://` scheme + 复制关键词 + 微信「在浏览器打开」降级）。
- 板块：美食打卡（顺路/本地/景点三个 tab）、打卡地点指引（机位构图）、餐厅推荐（按餐次）、预算与费用（按 `#spN` 选择 1–8 人共享记账：记一笔/结算/累计账目）、预算明细、天气、穿搭、出门清单、住宿导航、闹钟日历、备选方案（雨天）。
- **美食打卡三 tab 是硬结构**：不许因为「数据是空的」就删掉整个模块换成静态页（实测有 AI 这么干）。正确做法是保留三 tab、把 `S` / `F` / 榜单条目全填成本次行程的（见「内容必须整套替换」）。
- 图片：景点封面、「景点打卡·热度榜」、**打卡地点指引点进去的景点详情页头图**一律**实拍**（V6.00：构建期 `IMGS` 内嵌 + `V600_ALIAS` 名字映射 + `.v46-shot`，无图才显「暂无实拍图」）；美食仍按「菜名 + 所在景点」程序化配图，两者互不替代。
- 过渡动画与响应式：覆盖式转场、液态玻璃 Dock、暗色/微信内打开适配、移动端与桌面双端。

细节逐项见 `references/framework.md`。

## 交付与验收

- 交付单个 `.html`，能在浏览器直接打开，无控制台报错。
- **必须同时交付一张二维码 PNG**（见上节「二维码（死规则）」），指向已上传的 `https://` 链接；只给文件不给码 = 未完成。
- **验收一律走无头取证，不要占用用户正在用的桌面**：
  1. **静态核对**：`grep` 关键规则、抽内联 `<script>` 逐个 `node --check`（模板共 43 个脚本、已生成的路书 44 个，应全部通过）；再跑 `python scripts/check_demo_leftovers.py --html <路书>`，退出码必须是 0。
  2. **无头截图**：`msedge --headless --disable-gpu --hide-scrollbars --user-data-dir=<每次新建的临时目录> --window-size=W,H --screenshot=<png> "file:///<本地文件>"`。
  3. **动画/交互取证必须用 CDP 真实时间**（`--headless=new --remote-debugging-port=<每次换新> --remote-allow-origins=*`，用 `websocket-client` 连 `webSocketDebuggerUrl`），并在 `Emulation.setDeviceMetricsOverride` + `setTouchEmulationEnabled` + `Input.dispatchTouchEvent` 下跑真实触摸链。**`--virtual-time-budget --dump-dom` 不能用来验动画**：CSS 过渡不被虚拟时间驱动，站点落地依赖动画 `finished`，所有探针都会得到「永不撤层、永远不下沉」的假象，历史上正是这个假象导致「已对齐」的误判。
- `grep` 必查清单（这些都是回归过的点）：

| 要查的 | 期望 |
|---|---|
| `#v-home` 区块内 | **查不到**「一句话路线 / 三条硬提醒 / 这份路书怎么用 / 行前三件事」 |
| `v63-readfirst` / `v63-howto` | 各 1 处，分别在 `#v-prep` 和 `#v-faq` 内 |
| `#railCard::before` 与 `.foldbtn[data-seg]::before` | 有 `display:none!important`（列车图已删） |
| `#railCard` 的补白 | `min-height:0` / `padding-bottom:18px`（不再为列车图留白） |
| `markSpotLinks` | 存在且被调用两次（0ms + 1200ms） |
| `a.spotlink` 强化样式 | 有填色渐变 + `content:"景点打卡指引"` + `html body a.spotlink` 提权 |
| `.dayhero{border-radius:22px` / `.v50-dayart{display:none` / `车型待核` / 客机插画 `viewBox="0 0 900 300"` | 仍在 |
| `v564-art-js` / `v564-bind-js` / `v564-fix-js` / `v564-art-css` / `v564-fix-css` | 各 1 个，且在 `</body>` 之前 |
| `--v564-fimg` / `--v564-simg` / `--v564-mimg` | 三处都有 `!important` 覆盖规则 |
| `.v564-backbar` / `data-v564-back` | 样式 + 注入逻辑都在 |
| `.box.b-gray` 的深色分支 | 有（`@media (prefers-color-scheme: dark)` 内实色深底） |
| `v568-addon-css/js` `v569-addon-css/js` `v570-addon-css/js` `v578-addon-css` `v576-addon-js` | 各 1 个，全部在 `</body>` 之前，外层有 `V5.68-78 追加层 START/END` 注释 |
| `body::before` 与 `body::after` 的 `inset` | 两者都是 `inset:-34px`（不许一个 -26 一个 0） |
| `hasbg` 的深色分支 | 有 `html body.hasbg{background:transparent` |
| `#dock` 的下沉承载 | `data-v58="hold"` / `data-v58="sink"` 两条规则都在，`sink` 的 `transform:translate3d(0,96px,0)` 与 `transition:.30s` 齐 |
| `releaseDock()` | 只有「钉 1 → reflow → 两帧 rAF 放 0」，**不许**出现 `Element.prototype.animate` 包装或逐帧 `setAttribute('style',…)` |
| `pinDockVisible` / `v84sink` / `DUR = 430` / `v584-addon-css` | **应当全部查不到**（自研下沉层与实色深底覆盖层已删） |
| `v586-addon-css` | 1 个，`#7A2E12` / `#FFEFD8` / `#B23A00` 三色齐 |
| `Element.prototype.animate = wrappedAnimate;` / `Animation.prototype.cancel = wrappedCancel;` / `classList.add('v568-land')` | **三处都应查不到**（只允许留成注释）。转场一旦包 WAAPI 或临时关过渡，曲线就不再是原版那 260ms |
| `v588-addon-css` + `v568` 里的 `makeBlur(` | 都在：浮层壁纸走 `--v568-hero-blur` 预模糊图，`--v588-after-filter` 算好后为 `none` |
| `v587-addon-css` | 1 个，含 ①reduce 下的 `html:root body:not(.v512-slide) #dock#dock` 过渡覆盖 ②壁纸 `translateZ(0)` 合成层 ③`@supports (height:100lvh)` 的 `calc(100lvh + 68px)` |
| `v587` 的 reduce 覆盖里 | **不许**出现 `-webkit-transition`（前缀简写会盖掉标准简写，正常态会变成「位移在动、透明度直接归零」） |
| `v568-addon-js` 的 `syncHero` | 必须经 `setVar()` 写变量（比对现值后再写）；直接 `R.style.setProperty('--v568-hero-img', …)` = 自激重绘循环，背景会持续抖 |
| `v568-addon-js` 里的 `blCss` | 必须是 `blCss = 0`（模糊已降到 0）；画布只做「缩放 + `saturate`」，**不许**再写死 `blur(4px)` |
| `v596-addon-css` | 1 个，含 `html:root body.hasbg::before{…saturate(1.05)!important}`（**不再有 `blur()`**；浅/深两套） |
| `v599-addon-css` | 1 个；`body.hasbg .view.v512-in{background-color:transparent!important;background-image:none!important}` + 两伪元素 `content:none` + `body.hasbg .view.v512-out{opacity:0; transition:opacity .16s}` |
| `.v596-paper` / `--v596-px` / `v597-addon-js` | **应当全部查不到**（「浮层上再画一层壁纸」那套已整块删除） |
| `v589-addon-css` | 1 个，含 `.dayhero .dimg{transform:translateZ(0)}` 与 `#v-itinerary .card.daycard .v47-dayscene{transform:translateZ(0)}`（后者写成 `.dayhero .v47-dayscene` 会不命中） |
| `v589-addon-js` | 1 个，含 `__v589w` 去重 + `new Image()`/`decode()` 预热 + `window.__v589Warm` |
| `makeBlur()` 里 | 生成预模糊图后必须 `new Image()` + `decode()`，否则转场首帧现场解码 = 闪一下 |
| 内嵌 JPEG | **全部 `progressive=False`**（渐进式会在重解码时糊一帧）；`data:image/jpeg` 里查不到 progressive 标志，长边 ≤1200 |
| `v591-addon-css/js` | 各 1 个；`.dayhero .dimg` 下必须有 `img.v591-photo`（`decoding="sync"`），且 onload 后背景置 `none` |
| `v600-photo-css` | 1 个；含 `.daycard .v47-dayscene{display:none!important}`、`.dayhero .dimg.v600-noph` 占位、`.v46-rank::before{content:none}`、`.v46-shot` 横幅 |
| `v600-photo-js` | 1 个；含 `function aliasKey(k)`、`W.V600_ALIAS`、`resolve(`、MutationObserver 补 `.v46-shot` |
| `V543_IMGS` | key 覆盖 `SPOTS` 里**每个有实景的 k**；`data:image/jpeg` 数 = 景点数（同一景点可复用，不同景点不许撞图） |
| `V600_ALIAS` | 非空；热度榜行名里出现的景点片段（如「独克宗古城」「松赞林寺」）都要能映射到 `IMGS` 的 key |
| `cover(spot,i)` 接回 `paintHero` | **必须查不到**（`cover(` 只允许出现在 `__v543CoverFor` 工具函数里） |
| `自动题图 ·` | **应当查不到**（角标只允许「网络图 ·」「暂无实拍图 ·」「找图中 ·」） |
| `v601-guard-js` | 1 个，在 `</body>` 前；含 `__v601unlock`、`sheetOpen()`、`boxOpen()`、`--lgx-sy` 还原、`pageshow` 兜底 |
| 脚本数 | 模板 41、生成的路书 42，`node --check` 全过 |
| `verify_roadbook.py` | 打印 `PASS 可以交付`（板块/天数/功能标记/示例残留全过） |
- 逐项核对 `references/framework.md` 的功能清单，确认「不多了、不少了」。
- **三态可读性各拍一张**（浅色 / 深色 / 自定义背景），并把截图一起交付；哪一态没看就等于没验收。
