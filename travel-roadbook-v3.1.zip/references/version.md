# 版本号规则与修改记录

## 规则（写死，从 v1.2 起严格执行）

1. **对外版本号 = 用户要求修改本 skill 的累计次数**，写成 `v{十位}.{个位}`：
   - 12 次 → `v1.2`
   - 13 次 → `v1.3`
   - 9 次 → `v0.9`
   - 10 次 → `v1.0`
   - 23 次 → `v2.3`
   （小于 10 次补 `0.`；个位数直接落在小数位上，不是「1.12」）
2. 每次修改都要动这四处，缺一处就算没改完：
   - 本文件的「累计次数」+1、追加一行记录；
   - 压缩包命名 `travel-roadbook-v3.1.zip`（跟着版本走）；
   - 生成的路书页面里可见的版本标识（`#wechatTip` 的「本页 vX.Y」——这里的 vX.Y 是**这本路书自己的**版本，不是 skill 版本）；
   - 交付二维码卡片的副标题（`--sub "v2.1 · 扫码在手机 / 微信打开"`）。
3. 代码里的 `v600-photo-js` / `v601-guard-js` / `v13-spotdetail-js` 这类**层编号只是构建批次标记**，不对外；对外只说 `v3.1`。
4. 修改次数只统计「用户明确要求改 skill 本体」的轮次；单纯要压缩包、问是否安装、确认是否最新，**不计**。

## 累计次数

**当前：31 次 → v3.1**

| # | 用户要求 | 落点 |
|---|---|---|
| 1 | 自定义背景下切板块，背景短暂变形 | v594–v599 转场层 |
| 2 | 还是轻微变形 + 背景高斯模糊太重 | `makeBlur` 把模糊降到 0 |
| 3 | 第三次反馈「没修好，还是会变形」 | v599 浮层零绘制，靠重复类名顶特异性 (0,6,2) |
| 4 | 切板块时白幕盖住背景 + 背景跟着左右滑 | `body.hasbg .view.v512-in` 透明化 + 伪元素 `content:none` |
| 5 | 「你真的解决了吗，主要在浏览器内打开」 | 无头 CDP 逐帧取证流程写进 SKILL |
| 6 | 确认改的是 skill 不是单个行程 | 改 `assets/template.html` + 文档，不改链接 |
| 7 | 是否已安装、要不要重启 | 明确 `.user_skills` 即安装位，改完即生效 |
| 8 | 要 skill 压缩包 | 打包流程与排除 `.bak` 规则 |
| 9 | 确认是最新完整版 | 解包比对 + 脚本数校验 |
| 10 | 景点打卡要能显示图、行程页必须是实拍不许 AI 图 | V6.00 实拍硬规则、`V600_ALIAS`、`.v46-shot` |
| 11 | Workbody 四条（南京示例数据 / 图源太少 / 点行程不能滑 / 别的 AI 也能用） | 整套替换清单 + 抓图/写入/自检脚本 + `v601-guard-js` |
| 12 | 二维码太素，要卡片式 | `make_qr.py` 重写为卡片码，规格进 SKILL |
| 13 | 「景点打卡指引点进去还是没有景点图片」 | v1.3：详情页补实拍头图（`v13-spotdetail-js`）；顺带修掉 `fetchSpotPhoto` 内嵌图不查别名、以及一开页就并发抓十几张图 |

| 14 | 深色「Day 1」看不清（浅色也要清楚）+ 景点页「返回/关闭」按来路走 | v1.4：`v14-fix-js`（选中标签深青底白字、待出发徽标奶黄底深棕字；导航栈 + 返回条改挂 `data-v14-go`；进详情前给热度榜弹层拍快照，返回可还原） |

| 15 | 景点指引的图要和行程顶部一样：自动识别景点，再去小红书 / 高德 / 美团 / 携程 / 飞猪 / 百度 / 维基 / 360 搜图 | v1.5：`fetch_spot_photos.py` 增 搜狗 + 百度百科两个直连源，8 家平台 `site:` 站内检索全部默认开跑；三处（行程顶图 / 热度榜缩略图 / 详情页头图）共用 `V543_IMGS`+`V600_ALIAS` 写死进 SKILL |

| 16 | 7 天行程顶部只显示 4 个 Day 按钮、其余天堆在下面；点景点打卡回首页 | v1.6：`buildTabs` 改为按 `.daycard` 数量自动生成（不再写死 4 天），标题自动 `Day 1–N`；新增 `v15-anyday-js` 老页面兜底重建 tab；`__navTo` 对缺失板块原地提示不跳首页；`check_demo_leftovers.py` 增结构闸门（缺板块/Dock 指空判失败） |

| 17 | 天数必须是变量，不许写死 7/8 天；加一条红线：所有大模型严格执行 skill、禁止删改框架 | v1.7：SKILL 顶部新增「红线」四条（天数变量化 / 板块与功能禁止删改 / 导航目标必须存在 / 交稿必须自检）；`check_demo_leftovers.py` 增「写死 4 天代码」「没有 .daycard」「四天全部显示」三项硬检 |

| 18 | 提高兼容性，让不擅长写码的模型也能顺利执行 | v1.8：新增 `scripts/verify_roadbook.py` 一键自检（板块/Dock/天数/示例残留/JS 语法，FAIL 时给修法）；SKILL 增「傻瓜执行清单」5 步；日卡选择器容错 `.daycard / [data-day]`，`#dayTabs` 缺失时自建 |

| 19 | 再加一条红线：所有大模型必须严格、完全执行 skill 的全部功能 | v1.9：红线新增「功能必须全量实现」（Curve Day tab / 实拍图 / 热度榜 / 美食三 tab / 返回条 / Dock / 滚动记忆 / 背景 / 票据 / 记账 / 导览图 / 二维码，禁止删改或空壳）；`verify_roadbook.py` 增 9 项功能标记硬检 |

| 20 | skill 里不能保留南京行程的详细内容，只留框架 | v2.0：模板清空 `S/F/SPOTS/MEALS`、`V543_IMGS`、`V600_ALIAS`；4 张日卡换成占位卡；可见文案里的地名/日期/价格全部通用化；体量从 3.85MB 降到 1.97MB；38 个板块与全部交互保留 |

| 21 | 模板里连注释也不能留示例地名 | v2.1：删掉 4 处含示例地名的注释；脚本里残留的地名（浏览器标题兜底、抢票提醒、热度榜来源文案、主题名、官方导览图标签）统一换成通用词；`check_demo_leftovers.py --strict-code` 从「48 词全过 + 27 处代码残留」变成 **0 残留** |

| 22 | 景点详情页必须存在 / 首页必须有 `#rbVer` / 热度榜不许写死杭州南京 | v2.2：`verify_roadbook.py` 增三项硬检；`check_details()` 逐页查 `v-spot-*` 正文、hero、实拍图位 |

| 23 | 切板块回来弹到底部/中部 | v2.3：新增 `v23-scrollfix-js`，导航前保存位置（0 也算有效），落地后六次校正；目标页更矮时按顶部处理 |

| 24 | 顺路/不顺路美食没区别 | v2.4：新增 `v24-foodroute` 按 `g` 的 Day 范围 + 城市比对日卡正文；本地页只渲染 `route:0`；新增 `#v46-near` 附近美食 |

| 25 | 红线要更严格，不许其他模型偷工减料 | v2.5：`verify_roadbook.py` 重写为多层硬闸门（板块≥30 / Dock≥5 / 详情页 / 图片 / 版本 / 美食 / 占位 / 语法） |

| 26 | WorkBuddy 新版首页左缘多一个尖箭头；7 天行程变成 Day 1–16、双数空白 | v2.6：`buildTabs` 与 `v15-anyday-js` 的日卡统计从 `.daycard, [data-day]` 改为只认 `.daycard`（老页面兜底 `.card[data-day]`），tab 判定改 `n===cards.length`；模板/样本同步修；`verify_roadbook.py` 新增并集选择器、`n>=`、标题天数不一致、`</script>` 后裸 `>` 四类硬检，以及 `--expect-days N`（用户说几天就卡几天）；模板不再把 `body[data-day]`/`.v514-art[data-day]` 当日卡 |

| 27 | 图1 红框下隐约图片 / 两天景点图找不到 / Day 按钮点一下变深色 | v2.7：`v27-fix-css` 隐藏 `.v50-wash`/`.v50-mid`/`.v50-dayart` 装饰底纹（深/浅同规则）；`findSpot` 增 2–4 字名称前缀兜底；`v27-fix-js` 从页面自身 `var SPOTS` 解析景点名，自动补 `V600_ALIAS` 城市级别名并逐张补 `.dimg` 封面；Day tab 改白底深字 + 1px 描边 + 3px 外环 + 底部 3px 色条，不再深色填充；`verify_roadbook.py` 增 v27 标记与日卡图 key 数硬检 |

| 28 | WorkBuddy 反馈：v2.7 空白模板清空示例数据时把 `#railCard` / `#planeCard` / `#tkForms` 整块 HTML 删掉，只剩 JS/CSS；`renderRail()` 找不到元素直接 return，OCR 识别出的车次/检票口/座位无处可写；车票座位还写死 4 人（本次 5 人） | v2.8：`assets/template.html` 补回真 HTML（`#railCard`、3 段 `#tkForms`、`#planeCard`、`#tkSeats`、`#tkNo`、`#tkGate`、`#tkEdit`）；每段只放 1 行乘客模板，由 `buildPax()` 动态克隆到 8 行、`applyPax()` 按人数显示；`segData()` 改为按页面实际 `.paxrow` 读取，删掉 `for(i=1;i<=4;i++)`；`renderRail()` 不再写「4 人」；OCR 页补 `#segtabs`；车票/机票 OCR 都能回填；`verify_roadbook.py` 增票卡 DOM、座位字段、`renderRail()`/`planeHead()` 硬检，并拦截写死 4 天的装饰循环 |

| 29 | 复查票卡回填：要求车票 OCR 同时能填航班号/日期/机场/登机口/值机柜台/座位舱位；座位按 1–8 人动态；`verify_roadbook.py` 不能出现 PASS 空壳；并加红线要求所有模型严格完整执行、禁止删改 | v2.9：修复 `planeCard` 手动填按钮只在 `if(!act)` 内绑定的问题（静态 `.v44-act` 导致按钮无事件，现幂等绑定）；`showSeg` 用 important 隐藏修复 `#railCard` 的 `display:flex!important` 冲突；`buildPax`/`applyPax` 实测 8 行克隆、5 人显示；OCR 同时填车票/航班；`verify_roadbook.py` 票卡 DOM/3 段字段/航班字段/写死 4 行/写死 4 天硬检；SKILL 新增第 13 条红线「所有大模型严格完整执行、禁止删改」，红线总数 13 |

| 30 | 复查发现时间线 48 个地点全是纯文本、0 个高德链接；WorkBuddy 两次改版后版本号仍是 v0.1，自检只查格式不查递增 | v3.0：模板新增 `v30-timeline-nav-js`（从 `S`/`SPOTS`/`V600_ALIAS` 读地名，自动给时间线 `.tl .c` 补 `uri.amap.com` 链接，只补没有链接的条目）；`verify_roadbook.py` 新增 `check_timeline_nav()`，按日卡检查时间线是否 0 链接，并新增 `--expect-version` / `--prev-version`，版本没递增或不是用户要求版本直接 FAIL；SKILL 新增第 14 条红线「时间线导航不许漏 + 版本号改一次必须递增」，红线总数 14 |

| 31 | 审查模板发现 WorkBuddy 仍能看到南京/杭州示例详情、餐厅表、官方导览图与示例高德链接；`check_demo_leftovers.py` 漏检编码 URL；Day 标签被 v2.7 白底描边覆盖，和原版路书不一致 | v3.1：模板把示例地名/餐厅/路线/车次/日期/`当地…` 文案全部泛化，110 个静态高德 `keyword` 与 757 个 `city` 参数清成通用值，4 张官方导览图大 JPEG 换透明占位，`v-fuzimiao`→`v-oldstreet`、`v-official-qixia`→`v-official-map3`；`check_demo_leftovers.py` 词表 48→80，新增 `url_query_text()` 对 `keyword/city/query/q` URL 解码后检查；`verify_roadbook.py` 空白模板 <1.5MB 放行、`REQUIRED` 扩到 10 个板块、`FEATURES` 增补 5 个板块、`check_timeline_nav()` 遍历同一日卡的所有 `.tl`、`check_version()` 比对二维码副标题；Day 标签去掉 v2.7 白底描边覆盖，恢复原版深青选中 + 白字，保留「待出发」奶油徽标 |

下次（第 32 次）→ `v3.2`。
