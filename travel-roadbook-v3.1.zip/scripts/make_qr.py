# -*- coding: utf-8 -*-
"""路书交付二维码：把可访问链接生成一张「卡片式」二维码 PNG（扫码即开）。

用法：
    python make_qr.py "<url>" "<out.png>" [二维码方块边长，默认 560]
    python make_qr.py "<url>" "<out.png>" 560 --title "香格里拉 · 稻城亚丁 · 成都" \
           --sub "V6.02 · 扫码在手机 / 微信打开" --note "微信内若看到旧版，退出重进链接即可"
    python make_qr.py "<url>" "<out.png>" 560 --bare     # 只要裸码，不做卡片

卡片样式（默认，对齐用户给的参考图）：
    · 浅灰页面底 + 白色圆角卡片 + 细边框
    · 顶部深墨绿标题（自动缩字号，保证一行放得下）
    · 标题下一行灰色副标题（版本 + 扫码提示）
    · 中间二维码：深墨绿码点、圆角码点，三个定位角做成"圆角方框 + 白框 + 实心方块"
    · 底部一行灰色链接（去掉 https://），再来一行更淡的微信提示
    · 纠错等级 H（约 30%），圆角与配色吃掉的那点面积不影响扫

依赖：segno（纯 Python）+ Pillow
    python -m pip install segno pillow

为什么必须用 segno 而不是手写编码：QR 需要 Reed-Solomon 纠错与掩码选择，
手写极易生成「看着像二维码、其实扫不出来」的图。
"""
import os
import sys

# 卡片配色（深墨绿，跟路书主题一致；与白底对比度 ≈ 9:1，扫得动）
INK = (14, 92, 84)
MUTED = (124, 138, 136)
FAINT = (154, 166, 163)
CARD_BG = (255, 255, 255)
PAGE_BG = (244, 246, 245)
CARD_LINE = (226, 234, 231)

FONT_BOLD_CANDIDATES = [
    r"C:\Windows\Fonts\msyhbd.ttc",
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    "/System/Library/Fonts/PingFang.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
]
FONT_REG_CANDIDATES = [
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    "/System/Library/Fonts/PingFang.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
]


def pick_font(cands, size):
    from PIL import ImageFont
    for p in cands:
        if p and os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                continue
    return ImageFont.load_default()


def draw_round_qr(qr, box, ink=INK, light=(255, 255, 255), qz=3):
    """把 segno 矩阵画成「圆角码点 + 圆角定位角」的位图，返回 RGB 图。"""
    from PIL import Image, ImageDraw
    m = qr.matrix
    n = len(m)
    module = max(2, int(box // (n + 2 * qz)))
    size = module * (n + 2 * qz)
    img = Image.new("RGB", (size, size), light)
    d = ImageDraw.Draw(img)
    r = max(1, int(module * 0.22))

    def in_finder(r_, c_):
        return ((r_ < 7 and c_ < 7) or (r_ < 7 and c_ >= n - 7) or (r_ >= n - 7 and c_ < 7))

    for r_ in range(n):
        row = m[r_]
        for c_ in range(n):
            if not row[c_] or in_finder(r_, c_):
                continue
            x = (c_ + qz) * module
            y = (r_ + qz) * module
            d.rounded_rectangle([x, y, x + module - 1, y + module - 1], radius=r, fill=ink)

    def eye(gr, gc):
        x0 = (gc + qz) * module
        y0 = (gr + qz) * module
        s7 = 7 * module
        d.rounded_rectangle([x0, y0, x0 + s7 - 1, y0 + s7 - 1],
                            radius=int(module * 1.3), fill=ink)
        d.rounded_rectangle([x0 + module, y0 + module, x0 + s7 - 1 - module, y0 + s7 - 1 - module],
                            radius=int(module * 0.9), fill=light)
        x1 = x0 + 2 * module
        y1 = y0 + 2 * module
        d.rounded_rectangle([x1, y1, x1 + 3 * module - 1, y1 + 3 * module - 1],
                            radius=int(module * 0.55), fill=ink)

    eye(0, 0)
    eye(0, n - 7)
    eye(n - 7, 0)
    return img


def fit_text(draw, text, cands, start, max_w, min_size=13):
    size = start
    while size > min_size:
        f = pick_font(cands, size)
        if draw.textlength(text, font=f) <= max_w:
            return f, draw.textlength(text, font=f)
        size -= 1
    f = pick_font(cands, min_size)
    return f, draw.textlength(text, font=f)


def main():
    if len(sys.argv) < 3:
        print("usage: python make_qr.py <url> <out.png> [qr_box_px] "
              "[--title 标题] [--sub 副标题] [--note 底部提示] [--bare]")
        return 2
    url = sys.argv[1].strip()
    out = sys.argv[2].strip()
    box = 560
    title = ""
    sub = ""
    note = ""
    bare = False
    args = sys.argv[3:]
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--bare":
            bare = True
        elif a == "--title" and i + 1 < len(args):
            title = args[i + 1]; i += 1
        elif a == "--sub" and i + 1 < len(args):
            sub = args[i + 1]; i += 1
        elif a == "--note" and i + 1 < len(args):
            note = args[i + 1]; i += 1
        elif a.isdigit():
            box = int(a)
        i += 1

    try:
        import segno
    except ImportError:
        print("缺少依赖 segno：先执行  python -m pip install segno")
        return 3
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print("缺少依赖 Pillow：先执行  python -m pip install pillow")
        return 3

    if not (url.startswith("http://") or url.startswith("https://")):
        print("警告：链接不是 http(s)，手机扫码会打不开：%s" % url)

    qr = segno.make(url, error="h")

    if bare:
        modules = qr.symbol_size(border=4)[0]
        scale = max(1, box // modules)
        os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
        qr.save(out, scale=scale, border=4, dark="#0e5c54", light="#ffffff", kind="png")
        print("url    : %s" % url)
        print("version: %s  modules: %s  scale: %s" % (qr.version, modules, scale))
        print("saved  : %s (%s bytes)" % (out, os.path.getsize(out)))
        return 0

    title = title or "旅行路书"
    sub = sub or "扫码在手机 / 微信打开"
    host = url.split("://", 1)[-1]
    note = note or "微信内若看到旧版，退出重进链接即可"

    pad = 36
    W = box + pad * 2 + 56
    tmp = Image.new("RGB", (10, 10), CARD_BG)
    td = ImageDraw.Draw(tmp)

    f_title, tw = fit_text(td, title, FONT_BOLD_CANDIDATES, 36, W - pad * 2 - 10)
    f_sub = pick_font(FONT_REG_CANDIDATES, 17)
    f_url = pick_font(FONT_REG_CANDIDATES, 15)
    f_note = pick_font(FONT_REG_CANDIDATES, 14)

    th = 46
    sh = 27
    uh = 24
    nh = 22
    qr_img = draw_round_qr(qr, box)
    H = pad + th + 10 + sh + 26 + qr_img.height + 26 + uh + 8 + nh + pad

    card = Image.new("RGB", (W, H), PAGE_BG)
    d = ImageDraw.Draw(card)
    d.rounded_rectangle([8, 8, W - 9, H - 9], radius=26, fill=CARD_BG, outline=CARD_LINE, width=2)

    y = pad
    d.text(((W - tw) / 2, y), title, font=f_title, fill=INK)
    y += th + 10
    sw = d.textlength(sub, font=f_sub)
    d.text(((W - sw) / 2, y), sub, font=f_sub, fill=MUTED)
    y += sh + 26

    qx = (W - qr_img.width) // 2
    card.paste(qr_img, (qx, y))
    y += qr_img.height + 26

    uw = d.textlength(host, font=f_url)
    d.text(((W - uw) / 2, y), host, font=f_url, fill=FAINT)
    y += uh + 8
    nw = d.textlength(note, font=f_note)
    d.text(((W - nw) / 2, y), note, font=f_note, fill=FAINT)

    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    card.save(out, "PNG", optimize=True)
    print("url    : %s" % url)
    print("version: %s  modules: %s  card: %dx%d" % (qr.version, len(qr.matrix), W, H))
    print("saved  : %s (%s bytes)" % (out, os.path.getsize(out)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
