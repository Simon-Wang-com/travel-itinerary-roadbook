#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""构建期「景点实拍图」抓取器（纯 Python，无豆包专有能力，任何 AI/命令行都能跑）。

为什么要有这个脚本：浏览器里（运行时）抓图基本不可用——维基被墙、百度/搜狗/360 的
图片接口都不给 `Access-Control-Allow-Origin`，静态页 fetch 会被 CORS 拦死，JSONP
也早已失效。唯一可靠的做法是**构建期**由脚本（或 Agent 的 image_search）把图抓下来、
压小、base64 内嵌进 HTML。本脚本就是这条构建期链路，图源全部是国内可达接口。

用法:
    python fetch_spot_photos.py --spots spots.json --out photos.json \
           [--preview preview_dir] [--max-side 1100] [--quality 68] [--min-side 640]

spots.json（最少一个字段）:
    [
      {"k": "duke",   "name": "独克宗古城", "q": "独克宗古城 转经筒"},
      {"k": "songzan","name": "松赞林寺",   "q": "松赞林寺 晨雾"}
    ]
    k    = 写进 V543_IMGS 的 key（也是 V600_ALIAS 的 value）
    name = 景点名（热度榜行名里会出现的那个）
    q    = 检索词（可选，默认用 name；加「实拍/风景」之类更容易出照片）

输出 photos.json（可直接喂给 embed_photos.py）:
    {"duke": "data:image/jpeg;base64,....", "songzan": "..."}

图源顺序（`--sources` 可改；默认全部启用）:
    1) 360 图片     https://image.so.com/j                 ✅ 国内直连
    2) 搜狗图片     https://pic.sogou.com/napi/pc/searchList ✅ 国内直连
    3) 百度图片     https://image.baidu.com/search/acjson   ⚠️ 常 antiFlag，尽力而为
    4) 百度百科图   https://baike.baidu.com/api/...         ✅ 词条主图，最贴景点
    5) Bing 图片    https://www.bing.com/images/async       ✅ 可连
    6) 维基百科     https://zh.wikipedia.org/api/rest_v1/... ⛔ 本机被墙，海外可用
    7) 平台站内图   小红书 / 高德 / 美团 / 携程 / 飞猪 / 百度 / 维基 / 360
       —— 这些平台的图片检索要登录态或私有 key，**脚本不硬碰鉴权**，改成
          `site:xiaohongshu.com` 等站内检索走 360/搜狗/Bing，把平台上的实拍图捞出来；
          这是目前唯一不需要账号又能拿到这几家图的稳定路径。

顺序原则：先「景点词条/图库」（360/搜狗/百科），再搜索引擎兜底，最后维基；
每张都过标题闸门 + 尺寸/比例闸门，宁可少一张，也不塞错图。
"""
import argparse
import base64
import io
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import html

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")

BAD_WORDS = ("地图", "路线", "图标", "logo", "LOGO", "门票", "二维码", "截图", "示意",
             "攻略", "封面", "海报", "菜单", "价目", "广告", "水印",
             "动物", "植物", "花卉", "鸟", "猫", "狗", "人像", "自拍", "写真",
             "特写", "细节", "标本", "手绘图", "插画", "壁纸")


def http(url, referer=None, timeout=15, limit=6_000_000):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if referer:
        h["Referer"] = referer
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read(limit), resp.headers.get("Content-Type", "")


def src_so(q, want=12):
    """360 图片：返回 [(url, title, w, h)]"""
    url = "https://image.so.com/j?q=%s&src=srp&sn=0&pn=30" % urllib.parse.quote(q)
    raw, _ = http(url, referer="https://image.so.com/")
    data = json.loads(raw.decode("utf-8", "replace"))
    out = []
    for it in (data.get("list") or data.get("data") or []):
        u = it.get("thumb") or it.get("thumbUrl") or it.get("imgurl") or ""
        u = u.replace("\\/", "/")
        if not u.startswith("http"):
            continue
        out.append((u, html.unescape(str(it.get("title") or "")), int(it.get("width") or 0), int(it.get("height") or 0)))
        if len(out) >= want:
            break
    return out


def src_bing(q, want=12):
    """Bing 图片：把 murl 和 t（标题）按出现顺序配对。标题不含检索词的直接丢。"""
    url = "https://www.bing.com/images/async?q=%s&first=1&count=30&mmasync=1" % urllib.parse.quote(q)
    raw, _ = http(url, referer="https://www.bing.com/")
    urls = [urllib.parse.unquote(m.decode("utf-8", "replace")).replace("\\/", "/")
            for m in re.findall(rb"&quot;murl&quot;:&quot;([^&]+)&quot;", raw)]
    titles = [urllib.parse.unquote(m.decode("utf-8", "replace"))
              for m in re.findall(rb"&quot;t&quot;:&quot;([^&]+)&quot;", raw)]
    out = []
    for i, u in enumerate(urls):
        if not u.startswith("http"):
            continue
        title = titles[i] if i < len(titles) else ""
        out.append((u, title, 0, 0))
        if len(out) >= want * 3:
            break
    return out


def src_baidu(q, want=12):
    """百度图片：经常 antiFlag，能拿到就用"""
    url = ("https://image.baidu.com/search/acjson?tn=resultjson_com&ipn=rj&ct=201326592"
           "&fp=result&word=%s&pn=0&rn=30" % urllib.parse.quote(q))
    raw, _ = http(url, referer="https://image.baidu.com/")
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return []
    if data.get("antiFlag"):
        return []
    out = []
    for it in (data.get("data") or []):
        if not isinstance(it, dict):
            continue
        u = it.get("middleURL") or it.get("thumbURL") or it.get("hoverURL") or ""
        if not u.startswith("http"):
            continue
        out.append((u, str(it.get("fromPageTitle") or ""), int(it.get("width") or 0), int(it.get("height") or 0)))
        if len(out) >= want:
            break
    return out


def src_wiki(q, want=4):
    """维基摘要原图（国内多为超时，保留着以防在海外环境跑）"""
    t = urllib.parse.quote(q.replace(" ", "_"))
    url = "https://zh.wikipedia.org/api/rest_v1/page/summary/%s" % t
    try:
        raw, _ = http(url, timeout=6)
        data = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return []
    src = ((data.get("originalimage") or {}).get("source")
           or (data.get("thumbnail") or {}).get("source") or "")
    return [(src, str(data.get("title") or ""), 0, 0)] if src.startswith("http") else []


def src_sogou(q, want=12):
    """搜狗图片：napi 接口返回 JSON，国内直连。"""
    url = ("https://pic.sogou.com/napi/pc/searchList?mode=1&start=0&xml_len=30&query=%s"
           % urllib.parse.quote(q))
    raw, _ = http(url, referer="https://pic.sogou.com/")
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return []
    out = []
    for it in (((data.get("data") or {}).get("items")) or []):
        u = it.get("picUrl") or it.get("thumbUrl") or it.get("oriPicUrl") or ""
        if not u.startswith("http"):
            continue
        out.append((u, str(it.get("title") or ""), int(it.get("width") or 0), int(it.get("height") or 0)))
        if len(out) >= want:
            break
    return out


def src_baike(q, want=2):
    """百度百科词条主图：景点词条的主图通常就是标准实拍，命中率高于图库。"""
    url = ("https://baike.baidu.com/api/openapi/BaikeLemmaCardApi?scope=103&format=json"
           "&appid=379020&bk_key=%s&bk_length=600" % urllib.parse.quote(q))
    try:
        raw, _ = http(url, timeout=10)
        data = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return []
    u = data.get("imageUrl") or data.get("image") or ""
    if not u.startswith("http"):
        return []
    return [(u, str(data.get("key") or q), 0, 0)]


def kw_hit(q, title):
    """标题里至少要出现一个检索词（>=2 字），否则视为「抓错图」直接丢。
    实测过：Bing 的 murl 列表会混进完全无关的图（查寺庙会返回人像），
    只靠 URL 拿图会把路书配成毫不相干的东西，所以这道闸必须有。"""
    if not title:
        return False
    toks = [t for t in re.split(r"[\s·\|/]+", q) if len(t) >= 2]
    return any(t in title for t in toks)


SOURCES = [("360", src_so), ("sogou", src_sogou), ("baidu", src_baidu),
           ("baike", src_baike), ("bing", src_bing), ("wiki", src_wiki)]


def encode(path_or_bytes, max_side=1100, quality=68, min_side=640, max_ratio=2.4):
    """返回 (dataURI, w, h)；不合格返回 None。"""
    try:
        from PIL import Image
    except ImportError:
        print("缺少依赖 Pillow：python -m pip install pillow", file=sys.stderr)
        raise SystemExit(3)
    try:
        im = Image.open(io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, bytes) else path_or_bytes)
        im.load()
    except Exception:
        return None
    w, h = im.size
    if min(w, h) < min_side:
        return None
    if max(w, h) / float(min(w, h)) > max_ratio:
        return None
    im = im.convert("RGB")
    if max(w, h) > max_side:
        r = max_side / float(max(w, h))
        im = im.resize((max(1, int(w * r)), max(1, int(h * r))), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=quality, progressive=False, optimize=True)
    b = buf.getvalue()
    return ("data:image/jpeg;base64," + base64.b64encode(b).decode("ascii"), im.size[0], im.size[1], len(b))


def fetch_one(spot, args, preview_dir):
    name = spot.get("name") or spot.get("k") or ""
    q = spot.get("q") or name
    if spot.get("file"):
        try:
            with open(spot["file"], "rb") as f:
                got = encode(f.read(), args.max_side, args.quality, args.min_side)
        except Exception as e:
            print("  [%s] 本地文件失败 %s" % (name, e))
            got = None
        if got:
            return got[0], "local"
        return None, "local"
    tried = 0
    queries = [name]
    if q and q != name:
        queries.append(q)
    # 站内检索兜底：小红书 / 携程 / 高德 / 美团 都没有公开的免鉴权图片接口，
    # 但它们的图会被搜索引擎收录，所以用 site: 限定再走一遍 360 / Bing。
    for pf in getattr(args, "platforms_list", []):
        queries.append("%s site:%s" % (name, pf))
        print("  站内检索：%s" % pf)
    for qq in queries:
        for tag, fn in SOURCES:
            try:
                cands = fn(qq)
            except Exception as e:
                print("  [%s] %s 接口失败：%s" % (name, tag, str(e)[:70]))
                continue
            for url, title, w, h in cands:
                if any(b in title for b in BAD_WORDS):
                    continue
                if args.strict and not kw_hit(qq, title):
                    continue
                tried += 1
                try:
                    raw, ctype = http(url, referer={
                        "360": "https://image.so.com/", "sogou": "https://pic.sogou.com/",
                        "baidu": "https://image.baidu.com/", "baike": "https://baike.baidu.com/",
                        "bing": "https://www.bing.com/", "wiki": "https://zh.wikipedia.org/",
                    }.get(tag))
                except Exception:
                    continue
                got = encode(raw, args.max_side, args.quality, args.min_side)
                if not got:
                    continue
                uri, iw, ih, nbytes = got
                print("  [%s] %s 命中 len=%dx%d raw=%dKB  title=%s" % (name, tag, iw, ih, nbytes // 1024, title[:24]))
                if preview_dir:
                    os.makedirs(preview_dir, exist_ok=True)
                    with open(os.path.join(preview_dir, "%s.jpg" % spot.get("k", "spot")), "wb") as f:
                        f.write(base64.b64decode(uri.split(",", 1)[1]))
                return uri, tag
    print("  [%s] 全部图源都没拿到合格图（试了 %d 张）" % (name, tried))
    return None, "none"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spots", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--preview", default="")
    ap.add_argument("--max-side", type=int, default=1100)
    ap.add_argument("--quality", type=int, default=68)
    ap.add_argument("--min-side", type=int, default=640)
    ap.add_argument("--only", default="", help="只跑这些 key，逗号分隔")
    ap.add_argument("--no-strict", action="store_true", help="关掉标题闸门（不建议）")
    ap.add_argument("--platforms",
                    default="xiaohongshu.com,amap.com,meituan.com,ctrip.com,fliggy.com,baidu.com,zh.wikipedia.org,so.com",
                    help="站内检索的站点（小红书/高德/美团/携程/飞猪/百度/维基/360），逗号分隔；置空可关掉")
    a = ap.parse_args()

    a.strict = not a.no_strict
    PLATFORM_ALIAS = {
        "小红书": "xiaohongshu.com", "xhs": "xiaohongshu.com",
        "高德": "amap.com", "高德地图": "amap.com", "gaode": "amap.com",
        "美团": "meituan.com", "大众点评": "dianping.com",
        "携程": "ctrip.com", "飞猪": "fliggy.com",
        "百度": "baidu.com", "维基": "zh.wikipedia.org", "维基百科": "zh.wikipedia.org",
        "360": "so.com", "搜狗": "sogou.com", "bing": "bing.com",
    }
    raw_pf = [x.strip() for x in (a.platforms or "").split(",") if x.strip()]
    a.platforms_list = [PLATFORM_ALIAS.get(x, x) for x in raw_pf]
    spots = json.load(open(a.spots, encoding="utf-8"))
    only = [x.strip() for x in a.only.split(",") if x.strip()]
    if only:
        spots = [s for s in spots if s.get("k") in only]

    out, report = {}, []
    for s in spots:
        k = s.get("k")
        if not k:
            print("跳过没有 k 的条目：%r" % s)
            continue
        print("抓图：%s（%s）" % (k, s.get("name", "")))
        uri, tag = fetch_one(s, a, a.preview)
        if uri:
            out[k] = uri
            report.append({"k": k, "name": s.get("name", ""), "src": tag,
                           "kb": len(uri) * 3 // 4 // 1024})
        time.sleep(0.6)

    os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    print("\n写出 %s：%d/%d 个景点拿到图" % (a.out, len(out), len(spots)))
    for r in report:
        print("  %-12s %-6s %4dKB" % (r["k"], r["src"], r["kb"]))
    miss = [s.get("k") for s in spots if s.get("k") not in out]
    if miss:
        print("没图的 key：%s（补 spots.json，或让 Agent 用 image_search 找图后给 file 字段）" % ", ".join(miss))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
