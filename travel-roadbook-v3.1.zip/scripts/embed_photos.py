#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把构建期抓到的景点图写进 HTML 的 `V543_IMGS`，并合并 `V600_ALIAS`。

纯标准库，任何 AI / 命令行都能跑。幂等：反复执行不会叠加。

用法:
    python embed_photos.py --html 路书.html --photos photos.json \
           [--alias alias.json] [--drop-missing] [--dry]

photos.json : {"duke": "data:image/jpeg;base64,...", ...}   ← fetch_spot_photos.py 的产物
alias.json  : {"独克宗古城": "duke", "松赞林寺": "songzan", ...}
              热度榜行名里出现左边任一片段，就用右边 key 的图。

--drop-missing：把 HTML 里 V543_IMGS 中「本次 photos 没有的 key」删掉（默认保留旧图，
方便分批补图）。
"""
import argparse
import json
import os
import re
import sys


def obj_span(s, marker):
    """找到 marker（如 'window.V543_IMGS='）后面的对象字面量，返回 (start, end) 覆盖整段 {...}。"""
    i = s.find(marker)
    if i < 0:
        return None
    j = s.find("{", i)
    if j < 0:
        return None
    depth = 0
    k = j
    in_str = None
    while k < len(s):
        c = s[k]
        if in_str:
            if c == "\\":
                k += 2
                continue
            if c == in_str:
                in_str = None
        elif c in ("'", '"'):
            in_str = c
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return (j, k + 1)
        k += 1
    return None


def read_obj(s, marker):
    sp = obj_span(s, marker)
    if not sp:
        return {}
    try:
        return json.loads(s[sp[0]:sp[1]])
    except Exception as e:
        print("警告：%s 解析失败（%s），当作空对象" % (marker, e))
        return {}


def write_obj(s, marker, obj):
    sp = obj_span(s, marker)
    body = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    if not sp:
        print("警告：HTML 里没有 %s，跳过（模板旧版可能没有这一行）" % marker)
        return s
    return s[:sp[0]] + body + s[sp[1]:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True)
    ap.add_argument("--photos", required=True)
    ap.add_argument("--alias", default="")
    ap.add_argument("--drop-missing", action="store_true")
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()

    s = open(a.html, encoding="utf-8").read()
    photos = json.load(open(a.photos, encoding="utf-8"))
    if not photos:
        print("photos.json 是空的，没东西可写")
        return 2

    old = read_obj(s, "window.V543_IMGS=")
    if a.drop_missing:
        new = dict(photos)
    else:
        new = dict(old)
        new.update(photos)

    alias_json = json.load(open(a.alias, encoding="utf-8")) if a.alias else {}
    old_alias = read_obj(s, "window.V600_ALIAS=")
    new_alias = dict(old_alias)
    new_alias.update(alias_json)

    print("V543_IMGS：%d → %d 个 key（本次新增/覆盖 %d）" % (len(old), len(new), len(photos)))
    print("V600_ALIAS：%d → %d 条别名" % (len(old_alias), len(new_alias)))
    if a.dry:
        print("（--dry，不写盘）")
        return 0

    s2 = write_obj(s, "window.V543_IMGS=", new)
    s2 = write_obj(s2, "window.V600_ALIAS=", new_alias)
    if len(s2) == len(s):
        print("没变化，未写盘")
        return 0
    open(a.html, "w", encoding="utf-8", newline="").write(s2)
    print("写入 %s：%d → %d 字节（+%.2fMB）" % (
        os.path.basename(a.html), len(s), len(s2), (len(s2) - len(s)) / 1048576.0))
    missing = [k for k in new if k not in photos]
    if missing:
        print("这些 key 仍用旧图：%s" % ", ".join(missing))
    return 0


if __name__ == "__main__":
    sys.exit(main())
